package com.peerlink.app.service

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * F32 pixel mask primitives for the eFootball result reader.
 *
 * Every threshold here was measured on the seven supplied 1600x720 captures
 * and validated through the host-side replica (tests/f32_capture_validation.py).
 * The colours that matter:
 *  - eFootball yellow  ~rgb(216..240,216..240,0)      hue ~60 (F31 looked for 15..45 and never matched)
 *  - score digits       ~rgb(0,0,96) navy inside the yellow boxes
 *  - statistics values  yellow on navy rows
 *  - label text         two dark shades (rgb(0,0,96) and rgb(0,0,32)) on the yellow band
 *  - pitch grass        hue ~91
 *
 * Pure Kotlin over ARGB ints so the rules stay unit-testable on the JVM.
 */
internal object ScorePixelMasks {
    const val TEMPLATE_W = 24
    const val TEMPLATE_H = 32
    const val GLYPH_W = 20
    const val GLYPH_H = 28

    /** One connected component inside a window. Coordinates are window-local. */
    data class Comp(
        val x0: Int, val y0: Int, val x1: Int, val y1: Int, val area: Int,
    ) {
        val w: Int get() = x1 - x0
        val h: Int get() = y1 - y0
        val fill: Float get() = area.toFloat() / max(1, w * h)
    }

    fun red(c: Int) = (c shr 16) and 0xFF
    fun green(c: Int) = (c shr 8) and 0xFF
    fun blue(c: Int) = c and 0xFF

    fun isYellow(c: Int): Boolean {
        val r = red(c); val g = green(c); val b = blue(c)
        return r >= 140 && g >= 120 && b <= 120 &&
            abs(r - g) <= 70 && r - b >= 60 && g - b >= 60
    }

    fun isDark(c: Int): Boolean = maxChannel(c) <= 120

    fun maxChannel(c: Int): Int = max(red(c), max(green(c), blue(c)))

    /** Even darker cut used for the label text on the yellow band. */
    fun isDarkLabel(c: Int): Boolean = maxChannel(c) <= 150

    fun isNavy(c: Int): Boolean {
        val r = red(c); val g = green(c); val b = blue(c)
        return b - r >= 40 && b - g >= 40 && b >= 60 && b <= 170
    }

    fun isGreen(c: Int): Boolean {
        val r = red(c); val g = green(c); val b = blue(c)
        return g - r >= 20 && g - b >= 20 && g >= 70 && g <= 200
    }

    /** Fill an ARGB int array with a mask predicate. */
    inline fun mask(pixels: IntArray, pred: (Int) -> Boolean): BooleanArray {
        val out = BooleanArray(pixels.size)
        for (i in pixels.indices) out[i] = pred(pixels[i])
        return out
    }

    /**
     * 3x3 morphological closing (4-neighbourhood, border cleared). Bridges the
     * hairline gaps that thin eFootball menu glyphs develop after JPEG.
     */
    fun close3(mask: BooleanArray, w: Int, h: Int): BooleanArray {
        if (w <= 0 || h <= 0) return mask
        val dil = BooleanArray(mask.size)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val i = row + x
                if (!mask[i]) continue
                dil[i] = true
                if (x > 0) dil[i - 1] = true
                if (x + 1 < w) dil[i + 1] = true
                if (y > 0) dil[i - w] = true
                if (y + 1 < h) dil[i + w] = true
            }
        }
        val ero = BooleanArray(mask.size)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val i = row + x
                if (x == 0 || y == 0 || x + 1 == w || y + 1 == h) continue
                ero[i] = dil[i] && dil[i - 1] && dil[i + 1] && dil[i - w] && dil[i + w]
            }
        }
        for (i in mask.indices) ero[i] = ero[i] || mask[i]
        return ero
    }

    /**
     * Connected components via flood fill. The windows are tiny (a few hundred
     * pixels), so this stays far cheaper than shipping an OpenCV dependency.
     */
    fun components(
        mask: BooleanArray, w: Int, h: Int, minArea: Int,
    ): List<Comp> {
        val out = ArrayList<Comp>()
        if (w <= 0 || h <= 0) return out
        val seen = BooleanArray(mask.size)
        val queue = IntArray(mask.size)
        for (start in mask.indices) {
            if (!mask[start] || seen[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            seen[start] = true
            var minX = start % w
            var maxX = minX
            var minY = start / w
            var maxY = minY
            var area = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % w
                val y = p / w
                area++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                if (x > 0 && mask[p - 1] && !seen[p - 1]) { seen[p - 1] = true; queue[tail++] = p - 1 }
                if (x + 1 < w && mask[p + 1] && !seen[p + 1]) { seen[p + 1] = true; queue[tail++] = p + 1 }
                if (y > 0 && mask[p - w] && !seen[p - w]) { seen[p - w] = true; queue[tail++] = p - w }
                if (y + 1 < h && mask[p + w] && !seen[p + w]) { seen[p + w] = true; queue[tail++] = p + w }
            }
            if (area >= minArea) out += Comp(minX, minY, maxX + 1, maxY + 1, area)
        }
        return out
    }

    /**
     * Merge glyph fragments that split after JPEG: side-by-side pieces (x near,
     * y overlap) or vertically stacked pieces (y near, x overlap).
     */
    fun mergeFragments(comps: List<Comp>, maxGap: Int = 6, minYOverlap: Float = 0.3f): List<Comp> {
        var work = ArrayList(comps)
        var changed = true
        while (changed) {
            changed = false
            val out = ArrayList<Comp>()
            while (work.isNotEmpty()) {
                val c = work.removeAt(0)
                var hit: Comp? = null
                for (o in out) {
                    val xgap = max(c.x0 - o.x1, o.x0 - c.x1)
                    val ygap = max(c.y0 - o.y1, o.y0 - c.y1)
                    val yover = min(c.y1, o.y1) - max(c.y0, o.y0)
                    val xover = min(c.x1, o.x1) - max(c.x0, o.x0)
                    val nearX = xgap <= maxGap && yover >= minYOverlap * min(c.h, o.h)
                    val nearY = ygap <= maxGap && xover >= minYOverlap * min(c.w, o.w)
                    if (nearX || nearY) { hit = o; break }
                }
                val hit = hit
                if (hit != null) {
                    out.remove(hit)
                    out += Comp(
                        min(hit.x0, c.x0), min(hit.y0, c.y0),
                        max(hit.x1, c.x1), max(hit.y1, c.y1), hit.area + c.area,
                    )
                    changed = true
                } else {
                    out += c
                }
            }
            work = out
        }
        return work
    }

    /** Jaccard distance between two same-size binary masks. */
    fun jaccard(a: BooleanArray, b: BooleanArray): Float {
        var inter = 0
        var union = 0
        val n = min(a.size, b.size)
        for (i in 0 until n) {
            val x = a[i]; val y = b[i]
            if (x && y) inter++
            if (x || y) union++
        }
        if (union == 0) return 1f
        return 1f - inter.toFloat() / union.toFloat()
    }

    /**
     * Tight-crop a glyph mask and fit it (aspect preserved, centred) into the
     * TEMPLATE_W x TEMPLATE_H cell. Returns null when the mask is empty.
     */
    fun normalizeGlyph(mask: BooleanArray, w: Int, h: Int): BooleanArray? {
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (!mask[row + x]) continue
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        if (maxX < minX || maxY < minY) return null
        val sw = maxX - minX + 1
        val sh = maxY - minY + 1
        val scale = min(GLYPH_W.toFloat() / sw, GLYPH_H.toFloat() / sh)
        val nw = max(1, (sw * scale + 0.5f).toInt())
        val nh = max(1, (sh * scale + 0.5f).toInt())
        // Box-sample the source rect into nw x nh (nearest neighbour is stable
        // because the templates themselves were produced with area averaging).
        val small = BooleanArray(nw * nh)
        for (ny in 0 until nh) {
            val sy0 = ny * sh / nh
            val sy1 = max(sy0 + 1, (ny + 1) * sh / nh)
            for (nx in 0 until nw) {
                val sx0 = nx * sw / nw
                val sx1 = max(sx0 + 1, (nx + 1) * sw / nw)
                var on = 0; var total = 0
                for (sy in sy0 until sy1) {
                    val row = (minY + sy) * w
                    for (sx in sx0 until sx1) {
                        total++
                        if (mask[row + minX + sx]) on++
                    }
                }
                small[ny * nw + nx] = on * 2 >= total
            }
        }
        val out = BooleanArray(TEMPLATE_W * TEMPLATE_H)
        val ox = (TEMPLATE_W - nw) / 2
        val oy = (TEMPLATE_H - nh) / 2
        for (ny in 0 until nh) {
            val row = ny * nw
            val dst = (oy + ny) * TEMPLATE_W + ox
            for (nx in 0 until nw) out[dst + nx] = small[row + nx]
        }
        return out
    }
}
