package com.peerlink.app.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.peerlink.app.core.AppState
import com.peerlink.app.godmode.PrimeClient
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * F32 on-device eFootball result reader - recognise first, read second.
 *
 * The F31 reader sent every captured frame through ML Kit (~1.5 s per frame on
 * device) and its visual preprocessor searched for orange-yellow (hue 15..45)
 * while the real eFootball scoreboard yellow sits at hue ~60, so the score was
 * usually never even isolated. F32 fixes both:
 *
 *  1. [ScoreScreenReader] classifies each frame with cheap pixel signatures
 *     (BANNER / STATS / MENU / unknown) and throws non-score frames away
 *     immediately, without any OCR.
 *  2. Recognised screens are read from frozen eFootball-font digit templates
 *     in a few milliseconds; ambiguous glyphs fail the whole cell instead of
 *     guessing. Statistics values and the Full-Time/Halftime label are read
 *     with the same deterministic machinery.
 *  3. ML Kit remains only as a fallback for a recognised screen whose template
 *     read failed, on a tiny preprocessed image, and its hue windows now match
 *     the measured colours.
 */
object PrimeScreenScoreDetector {
    data class Score(val home: Int, val away: Int, val source: String, val finalScreen: Boolean = false)

    /** Full result of one analysed frame: score plus layout, finality and stats. */
    data class Analysis(
        val score: Score?,
        val layout: ScoreScreenReader.Layout,
        val finality: ScoreScreenReader.Finality?,
        val stats: List<ScoreScreenReader.StatRow>?,
    )

    class CapturedFrame internal constructor(
        val bitmap: Bitmap,
        /** true when the payload is the v5 full central crop; false for v4 bands. */
        val fullCrop: Boolean,
        val topHeight: Int,
        val gap: Int,
        val referenceHeight: Int,
    ) {
        fun recycle() {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private val ocrInFlight = java.util.concurrent.atomic.AtomicBoolean(false)
    private val completionExecutor = java.util.concurrent.Executor { it.run() }

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /** Capture only. Kept separate so the 4 Hz producer is not blocked by reads. */
    fun captureFrame(context: Context): CapturedFrame? {
        // Preferred path: Prime crops/scales before the bytes cross loopback.
        PrimeClient.captureScoreFrame()?.let { frame ->
            val bitmap = BitmapFactory.decodeByteArray(frame.bytes, 0, frame.bytes.size) ?: return@let
            if (frame.version >= 5) {
                // v5 payload: central 56% of the display, FULL height.
                if (frame.referenceHeight <= 0 || bitmap.width < 240 || bitmap.height < 180) {
                    bitmap.recycle()
                    return@let
                }
                return CapturedFrame(bitmap, fullCrop = true, topHeight = bitmap.height, gap = 0, referenceHeight = frame.referenceHeight)
            }
            if (frame.topHeight <= 0 || frame.gap < 0 || frame.topHeight.toLong() + frame.gap >= bitmap.height || frame.referenceHeight <= 0) {
                bitmap.recycle()
                return@let
            }
            return CapturedFrame(bitmap, fullCrop = false, topHeight = frame.topHeight, gap = frame.gap, referenceHeight = frame.referenceHeight)
        }

        // A slow v4/v5 capture must not trigger two extra full screenshots.
        if (PrimeClient.protocolVersion == 0 && !PrimeClient.isAlive()) return null
        if (PrimeClient.protocolVersion >= 4) return null

        // A v3 Prime daemon can survive an APK update until reboot/recovery.
        // Keep it usable by taking the old full PNG and cropping locally.
        val png = PrimeClient.captureScreenPng() ?: captureViaLegacyPrime(context) ?: return null
        val source = BitmapFactory.decodeByteArray(png, 0, png.size) ?: return null
        return try {
            CapturedFrame(source, fullCrop = true, topHeight = source.height, gap = 0, referenceHeight = source.height)
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Full F32 analysis of one captured frame. Non-score layouts cost a few
     * milliseconds and never reach ML Kit.
     */
    fun analyzeFrame(frame: CapturedFrame): Analysis? {
        val bitmap = frame.bitmap
        if (bitmap.isRecycled || bitmap.width < 240 || bitmap.height < 180) return null
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        val reading = ScoreScreenReader.read(w, h, pixels) ?: return null

        var score: Score? = null
        if (reading.home != null && reading.away != null) {
            val finalScreen = when (reading.layout) {
                ScoreScreenReader.Layout.STATS, ScoreScreenReader.Layout.MENU ->
                    reading.finality == ScoreScreenReader.Finality.FULL_TIME
                else -> false
            }
            score = Score(reading.home, reading.away, reading.layout.name.lowercase(), finalScreen)
        } else if (reading.layout != ScoreScreenReader.Layout.NONE) {
            // Recognised score screen but the deterministic read failed. Fall
            // back to ML Kit on the small preprocessed image; the fast path is
            // still what runs for the overwhelming majority of frames.
            val fallback = mlKitFallback(frame)
            if (fallback != null) score = fallback.copy(source = "${reading.layout.name.lowercase()}_mlkit")
        }
        return Analysis(score, reading.layout, reading.finality, reading.stats)
    }

    /** F31-compatible API used by the automatic capture engine. */
    fun detectFrame(frame: CapturedFrame): Score? = analyzeFrame(frame)?.score

    /** One-shot helper used by the manual FT button. */
    fun captureScore(context: Context): Score? {
        val frame = captureFrame(context) ?: return null
        return try {
            detectFrame(frame)
        } finally {
            frame.recycle()
        }
    }

    /** Used by tests and by pre-v4 Prime compatibility. */
    internal fun detectScore(source: Bitmap): Score? {
        val frame = CapturedFrame(source, fullCrop = true, topHeight = source.height, gap = 0, referenceHeight = source.height)
        return try {
            detectFrame(frame)
        } finally {
            frame.recycle()
        }
    }

    // ------------------------------------------------------------------
    // ML Kit fallback (rare path)
    // ------------------------------------------------------------------

    /**
     * Build the F31-style two-band composite from this frame and OCR only the
     * isolated score glyphs plus the tiny Full-Time text strips.
     */
    private fun mlKitFallback(frame: CapturedFrame): Score? {
        val compositeSource = if (frame.fullCrop) makeBands(frame.bitmap) else frame.bitmap
            ?: return null
        try {
            val prepared = ScoreVisualPreprocessor.prepare(compositeSource, frame.referenceHeight)
                ?: return null
            return try {
                val text = recognizeBlocking(prepared.bitmap) ?: return null
                val reading = ScoreLaneReader.read(
                    tokens(text),
                    prepared.bitmap.width,
                    prepared.scoreHeight,
                    prepared.gap,
                    prepared.referenceHeight,
                ) ?: return null
                val finalScreen = FinalScoreEvidence.isFinal(text.text) &&
                    !FinalScoreEvidence.isNonFinal(text.text)
                Score(reading.home, reading.away, "mlkit", finalScreen)
            } finally {
                prepared.recycle()
            }
        } finally {
            if (compositeSource !== frame.bitmap && !compositeSource.isRecycled) compositeSource.recycle()
        }
    }

    /** Top 32% + bottom 30% of a full-height central crop (fallback input). */
    private fun makeBands(source: Bitmap): Bitmap? {
        val w = source.width
        val h = source.height
        val topHeight = (h * 0.32f).toInt().coerceAtLeast(1)
        val lowerTop = (h * 0.70f).toInt().coerceIn(0, h - 1)
        val gap = (h / 140).coerceIn(4, 10)
        val height = topHeight + gap + (h - lowerTop)
        val composite = Bitmap.createBitmap(w, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(composite)
        canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(source, Rect(0, 0, w, topHeight), Rect(0, 0, w, topHeight), null)
        canvas.drawBitmap(source, Rect(0, lowerTop, w, h), Rect(0, topHeight + gap, w, height), null)
        return composite
    }

    private fun tokens(text: Text): List<ScoreLaneReader.Token> = buildList {
        fun addToken(value: String, box: Rect?) {
            if (box != null) add(ScoreLaneReader.Token(value, ScoreLaneReader.Box(
                box.left.toFloat(), box.top.toFloat(), box.right.toFloat(), box.bottom.toFloat(),
            )))
        }
        text.textBlocks.forEach { block ->
            block.lines.forEach { line ->
                addToken(line.text, line.boundingBox)
                line.elements.forEach { addToken(it.text, it.boundingBox) }
            }
        }
    }

    /** Compatibility path for a resident v2 PrimeServer. */
    private fun captureViaLegacyPrime(context: Context): ByteArray? {
        val dir = context.externalCacheDir ?: return null
        if (!dir.exists()) runCatching { dir.mkdirs() }
        val file = java.io.File(dir, "match_score_frame.png")
        return try {
            if (!PrimeClient.captureScreenPngToPath(file.absolutePath)) return null
            if (!file.isFile || file.length() !in 64L..(12L * 1024L * 1024L)) return null
            file.readBytes()
        } catch (_: Exception) {
            null
        } finally {
            runCatching { file.delete() }
        }
    }

    private fun recognizeBlocking(bitmap: Bitmap): Text? {
        if (!ocrInFlight.compareAndSet(false, true)) return null
        // ML Kit continues after our wait times out. Give it its own bitmap and
        // retain both that bitmap and the single-flight slot until task completion.
        val owned = try { bitmap.copy(Bitmap.Config.ARGB_8888, false) }
        catch (_: Exception) { null }
        if (owned == null) { ocrInFlight.set(false); return null }
        val latch = CountDownLatch(1)
        val result = java.util.concurrent.atomic.AtomicReference<Text?>()
        try {
            recognizer.process(InputImage.fromBitmap(owned, 0))
                .addOnCompleteListener(completionExecutor) { task ->
                    try {
                        if (task.isSuccessful) result.set(task.result)
                    } finally {
                        owned.recycle()
                        ocrInFlight.set(false)
                        latch.countDown()
                    }
                }
        } catch (_: Exception) {
            owned.recycle()
            ocrInFlight.set(false)
            return null
        }
        return try {
            if (latch.await(1_200L, TimeUnit.MILLISECONDS)) result.get() else null
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            null // Completion still owns cleanup; never recycle ML Kit's live input.
        }
    }
}
