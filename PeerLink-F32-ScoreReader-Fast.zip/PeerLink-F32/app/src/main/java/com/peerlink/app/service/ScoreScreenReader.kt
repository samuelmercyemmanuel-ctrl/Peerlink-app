package com.peerlink.app.service

/**
 * F32 two-stage eFootball result reader: recognise first, read second.
 *
 * Stage 1 classifies the frame with cheap pixel signatures and throws away
 * everything that is not one of the three result screens without any OCR:
 *  - BANNER  walking-pitch score banner (bottom band, players still visible)
 *  - STATS   statistics screen (scoreline on top, 13-row table)
 *  - MENU    Full-Time / halftime menu (big yellow score on black)
 *
 * Stage 2 reads only recognised screens and never touches ML Kit on the fast
 * path: digits come from frozen eFootball-font templates (DigitTemplates).
 * Every geometric constant and colour threshold in this file was measured on
 * the seven supplied 1600x720 captures and cross-validated in the host-side
 * replica against PNG and JPEG q88 re-encodes, including downscaled frames.
 *
 * Fail-safe rule: an ambiguous glyph fails its whole cell (and the cell's
 * value), because a wrong read is worse than no read. The capture engine
 * still requires two matching reads before any automatic settlement.
 *
 * Pure Kotlin over ARGB ints - JVM unit tests exercise this object directly.
 */
internal object ScoreScreenReader {

    enum class Layout { NONE, BANNER, STATS, MENU, UNKNOWN_SCORE }
    enum class Finality { FULL_TIME, HALF_TIME }

    data class StatRow(val label: String, val home: Int?, val away: Int?)

    data class Reading(
        val layout: Layout,
        val home: Int?,
        val away: Int?,
        val confidence: Float,
        val finality: Finality?,
        /** Non-null only when the statistics table was read; rows may hold null cells. */
        val stats: List<StatRow>?,
    )

    class Frame(val w: Int, val h: Int, val pixels: IntArray) {
        val yellow: BooleanArray = ScorePixelMasks.mask(pixels) { ScorePixelMasks.isYellow(it) }
        val dark: BooleanArray = ScorePixelMasks.mask(pixels) { ScorePixelMasks.isDark(it) }
        val navy: BooleanArray = ScorePixelMasks.mask(pixels) { ScorePixelMasks.isNavy(it) }
    }

    // ---- stage 1 windows (fractions of the frame) -------------------------
    private const val TOP_WIN_Y0 = 0.105f; private const val TOP_WIN_Y1 = 0.245f
    private const val BOT_WIN_Y0 = 0.765f; private const val BOT_WIN_Y1 = 0.895f
    private const val BOX_WIN_X0 = 0.34f; private const val BOX_WIN_X1 = 0.66f

    // classification signatures
    private const val GREEN_Y0 = 0.25f; private const val GREEN_Y1 = 0.72f
    private const val GREEN_MIN = 0.22f
    private const val NAVY_Y0 = 0.13f; private const val NAVY_Y1 = 0.28f
    private const val NAVY_MIN = 0.30f
    private const val BLACK_Y1 = 0.62f
    private const val BLACK_MIN = 0.45f

    // ---- menu window -------------------------------------------------------
    private const val MENU_Y0 = 0.105f; private const val MENU_Y1 = 0.245f
    private const val MENU_X0 = 0.36f; private const val MENU_X1 = 0.64f

    // ---- fixed score-box cells --------------------------------------------
    private const val CELL_TOP_Y0 = 0.135f; private const val CELL_TOP_Y1 = 0.225f
    private const val CELL_BOT_Y0 = 0.780f; private const val CELL_BOT_Y1 = 0.870f
    private const val CELL_HOME_X0 = 0.373f; private const val CELL_HOME_X1 = 0.455f
    private const val CELL_AWAY_X0 = 0.505f; private const val CELL_AWAY_X1 = 0.587f

    // ---- statistics table --------------------------------------------------
    private const val STAT_ROW_C0 = 0.2944f
    private const val STAT_ROW_STEP = 0.04472f
    private const val STAT_ROW_HALF = 0.0155f
    private const val STAT_HOME_X0 = 0.218f; private const val STAT_HOME_X1 = 0.345f
    private const val STAT_AWAY_X0 = 0.615f; private const val STAT_AWAY_X1 = 0.752f

    val STAT_LABELS = listOf(
        "Possession", "Total Shots", "Shots on Target", "Fouls", "Offsides",
        "Corner Kicks", "Free Kicks", "Passes", "Successful Passes", "Crosses",
        "Interceptions", "Tackles", "Saves",
    )

    // ---- reading gates -----------------------------------------------------
    private const val MAX_DIST_BOX = 0.55f
    private const val MAX_DIST_MENU = 0.52f
    private const val MAX_DIST_STAT = 0.50f
    private const val MIN_MARGIN = 0.045f
    /** Statistics digits render ~12 px on downscaled frames: slightly softer. */
    private const val MIN_MARGIN_STAT = 0.040f

    // -----------------------------------------------------------------------
    /** Entry point. Returns null when the frame is unusably small. */
    fun read(w: Int, h: Int, pixels: IntArray): Reading? {
        if (w < 240 || h < 180 || pixels.size < w * h) return null
        val fr = Frame(w, h, pixels)
        val topBoxes = boxesInWindow(fr, TOP_WIN_Y0, TOP_WIN_Y1)
        val botBoxes = boxesInWindow(fr, BOT_WIN_Y0, BOT_WIN_Y1)

        var layout = Layout.NONE
        var home: Int? = null
        var away: Int? = null
        var confidence = 0f
        var finality: Finality? = null
        var stats: List<StatRow>? = null

        val green = greenFraction(fr)
        val navyFraction = navyFraction(fr)
        val blackFraction = blackFraction(fr)
        val menuPresent = menuGlyphs(fr).isNotEmpty()
        // Fixed-cell yellow presence rescues frames where the boxes melted
        // into the band (heavy blur / small scale): components vanish but the
        // known positions still hold the box pair.
        val topCellPair = cellPairPresent(fr, top = true)
        val botCellPair = cellPairPresent(fr, top = false)

        when {
            (botBoxes.isNotEmpty() || botCellPair) && green >= GREEN_MIN -> {
                layout = Layout.BANNER
                scoreFrom(tryPair(botBoxes, fr)) {
                    home = it.first; away = it.second; confidence = it.third
                } || runFixedCells(fr, false) {
                    home = it.first; away = it.second; confidence = it.third
                }
            }
            (topBoxes.isNotEmpty() || topCellPair) && navyFraction >= NAVY_MIN -> {
                layout = Layout.STATS
                scoreFrom(tryPair(topBoxes, fr)) {
                    home = it.first; away = it.second; confidence = it.third
                } || runFixedCells(fr, true) {
                    home = it.first; away = it.second; confidence = it.third
                }
                stats = readStats(fr)
                finality = readFinality(fr, true)
            }
            blackFraction >= BLACK_MIN && menuPresent -> {
                layout = Layout.MENU
                readMenuScore(fr)?.let {
                    home = it.first; away = it.second
                }
                finality = readFinality(fr, false)
            }
            topBoxes.isNotEmpty() || botBoxes.isNotEmpty() || topCellPair || botCellPair -> {
                // Yellow box shapes exist but the layout signature is unclear.
                // Read the score if possible; no statistics, no finality claim.
                layout = Layout.UNKNOWN_SCORE
                if (topBoxes.isNotEmpty() || topCellPair) {
                    scoreFrom(tryPair(topBoxes, fr)) {
                        home = it.first; away = it.second; confidence = it.third
                    } || runFixedCells(fr, true) {
                        home = it.first; away = it.second; confidence = it.third
                    }
                }
                if (home == null && (botBoxes.isNotEmpty() || botCellPair)) {
                    scoreFrom(tryPair(botBoxes, fr)) {
                        home = it.first; away = it.second; confidence = it.third
                    } || runFixedCells(fr, false) {
                        home = it.first; away = it.second; confidence = it.third
                    }
                }
            }
        }
        return Reading(layout, home, away, confidence, finality, stats)
    }

    /** Both fixed cells hold a yellow patch: a score box pair is plausible. */
    private fun cellPairPresent(fr: Frame, top: Boolean): Boolean {
        val y0f = if (top) CELL_TOP_Y0 else CELL_BOT_Y0
        val y1f = if (top) CELL_TOP_Y1 else CELL_BOT_Y1
        val y0 = (y0f * fr.h).toInt(); val y1 = (y1f * fr.h).toInt()
        if (y1 <= y0) return false
        fun cellFilled(x0f: Float, x1f: Float): Boolean {
            val x0 = (x0f * fr.w).toInt(); val x1 = (x1f * fr.w).toInt()
            if (x1 <= x0) return false
            var hit = 0; var total = 0
            for (y in y0 until y1) {
                val row = y * fr.w
                for (x in x0 until x1) {
                    total++
                    if (fr.yellow[row + x]) hit++
                }
            }
            return hit >= 0.20f * total
        }
        return cellFilled(CELL_HOME_X0, CELL_HOME_X1) && cellFilled(CELL_AWAY_X0, CELL_AWAY_X1)
    }

    private inline fun scoreFrom(result: Triple<Int, Int, Float>?, block: (Triple<Int, Int, Float>) -> Unit): Boolean {
        if (result == null) return false
        block(result)
        return true
    }

    private fun greenFraction(fr: Frame): Float {
        val y0 = (fr.h * GREEN_Y0).toInt(); val y1 = (fr.h * GREEN_Y1).toInt()
        var hit = 0; var total = 0
        for (y in y0 until min(y1, fr.h)) {
            val row = y * fr.w
            for (x in 0 until fr.w) {
                total++
                if (ScorePixelMasks.isGreen(fr.pixels[row + x])) hit++
            }
        }
        return if (total == 0) 0f else hit.toFloat() / total
    }

    private fun navyFraction(fr: Frame): Float {
        val y0 = (fr.h * NAVY_Y0).toInt(); val y1 = (fr.h * NAVY_Y1).toInt()
        var hit = 0; var total = 0
        for (y in y0 until min(y1, fr.h)) {
            val row = y * fr.w
            for (x in 0 until fr.w) {
                total++
                if (fr.navy[row + x]) hit++
            }
        }
        return if (total == 0) 0f else hit.toFloat() / total
    }

    private fun blackFraction(fr: Frame): Float {
        val y1 = (fr.h * BLACK_Y1).toInt()
        var hit = 0; var total = 0
        for (y in 0 until min(y1, fr.h)) {
            val row = y * fr.w
            for (x in 0 until fr.w) {
                total++
                if (ScorePixelMasks.maxChannel(fr.pixels[row + x]) <= 40) hit++
            }
        }
        return if (total == 0) 0f else hit.toFloat() / total
    }

    // -----------------------------------------------------------------------
    // Yellow score boxes (stats top band / banner bottom band)
    // -----------------------------------------------------------------------

    private fun boxesInWindow(fr: Frame, y0f: Float, y1f: Float): List<ScorePixelMasks.Comp> {
        val y0 = (fr.h * y0f).toInt(); val y1 = (fr.h * y1f).toInt()
        val x0 = (fr.w * BOX_WIN_X0).toInt(); val x1 = (fr.w * BOX_WIN_X1).toInt()
        val sub = BooleanArray(max(1, (y1 - y0) * (x1 - x0)))
        var k = 0
        for (y in y0 until y1) {
            val row = y * fr.w
            for (x in x0 until x1) sub[k++] = fr.yellow[row + x]
        }
        val sw = x1 - x0
        val out = ArrayList<ScorePixelMasks.Comp>()
        for (c in ScorePixelMasks.components(sub, sw, y1 - y0, minArea = 140)) {
            val hh = fr.h
            if (c.h < 0.040f * hh || c.h > 0.105f * hh) continue
            if (c.w < 0.035f * hh || c.w > 0.135f * hh) continue
            if (c.fill < 0.62f) continue
            // back to frame coordinates
            out += ScorePixelMasks.Comp(c.x0 + x0, c.y0 + y0, c.x1 + x0, c.y1 + y0, c.area)
        }
        return out
    }

    /** Try box pairs; the middle box of a triple is the eFootball logo. */
    private fun tryPair(boxes: List<ScorePixelMasks.Comp>, fr: Frame): Triple<Int, Int, Float>? {
        if (boxes.isEmpty()) return null
        val sorted = boxes.sortedBy { it.x0 }
        val tries = if (sorted.size >= 3) {
            listOf(sorted.first() to sorted.last(), sorted[0] to sorted[1], sorted[sorted.size - 2] to sorted.last())
        } else if (sorted.size == 2) {
            listOf(sorted[0] to sorted[1])
        } else return null
        for ((hb, ab) in tries) {
            val hv = readBoxDigits(fr, hb)
            val av = readBoxDigits(fr, ab)
            if (hv != null && av != null) return Triple(hv.first, av.first, (hv.second + av.second) / 2f)
        }
        return null
    }

    private fun glyphFromBox(fr: Frame, box: ScorePixelMasks.Comp): Pair<BooleanArray, Int>? {
        val insetX = (box.w * 0.16f).toInt()
        val insetY = (box.h * 0.16f).toInt()
        val ix0 = box.x0 + insetX; val ix1 = box.x1 - insetX
        val iy0 = box.y0 + insetY; val iy1 = box.y1 - insetY
        if (ix1 - ix0 < 4 || iy1 - iy0 < 4) return null
        val w = ix1 - ix0
        val g = BooleanArray(w * (iy1 - iy0))
        var k = 0
        for (y in iy0 until iy1) {
            val row = y * fr.w
            for (x in ix0 until ix1) {
                val i = row + x
                g[k++] = fr.dark[i] && !fr.yellow[i]
            }
        }
        return g to w
    }

    private fun readBoxDigits(fr: Frame, box: ScorePixelMasks.Comp): Pair<Int, Float>? {
        val (g, gw) = glyphFromBox(fr, box) ?: return null
        val gh = g.size / gw
        val comps = ScorePixelMasks.components(g, gw, gh, minArea = 8)
        if (comps.isEmpty()) return null
        val maxh = comps.maxOf { it.h }
        val kept = comps.filter { it.h >= maxh * 0.62f }.sortedBy { it.x0 }
        var digits = ""
        var confSum = 0f
        for (c in kept) {
            val sub = BooleanArray(c.w * c.h)
            for (y in 0 until c.h) {
                for (x in 0 until c.w) sub[y * c.w + x] = g[(c.y0 + y) * gw + c.x0 + x]
            }
            val norm = ScorePixelMasks.normalizeGlyph(sub, c.w, c.h) ?: return null
            val m = DigitTemplates.best(norm) ?: return null
            if (m.distance > MAX_DIST_BOX || m.margin < MIN_MARGIN) return null
            digits += ('0' + m.digit)
            confSum += m.distance
        }
        if (digits.isEmpty()) return null
        return digits.toInt() to confSum / kept.size
    }

    // -----------------------------------------------------------------------
    // Full-Time / halftime menu: big yellow digits directly on black
    // -----------------------------------------------------------------------

    private fun menuClusters(fr: Frame): List<ScorePixelMasks.Comp> {
        val y0 = (fr.h * MENU_Y0).toInt(); val y1 = (fr.h * MENU_Y1).toInt()
        val x0 = (fr.w * MENU_X0).toInt(); val x1 = (fr.w * MENU_X1).toInt()
        val w = x1 - x0
        if (w <= 0 || y1 <= y0) return emptyList()
        var win = BooleanArray(w * (y1 - y0))
        var k = 0
        for (y in y0 until y1) {
            val row = y * fr.w
            for (x in x0 until x1) win[k++] = fr.yellow[row + x]
        }
        win = ScorePixelMasks.close3(win, w, y1 - y0)
        val comps = ScorePixelMasks.components(win, w, y1 - y0, minArea = 60)
            .filter { it.h >= fr.h * 0.012f }
        if (comps.isEmpty()) return emptyList()
        return ScorePixelMasks.mergeFragments(comps)
    }

    private fun menuGlyphs(fr: Frame): List<ScorePixelMasks.Comp> =
        menuClusters(fr).filter { it.h >= fr.h * 0.055f }

    private fun readMenuScore(fr: Frame): Pair<Int, Int>? {
        val y0 = (fr.h * MENU_Y0).toInt(); val y1 = (fr.h * MENU_Y1).toInt()
        val x0 = (fr.w * MENU_X0).toInt(); val x1 = (fr.w * MENU_X1).toInt()
        val w = x1 - x0
        val clusters = menuClusters(fr)
        val digits = clusters.filter { it.h >= fr.h * 0.055f }
        if (digits.isEmpty()) return null
        val dash = clusters.firstOrNull { it.w.toFloat() / max(1, it.h) > 1.35f && it.h < fr.h * 0.045f }
        val dx = if (dash != null) (dash.x0 + dash.x1) / 2f else w / 2f
        val left = digits.filter { it.x1 <= dx }.sortedBy { it.x0 }
        val right = digits.filter { it.x0 >= dx }.sortedBy { it.x0 }
        var win = BooleanArray(w * (y1 - y0))
        var k = 0
        for (y in y0 until y1) {
            val row = y * fr.w
            for (x in x0 until x1) win[k++] = fr.yellow[row + x]
        }
        win = ScorePixelMasks.close3(win, w, y1 - y0)
        fun value(cs: List<ScorePixelMasks.Comp>): Int? {
            var parts = ""
            for (c in cs) {
                val sub = BooleanArray(c.w * c.h)
                for (y in 0 until c.h) {
                    for (x in 0 until c.w) sub[y * c.w + x] = win[(c.y0 + y) * w + c.x0 + x]
                }
                val norm = ScorePixelMasks.normalizeGlyph(sub, c.w, c.h) ?: return null
                val m = DigitTemplates.best(norm) ?: return null
                if (m.distance > MAX_DIST_MENU || m.margin < MIN_MARGIN) return null
                parts += ('0' + m.digit)
            }
            return if (parts.isEmpty()) null else parts.toInt()
        }
        val hv = value(left) ?: return null
        val av = value(right) ?: return null
        return hv to av
    }

    // -----------------------------------------------------------------------
    // Fixed-cell fallback: read the digit boxes at their known positions
    // -----------------------------------------------------------------------

    private fun readFixedCell(fr: Frame, x0f: Float, x1f: Float, y0f: Float, y1f: Float): Pair<Int, Float>? {
        val x0 = (x0f * fr.w).toInt(); val x1 = (x1f * fr.w).toInt()
        val y0 = (y0f * fr.h).toInt(); val y1 = (y1f * fr.h).toInt()
        val cw = x1 - x0; val ch = y1 - y0
        if (cw <= 0 || ch <= 0) return null
        val cellY = BooleanArray(cw * ch)
        var k = 0
        for (y in y0 until y1) {
            val row = y * fr.w
            for (x in x0 until x1) cellY[k++] = fr.yellow[row + x]
        }
        if (cellY.count { it } < 0.20f * cw * ch) return null
        var bx0 = cw; var bx1 = 0; var by0 = ch; var by1 = 0
        for (y in 0 until ch) {
            for (x in 0 until cw) {
                if (!cellY[y * cw + x]) continue
                if (x < bx0) bx0 = x
                if (x > bx1) bx1 = x
                if (y < by0) by0 = y
                if (y > by1) by1 = y
            }
        }
        if (bx1 <= bx0 || by1 <= by0) return null
        val bw = bx1 - bx0 + 1; val bh = by1 - by0 + 1
        if (bw < 0.030f * fr.w || bh < 0.040f * fr.h) return null
        val aspect = bw.toFloat() / bh
        if (aspect < 0.60f || aspect > 1.85f) return null   // merged boxes fail safe
        var yellowInBox = 0
        for (y in by0..by1) for (x in bx0..bx1) if (cellY[y * cw + x]) yellowInBox++
        if (yellowInBox < 0.52f * bw * bh) return null
        val ix0 = bx0 + (bw * 0.14f).toInt(); val ix1 = bx1 - (bw * 0.14f).toInt()
        val iy0 = by0 + (bh * 0.14f).toInt(); val iy1 = by1 - (bh * 0.14f).toInt()
        if (ix1 - ix0 < 4 || iy1 - iy0 < 4) return null
        val iw = ix1 - ix0
        val sub = BooleanArray(iw * (iy1 - iy0))
        k = 0
        for (y in iy0 until iy1) {
            for (x in ix0 until ix1) {
                val i = y * cw + x
                sub[k++] = fr.dark[(y0 + y) * fr.w + x0 + x] && !cellY[i]
            }
        }
        if (sub.count { it } < 12) return null
        val comps = ScorePixelMasks.components(sub, iw, iy1 - iy0, minArea = 8)
        if (comps.isEmpty()) return null
        val maxh = comps.maxOf { it.h }
        val kept = comps.filter { it.h >= maxh * 0.60f }.sortedBy { it.x0 }
        if (kept.size > 2) return null
        var digits = ""
        var confSum = 0f
        for (c in kept) {
            val s = BooleanArray(c.w * c.h)
            for (y in 0 until c.h) {
                for (x in 0 until c.w) s[y * c.w + x] = sub[(c.y0 + y) * iw + c.x0 + x]
            }
            val norm = ScorePixelMasks.normalizeGlyph(s, c.w, c.h) ?: return null
            val m = DigitTemplates.best(norm) ?: return null
            if (m.distance > MAX_DIST_BOX || m.margin < MIN_MARGIN) return null
            digits += ('0' + m.digit)
            confSum += m.distance
        }
        if (digits.isEmpty()) return null
        return digits.toInt() to confSum / kept.size
    }

    private fun runFixedCells(fr: Frame, top: Boolean, block: (Triple<Int, Int, Float>) -> Unit): Boolean {
        val hv = readFixedCell(fr, CELL_HOME_X0, CELL_HOME_X1, if (top) CELL_TOP_Y0 else CELL_BOT_Y0, if (top) CELL_TOP_Y1 else CELL_BOT_Y1)
        val av = readFixedCell(fr, CELL_AWAY_X0, CELL_AWAY_X1, if (top) CELL_TOP_Y0 else CELL_BOT_Y0, if (top) CELL_TOP_Y1 else CELL_BOT_Y1)
        if (hv == null || av == null) return false
        block(Triple(hv.first, av.first, (hv.second + av.second) / 2f))
        return true
    }

    // -----------------------------------------------------------------------
    // Statistics table: 13 rows, values are yellow digits on navy
    // -----------------------------------------------------------------------

    private fun readStats(fr: Frame): List<StatRow> {
        val rows = ArrayList<StatRow>(13)
        for (i in 0 until 13) {
            val cy = ((STAT_ROW_C0 + STAT_ROW_STEP * i) * fr.h).toInt()
            val half = (STAT_ROW_HALF * fr.h).toInt()
            val y0 = max(0, cy - half); val y1 = min(fr.h, cy + half)
            val home = statCell(fr, STAT_HOME_X0, STAT_HOME_X1, y0, y1)
            val away = statCell(fr, STAT_AWAY_X0, STAT_AWAY_X1, y0, y1)
            rows += StatRow(STAT_LABELS[i], home, away)
        }
        return rows
    }

    private fun statCell(fr: Frame, x0f: Float, x1f: Float, y0: Int, y1: Int): Int? {
        val x0 = (x0f * fr.w).toInt(); val x1 = (x1f * fr.w).toInt()
        val cw = x1 - x0
        if (cw <= 0 || y1 <= y0) return null
        val cell = BooleanArray(cw * (y1 - y0))
        var k = 0
        for (y in y0 until y1) {
            val row = y * fr.w
            for (x in x0 until x1) cell[k++] = fr.yellow[row + x]
        }
        val hBand = y1 - y0
        val comps = ScorePixelMasks.components(cell, cw, hBand, minArea = 14).filter {
            it.h >= 0.018f * fr.h && it.h <= 0.031f * fr.h && it.w <= 0.30f * cw
        }
        if (comps.isEmpty()) return null
        val maxh = comps.maxOf { it.h }
        val kept = comps.filter { it.h >= maxh * 0.60f }.sortedBy { it.x0 }
        var digits = ""
        for (c in kept) {
            val sub = BooleanArray(c.w * c.h)
            for (y in 0 until c.h) {
                for (x in 0 until c.w) sub[y * c.w + x] = cell[(c.y0 + y) * cw + c.x0 + x]
            }
            val norm = ScorePixelMasks.normalizeGlyph(sub, c.w, c.h) ?: return null
            val m = DigitTemplates.best(norm) ?: return null
            if (m.distance > MAX_DIST_STAT) continue   // not a digit at all (e.g. '%')
            if (m.margin < MIN_MARGIN_STAT) return null // ambiguous digit -> fail safe
            digits += ('0' + m.digit)
        }
        return if (digits.isEmpty()) null else digits.toInt()
    }

    // -----------------------------------------------------------------------
    // Finality label: 'Full Time' vs 'Halftime' (stats) / '45:00' vs 'Full Time' (menu)
    // -----------------------------------------------------------------------

    private class Strip(val data: BooleanArray, val w: Int, val h: Int)

    private fun statsLabelStrip(fr: Frame): Strip? {
        val y0 = (fr.h * 0.222f).toInt(); val y1 = (fr.h * 0.276f).toInt()
        // Row detection uses a wide window so bold label text cannot split the
        // band into runs; text extraction then stays in the central window.
        val bw0 = (fr.w * 0.30f).toInt(); val bw1 = (fr.w * 0.70f).toInt()
        val bandW = bw1 - bw0
        if (bandW <= 0 || y1 <= y0) return null
        val yfrac = FloatArray(y1 - y0)
        for (y in y0 until y1) {
            var hit = 0
            val row = y * fr.w
            for (x in bw0 until bw1) if (fr.yellow[row + x]) hit++
            yfrac[y - y0] = hit.toFloat() / bandW
        }
        var bestS = 0; var bestE = 0; var curS: Int? = null
        for (i in yfrac.indices) {
            if (yfrac[i] > 0.55f) {
                if (curS == null) curS = i
            } else if (curS != null) {
                if (i - curS > bestE - bestS) { bestS = curS; bestE = i }
                curS = null
            }
        }
        curS?.let { if (yfrac.size - it > bestE - bestS) { bestS = it; bestE = yfrac.size } }
        // Text rows sit strictly between the first and last pure-band row.
        val pure = (bestS until bestE).filter { yfrac[it] >= 0.92f }
        if (pure.isNotEmpty()) { bestS = pure.first(); bestE = pure.last() + 1 }
        if (bestE <= bestS) return null

        val x0 = (fr.w * 0.42f).toInt(); val x1 = (fr.w * 0.58f).toInt()
        val w = x1 - x0
        if (w <= 0) return null
        val text = BooleanArray(w * (y1 - y0))
        var k = 0
        for (y in y0 until y1) {
            val inBand = y - y0 >= bestS && y - y0 < bestE
            val row = y * fr.w
            for (x in x0 until x1) {
                text[k++] = inBand && ScorePixelMasks.isDarkLabel(fr.pixels[row + x])
            }
        }
        return Strip(text, w, y1 - y0)
    }

    private fun menuLabelStrip(fr: Frame): Strip? {
        val y0 = (fr.h * 0.030f).toInt(); val y1 = (fr.h * 0.095f).toInt()
        val x0 = (fr.w * 0.36f).toInt(); val x1 = (fr.w * 0.64f).toInt()
        val w = x1 - x0
        if (w <= 0 || y1 <= y0) return null
        val text = BooleanArray(w * (y1 - y0))
        var k = 0
        for (y in y0 until y1) {
            val row = y * fr.w
            for (x in x0 until x1) text[k++] = fr.yellow[row + x]
        }
        return Strip(text, w, y1 - y0)
    }

    private fun cleanStrip(strip: Strip, fr: Frame): Strip? {
        val w = strip.w; val h = strip.h
        val raw = strip.data
        // Drop components touching the top/bottom edge (band transition slabs)
        // and slab-shaped components wider than a possible glyph.
        val comps = ScorePixelMasks.components(raw, w, h, minArea = 6)
        if (comps.isEmpty()) return null
        val maxGlyphW = max(24, (fr.w * 0.045f).toInt())
        val clean = BooleanArray(raw.size)
        var kept = 0
        for (c in comps) {
            val touchesEdge = c.y0 == 0 || c.y1 == h
            if (touchesEdge || c.w > maxGlyphW) continue
            for (y in c.y0 until c.y1) {
                for (x in c.x0 until c.x1) clean[y * w + x] = raw[y * w + x]
            }
            kept++
        }
        if (kept == 0 || clean.count { it } < 40) return null
        // Keep only the largest contiguous run of ink rows (the text block):
        // isolated ghost rows at the band edges would bridge the word gap.
        val inkRows = BooleanArray(h)
        for (y in 0 until h) {
            var any = false
            val row = y * w
            for (x in 0 until w) if (clean[row + x]) { any = true; break }
            inkRows[y] = any
        }
        var bs = 0; var be = 0; var cs: Int? = null; var gap = 0
        for (i in 0 until h) {
            if (inkRows[i]) {
                if (cs == null) cs = i
                gap = 0
            } else if (cs != null) {
                gap++
                if (gap > 2) {
                    if (i - gap + 1 - cs > be - bs) { bs = cs; be = i - gap + 1 }
                    cs = null; gap = 0
                }
            }
        }
        if (cs != null && h - cs > be - bs) { bs = cs; be = h }
        if (be <= bs) return null
        val out = BooleanArray(raw.size)
        for (y in bs until be) {
            System.arraycopy(clean, y * w, out, y * w, w)
        }
        if (out.count { it } < 40) return null
        return Strip(out, w, h)
    }

    private fun readFinality(fr: Frame, statsLayout: Boolean): Finality? {
        val raw = (if (statsLayout) statsLabelStrip(fr) else menuLabelStrip(fr)) ?: return null
        val strip = cleanStrip(raw, fr) ?: return null
        val w = strip.w; val h = strip.h
        var minX = w; var maxX = -1; var minY = h; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (!strip.data[row + x]) continue
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        if (maxX < minX || maxY < minY) return null
        val tw = maxX - minX + 1
        val th = maxY - minY + 1
        // column profile inside the text bbox; note zero-runs that touch the
        // bbox edges are not word gaps
        data class Run(val start: Int, val len: Int)
        val inner = ArrayList<Run>()
        var run = 0
        for (i in 0 until tw) {
            var colHasInk = false
            for (y in minY..maxY) if (strip.data[y * w + minX + i]) { colHasInk = true; break }
            if (!colHasInk) run++
            else {
                if (run > 0 && i - run > 0) inner.add(Run(i - run, run))
                run = 0
            }
        }
        if (statsLayout) {
            val mid = inner.filter { it.start.toFloat() / tw >= 0.30f && (it.start + it.len).toFloat() / tw <= 0.72f }
            val big = mid.maxOfOrNull { it.len } ?: 0
            return when {
                big >= 4 -> Finality.FULL_TIME
                big <= 2 -> Finality.HALF_TIME
                else -> null   // small scales shrink the gap; refuse, never guess
            }
        }
        // MENU: clock digits share one height; 'Full Time' letters vary.
        val subW = tw; val subH = th
        val textOnly = BooleanArray(subW * subH)
        for (y in 0 until subH) {
            for (x in 0 until subW) textOnly[y * subW + x] = strip.data[(minY + y) * w + minX + x]
        }
        val comps = ScorePixelMasks.components(textOnly, subW, subH, minArea = 8).filter { it.h >= 4 }
        if (comps.isEmpty()) return null
        val heights = comps.map { it.h }.sorted()
        val spread = (heights.last() - heights.first()).toFloat() / max(1, heights.last())
        val midGap = inner.filter { it.start.toFloat() / tw >= 0.30f && (it.start + it.len).toFloat() / tw <= 0.70f }
            .maxOfOrNull { it.len } ?: 0
        val aspect = tw.toFloat() / th
        return when {
            spread <= 0.25f && aspect <= 4.1f -> Finality.HALF_TIME   // uniform digits + colon
            midGap >= 5 && aspect >= 4.2f -> Finality.FULL_TIME       // two words
            else -> null
        }
    }
}
