package com.peerlink.app.service

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.max
import kotlin.math.min

/**
 * JVM tests for the F32 reader primitives. The digit-rendering helpers draw
 * straight from the frozen template table, so the reader is exercised against
 * exactly the glyph shapes it was built to recognise.
 */
class ScorePixelMasksTest {
    @Test fun measuredColoursClassify() {
        // Values sampled from the supplied 1600x720 captures.
        assertTrue(ScorePixelMasks.isYellow(0xFFD8D800.toInt()))   // box fill
        assertTrue(ScorePixelMasks.isYellow(0xFFF0F000.toInt()))   // bright values
        assertFalse(ScorePixelMasks.isYellow(0xFF000060.toInt()))  // navy band
        assertFalse(ScorePixelMasks.isYellow(0xFF487830.toInt()))  // grass
        assertTrue(ScorePixelMasks.isNavy(0xFF000060.toInt()))
        assertFalse(ScorePixelMasks.isNavy(0xFF000020.toInt()))    // darker label shade
        assertTrue(ScorePixelMasks.isDark(0xFF000060.toInt()))
        assertTrue(ScorePixelMasks.isDark(0xFF000000.toInt()))
        assertFalse(ScorePixelMasks.isDark(0xFFD8D800.toInt()))
        assertTrue(ScorePixelMasks.isDarkLabel(0xFF000020.toInt()))
        assertTrue(ScorePixelMasks.isDarkLabel(0xFF000060.toInt()))
        assertFalse(ScorePixelMasks.isDarkLabel(0xFFD8D800.toInt()))
        assertTrue(ScorePixelMasks.isGreen(0xFF5C8727.toInt()))
        assertFalse(ScorePixelMasks.isGreen(0xFF000060.toInt()))
    }

    @Test fun close3BridgesOnePixelGaps() {
        val w = 8; val h = 8
        val m = BooleanArray(w * h)
        for (x in 0 until 8) m[3 * w + x] = true
        for (x in 0 until 8) m[5 * w + x] = true
        val closed = ScorePixelMasks.close3(m, w, h)
        for (x in 1 until 7) assertTrue("row 4 col $x", closed[4 * w + x])
    }

    @Test fun mergeFragmentsJoinsSideBySideAndStackedPieces() {
        fun comp(x0: Int, y0: Int, x1: Int, y1: Int) = ScorePixelMasks.Comp(x0, y0, x1, y1, (x1 - x0) * (y1 - y0))
        // side-by-side halves of one glyph
        val joined = ScorePixelMasks.mergeFragments(listOf(comp(10, 5, 20, 30), comp(22, 5, 32, 30)))
        assertEquals(1, joined.size)
        assertEquals(10, joined[0].x0); assertEquals(32, joined[0].x1)
        // vertically stacked halves of one glyph (menu digits split this way)
        val stacked = ScorePixelMasks.mergeFragments(listOf(comp(10, 5, 40, 25), comp(10, 28, 40, 45)))
        assertEquals(1, stacked.size)
        assertEquals(5, stacked[0].y0); assertEquals(45, stacked[0].y1)
        // the dash stays separate from both digits
        val apart = ScorePixelMasks.mergeFragments(listOf(comp(10, 5, 40, 45), comp(60, 20, 95, 28)))
        assertEquals(2, apart.size)
    }
}

class DigitTemplatesTest {
    @Test fun allTenDigitsAreFrozen() {
        for (d in 0..9) {
            val glyph = DigitTemplates.render(d)
            assertNotNull("digit $d missing", glyph)
            val match = DigitTemplates.best(glyph!!)!!
            assertEquals("digit $d self match", d, match.digit)
            assertEquals("digit $d self distance", 0f, match.distance, 1e-6f)
            assertTrue("digit $d margin", match.margin > 0.02f)
        }
    }

    @Test fun tableShapeIsExact() {
        assertEquals(ScorePixelMasks.TEMPLATE_W * ScorePixelMasks.TEMPLATE_H, 24 * 32)
    }
}

class ScoreScreenReaderTest {
    private val w = 896
    private val h = 720

    private fun blank(bg: Int) = IntArray(w * h) { bg }

    private fun rect(pixels: IntArray, x0: Int, y0: Int, x1: Int, y1: Int, color: Int) {
        for (y in max(0, y0)..min(h - 1, y1)) {
            for (x in max(0, x0)..min(w - 1, x1)) pixels[y * w + x] = color
        }
    }

    /** Draw a frozen template digit scaled into the target rect (nearest). */
    private fun glyph(pixels: IntArray, digit: Int, x0: Int, y0: Int, rw: Int, rh: Int, color: Int) {
        val bits = DigitTemplates.render(digit)!!
        // tight bounds of the template
        var minX = 24; var maxX = -1; var minY = 32; var maxY = -1
        for (y in 0 until 32) for (x in 0 until 24) {
            if (!bits[y * 24 + x]) continue
            if (x < minX) minX = x; if (x > maxX) maxX = x
            if (y < minY) minY = y; if (y > maxY) maxY = y
        }
        val sw = maxX - minX + 1; val sh = maxY - minY + 1
        for (y in 0 until rh) {
            for (x in 0 until rw) {
                val tx = minX + x * sw / rw
                val ty = minY + y * sh / rh
                if (bits[ty * 24 + tx]) {
                    val px = x0 + x; val py = y0 + y
                    if (px in 0 until w && py in 0 until h) pixels[py * w + px] = color
                }
            }
        }
    }

    private fun drawTemplate(pixels: IntArray, digit: Int, x0: Int, y0: Int, color: Int) {
        val bits = DigitTemplates.render(digit)!!
        for (y in 0 until 32) for (x in 0 until 24) {
            if (bits[y * 24 + x]) pixels[(y0 + y) * w + x0 + x] = color
        }
    }

    /** Solid yellow box with the navy digit drawn straight onto the fill. */
    private fun yellowBoxWithDigit(pixels: IntArray, digit: Int, bx0: Int, by0: Int, bw: Int = 44, bh: Int = 48) {
        rect(pixels, bx0, by0, bx0 + bw, by0 + bh, 0xFFD8D800.toInt())
        drawTemplate(pixels, digit, bx0 + (bw - 24) / 2, by0 + (bh - 32) / 2, 0xFF000060.toInt())
    }

    private fun navy(): Int = 0xFF000060.toInt()
    private fun grass(): Int = 0xFF5C8727.toInt()

    @Test fun plainGameplayFrameIsDiscardedWithoutReading() {
        // Grass everywhere, no yellow anywhere: exactly the "throw it away
        // immediately" path the capture engine relies on.
        val pixels = blank(grass())
        val reading = ScoreScreenReader.read(w, h, pixels)!!
        assertEquals(ScoreScreenReader.Layout.NONE, reading.layout)
        assertNull(reading.home)
        assertNull(reading.stats)
    }

    @Test fun statsScreenClassifiesAndReadsBoxedScore() {
        val pixels = blank(navy())
        // pitch strip at the very bottom so the frame is not classified BANNER
        rect(pixels, 0, (h * 0.92f).toInt(), w, h - 1, grass())
        yellowBoxWithDigit(pixels, 4, 354, 105)
        yellowBoxWithDigit(pixels, 2, 465, 105)
        val reading = ScoreScreenReader.read(w, h, pixels)!!
        assertEquals(ScoreScreenReader.Layout.STATS, reading.layout)
        assertEquals(4, reading.home)
        assertEquals(2, reading.away)
        assertTrue(reading.confidence < 0.4f)
    }

    @Test fun walkingBannerClassifiesAndReadsBottomScore() {
        val pixels = blank(grass())
        // navy banner band with the two score boxes
        rect(pixels, 0, 570, w, 655, navy())
        yellowBoxWithDigit(pixels, 0, 354, 578)
        yellowBoxWithDigit(pixels, 1, 465, 578)
        val reading = ScoreScreenReader.read(w, h, pixels)!!
        assertEquals(ScoreScreenReader.Layout.BANNER, reading.layout)
        assertEquals(0, reading.home)
        assertEquals(1, reading.away)
    }

    @Test fun menuClassifiesAndReadsBigYellowScore() {
        val pixels = blank(0xFF000000.toInt())
        // white menu tiles below the score
        rect(pixels, 150, 250, 720, 340, 0xFFF0F0F0.toInt())
        // big yellow digits with a dash between
        glyph(pixels, 4, 368, 88, 36, 52, 0xFFF0F000.toInt())
        rect(pixels, 420, 116, 452, 124, 0xFFF0F000.toInt())
        glyph(pixels, 2, 496, 88, 36, 52, 0xFFF0F000.toInt())
        val reading = ScoreScreenReader.read(w, h, pixels)!!
        assertEquals(ScoreScreenReader.Layout.MENU, reading.layout)
        assertEquals(4, reading.home)
        assertEquals(2, reading.away)
    }

    @Test fun fixedCellsRescueMergedBoxFrames() {
        // Same stats screen but the score boxes melt into the band (heavy
        // blur): component detection fails, the fixed positions still read.
        val pixels = blank(navy())
        rect(pixels, 0, (h * 0.92f).toInt(), w, h - 1, grass())
        yellowBoxWithDigit(pixels, 0, 354, 105)
        yellowBoxWithDigit(pixels, 1, 465, 105)
        // glue a yellow bridge so the two boxes merge into one component
        rect(pixels, 398, 105, 465, 153, 0xFFD8D800.toInt())
        val reading = ScoreScreenReader.read(w, h, pixels)!!
        assertEquals(ScoreScreenReader.Layout.STATS, reading.layout)
        assertEquals(0, reading.home)
        assertEquals(1, reading.away)
    }

    @Test fun statisticsRowIsReadFromRenderedDigits() {
        val pixels = blank(navy())
        rect(pixels, 0, (h * 0.92f).toInt(), w, h - 1, grass())
        yellowBoxWithDigit(pixels, 1, 354, 105)
        yellowBoxWithDigit(pixels, 2, 465, 105)
        // Fouls row: i = 3 -> centre at 0.2944 + 3*0.04472 = 0.4286 of height
        val cy = ((0.2944f + 3 * 0.04472f) * h).toInt()
        glyph(pixels, 2, 250, cy - 8, 11, 16, 0xFFF0F000.toInt())
        glyph(pixels, 0, 610, cy - 8, 11, 16, 0xFFF0F000.toInt())
        val reading = ScoreScreenReader.read(w, h, pixels)!!
        assertEquals(ScoreScreenReader.Layout.STATS, reading.layout)
        assertNotNull(reading.stats)
        assertEquals(13, reading.stats!!.size)
        assertEquals(2, reading.stats!![3].home)
        assertEquals(0, reading.stats!![3].away)
        assertEquals("Fouls", reading.stats!![3].label)
    }

    @Test fun ambiguousGlyphFailsSafeInsteadOfGuessing() {
        val pixels = blank(navy())
        rect(pixels, 0, (h * 0.92f).toInt(), w, h - 1, grass())
        // A blob drawn over the box fill: dark and not yellow, but no digit
        // template comes close, so the cell must fail instead of guessing.
        yellowBoxWithDigit(pixels, 8, 354, 105)
        yellowBoxWithDigit(pixels, 2, 465, 105)
        rect(pixels, 354 + 10, 105 + 8, 354 + 34, 105 + 40, 0xFF000060.toInt())
        val reading = ScoreScreenReader.read(w, h, pixels)!!
        assertEquals(ScoreScreenReader.Layout.STATS, reading.layout)
        assertNull("a filled blob must not become a digit", reading.home)
    }

    @Test fun fullTimeLabelBeatsHalftimeOnTheStatsBand() {
        val pixels = blank(navy())
        rect(pixels, 0, (h * 0.92f).toInt(), w, h - 1, grass())
        yellowBoxWithDigit(pixels, 0, 354, 105)
        yellowBoxWithDigit(pixels, 1, 465, 105)
        // the yellow band under the scoreline: 164..194 at 720p
        rect(pixels, (w * 0.30f).toInt(), 164, (w * 0.70f).toInt(), 194, 0xFFD8D800.toInt())
        // "Full Time": two words with a wide mid gap
        var x = (w * 0.44f).toInt()
        repeat(4) { rect(pixels, x, 170, x + 8, 188, 0xFF000020.toInt()); x += 14 }
        x += 16 // word space
        repeat(4) { rect(pixels, x, 170, x + 8, 188, 0xFF000020.toInt()); x += 14 }
        val reading = ScoreScreenReader.read(w, h, pixels)!!
        assertEquals(ScoreScreenReader.Layout.STATS, reading.layout)
        assertEquals(ScoreScreenReader.Finality.FULL_TIME, reading.finality)
    }

    @Test fun halftimeLabelHasNoMidGap() {
        val pixels = blank(navy())
        rect(pixels, 0, (h * 0.92f).toInt(), w, h - 1, grass())
        yellowBoxWithDigit(pixels, 1, 354, 105)
        yellowBoxWithDigit(pixels, 2, 465, 105)
        rect(pixels, (w * 0.30f).toInt(), 164, (w * 0.70f).toInt(), 194, 0xFFD8D800.toInt())
        // "Halftime": one word, only narrow letter gaps
        var x = (w * 0.44f).toInt()
        repeat(8) { rect(pixels, x, 170, x + 8, 188, 0xFF000020.toInt()); x += 12 }
        val reading = ScoreScreenReader.read(w, h, pixels)!!
        assertEquals(ScoreScreenReader.Layout.STATS, reading.layout)
        assertEquals(ScoreScreenReader.Finality.HALF_TIME, reading.finality)
    }
}
