#!/usr/bin/env python3
"""F32 host-side validation of the score reader against the real captures.

This is the pixel-pipeline replica of ScoreScreenReader.kt. It parses the
frozen digit templates straight out of DigitTemplates.kt (single source of
truth) and re-runs the complete F32 classification + reading pipeline over the
seven supplied eFootball screenshots, PNG and JPEG q88, including a downscaled
pass. Expected readings:

    20260808-135907  STATS  1-2  Halftime   full 13-row statistics table
    20260808-140853  STATS  4-2  Halftime   full 13-row statistics table
    20260808-140859  MENU   4-2  Halftime (45:00)
    20260905-005550  STATS  0-0  Halftime   full 13-row statistics table
    20260905-010207  BANNER 0-1  -
    20260905-184444  STATS  0-1  Full Time  full 13-row statistics table
    20260906-204840  MENU   2-2  Full Time

Dependencies: numpy, pillow (both already used by the other host tests).
"""
import io
import re
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.setrecursionlimit(10000)

# ---------------------------------------------------------------------------
# Templates parsed from the Kotlin source (bit 23-x of row y)
# ---------------------------------------------------------------------------
def load_templates():
    src = (ROOT / 'app/src/main/java/com/peerlink/app/service/DigitTemplates.kt').read_text()
    table = {}
    for m in re.finditer(r'(\d) to intArrayOf\(([^)]*)\)', src):
        digit = int(m.group(1))
        words = [int(w, 16) for w in m.group(2).replace('\n', '').split(',')]
        assert len(words) == 32, (digit, len(words))
        cell = np.zeros((32, 24), dtype=bool)
        for y, w in enumerate(words):
            for x in range(24):
                cell[y, x] = (w >> (23 - x)) & 1 != 0
        table[digit] = [cell]
    assert set(table) == set(range(10)), table.keys()
    return table

TW, TH = 24, 32
INNER_W, INNER_H = 20, 28

# ---------------------------------------------------------------------------
# Colour masks (must stay identical to ScorePixelMasks.kt)
# ---------------------------------------------------------------------------
def mask_yellow(rgb):
    r = rgb[..., 0].astype(np.int16); g = rgb[..., 1].astype(np.int16); b = rgb[..., 2].astype(np.int16)
    return (r >= 140) & (g >= 120) & (b <= 120) & (abs(r - g) <= 70) & (r - b >= 60) & (g - b >= 60)

def mask_dark(rgb):
    return rgb.max(axis=2) <= 120

def mask_navy(rgb):
    r = rgb[..., 0].astype(np.int16); g = rgb[..., 1].astype(np.int16); b = rgb[..., 2].astype(np.int16)
    return (b - r >= 40) & (b - g >= 40) & (b >= 60) & (b <= 170)

def mask_green(rgb):
    r = rgb[..., 0].astype(np.int16); g = rgb[..., 1].astype(np.int16); b = rgb[..., 2].astype(np.int16)
    return (g - r >= 20) & (g - b >= 20) & (g >= 70) & (g <= 200)

# ---------------------------------------------------------------------------
# Components (4-connectivity BFS - same semantics as ndimage.label)
# ---------------------------------------------------------------------------
def components(mask, min_area=12):
    h, w = mask.shape
    lab = np.zeros((h, w), dtype=np.int32)
    out = []
    comps = []
    for sy in range(h):
        for sx in range(w):
            if not mask[sy, sx] or lab[sy, sx]:
                continue
            label = len(comps) + 1
            stack = [(sy, sx)]
            lab[sy, sx] = label
            y0 = y1 = sy; x0 = x1 = sx; area = 0
            while stack:
                y, x = stack.pop()
                area += 1
                if x < x0: x0 = x
                if x > x1: x1 = x
                if y < y0: y0 = y
                if y > y1: y1 = y
                if x > 0 and mask[y, x - 1] and not lab[y, x - 1]:
                    lab[y, x - 1] = label; stack.append((y, x - 1))
                if x + 1 < w and mask[y, x + 1] and not lab[y, x + 1]:
                    lab[y, x + 1] = label; stack.append((y, x + 1))
                if y > 0 and mask[y - 1, x] and not lab[y - 1, x]:
                    lab[y - 1, x] = label; stack.append((y - 1, x))
                if y + 1 < h and mask[y + 1, x] and not lab[y + 1, x]:
                    lab[y + 1, x] = label; stack.append((y + 1, x))
            comps.append((label, x0, y0, x1 + 1, y1 + 1, area))
    for label, x0, y0, x1, y1, area in comps:
        if area >= min_area:
            out.append({'x0': x0, 'y0': y0, 'x1': x1, 'y1': y1, 'area': area,
                        'w': x1 - x0, 'h': y1 - y0,
                        'fill': area / max(1, (x1 - x0) * (y1 - y0))})
    return out

def close3(mask):
    m = mask.copy()
    d = m.copy()
    d[1:, :] |= m[:-1, :]; d[:-1, :] |= m[1:, :]
    d[:, 1:] |= m[:, :-1]; d[:, :-1] |= m[:, 1:]
    e = d.copy()
    e[1:, :] &= d[:-1, :]; e[:-1, :] &= d[1:, :]
    e[:, 1:] &= d[:, :-1]; e[:, :-1] &= d[:, 1:]
    e[0, :] = False; e[-1, :] = False; e[:, 0] = False; e[:, -1] = False
    return e | m

def merge_fragments(comps, max_gap=6, min_yover=0.3):
    comps = [dict(c) for c in comps]
    changed = True
    while changed:
        changed = False
        out = []
        while comps:
            c = comps.pop(0)
            hit = None
            for o in out:
                xgap = max(c['x0'] - o['x1'], o['x0'] - c['x1'])
                ygap = max(c['y0'] - o['y1'], o['y0'] - c['y1'])
                yover = min(c['y1'], o['y1']) - max(c['y0'], o['y0'])
                xover = min(c['x1'], o['x1']) - max(c['x0'], o['x0'])
                near_x = xgap <= max_gap and yover >= min_yover * min(c['h'], o['h'])
                near_y = ygap <= max_gap and xover >= min_yover * min(c['w'], o['w'])
                if near_x or near_y:
                    hit = o; break
            if hit is not None:
                hit['x0'] = min(hit['x0'], c['x0']); hit['x1'] = max(hit['x1'], c['x1'])
                hit['y0'] = min(hit['y0'], c['y0']); hit['y1'] = max(hit['y1'], c['y1'])
                hit['w'] = hit['x1'] - hit['x0']; hit['h'] = hit['y1'] - hit['y0']
                changed = True
            else:
                out.append(c)
        comps = out
    return comps

def normalize(glyph):
    ys, xs = np.nonzero(glyph)
    if len(xs) == 0: return None
    sub = glyph[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    sh, sw = sub.shape
    scale = min(INNER_W / sw, INNER_H / sh)
    nw, nh = max(1, int(round(sw * scale))), max(1, int(round(sh * scale)))
    img = Image.fromarray((sub * 255).astype(np.uint8)).resize((nw, nh), Image.BILINEAR)
    out = np.zeros((TH, TW), dtype=bool)
    small = np.asarray(img) >= 128
    out[(TH - nh) // 2:(TH - nh) // 2 + nh, (TW - nw) // 2:(TW - nw) // 2 + nw] = small
    return out

TEMPLATES = None

class DigitReader:
    @staticmethod
    def best(glyph):
        n = normalize(glyph)
        if n is None: return None, 1.0, 0.0
        scores = []
        for d, cells in TEMPLATES.items():
            inter = np.logical_and(n, cells[0]).sum()
            union = np.logical_or(n, cells[0]).sum()
            dist = 1.0 - inter / max(1, union)
            scores.append((dist, d))
        scores.sort()
        margin = scores[1][0] - scores[0][0] if len(scores) > 1 else 1.0
        return scores[0][1], scores[0][0], margin

# ---------------------------------------------------------------------------
# Frame + pipeline (mirrors ScoreScreenReader.kt)
# ---------------------------------------------------------------------------
CROP_X0, CROP_X1 = 0.22, 0.78

class Frame:
    def __init__(self, rgb):
        self.rgb = rgb
        self.h, self.w = rgb.shape[:2]
        self.yellow = mask_yellow(rgb)
        self.dark = mask_dark(rgb)
        self.navy = mask_navy(rgb)

def load_frame(path, jpeg_q=None, scale=1.0):
    img = Image.open(path).convert('RGB')
    W, H = img.size
    crop = img.crop((int(W * CROP_X0), 0, int(W * CROP_X1), H))
    if jpeg_q is not None:
        buf = io.BytesIO(); crop.save(buf, 'JPEG', quality=jpeg_q); buf.seek(0)
        crop = Image.open(buf).convert('RGB')
    if scale != 1.0:
        crop = crop.resize((int(crop.width * scale), int(crop.height * scale)), Image.BILINEAR)
    return Frame(np.asarray(crop))

CELL_TOP_Y = (0.135, 0.225); CELL_BOT_Y = (0.780, 0.870)
CELL_HOME_X = (0.373, 0.455); CELL_AWAY_X = (0.505, 0.587)
STAT_LABELS = ['Possession', 'Total Shots', 'Shots on Target', 'Fouls', 'Offsides',
               'Corner Kicks', 'Free Kicks', 'Passes', 'Successful Passes', 'Crosses',
               'Interceptions', 'Tackles', 'Saves']

def subwin(mask, w, x0, y0, x1, y1):
    return mask[y0:y1, x0:x1]

def boxes_in_window(fr, y0f, y1f):
    y0, y1 = int(fr.h * y0f), int(fr.h * y1f)
    x0, x1 = int(fr.w * 0.34), int(fr.w * 0.66)
    out = []
    for c in components(subwin(fr.yellow, fr.w, x0, y0, x1, y1), min_area=140):
        c = dict(c, x0=c['x0'] + x0, y0=c['y0'] + y0, x1=c['x1'] + x0, y1=c['y1'] + y0)
        if not (0.040 * fr.h <= c['h'] <= 0.105 * fr.h): continue
        if not (0.035 * fr.h <= c['w'] <= 0.135 * fr.h): continue
        if c['fill'] < 0.62: continue
        out.append(c)
    return out

def cell_pair_present(fr, top):
    y0f, y1f = CELL_TOP_Y if top else CELL_BOT_Y
    y0, y1 = int(y0f * fr.h), int(y1f * fr.h)
    def filled(x0f, x1f):
        x0, x1 = int(x0f * fr.w), int(x1f * fr.w)
        cell = fr.yellow[y0:y1, x0:x1]
        return cell.mean() >= 0.20
    return filled(*CELL_HOME_X) and filled(*CELL_AWAY_X)

def menu_glyphs(fr):
    y0, y1 = int(fr.h * 0.105), int(fr.h * 0.245)
    x0, x1 = int(fr.w * 0.36), int(fr.w * 0.64)
    win = close3(fr.yellow[y0:y1, x0:x1])
    comps = [c for c in components(win, min_area=60) if c['h'] >= fr.h * 0.012]
    if not comps: return []
    return [c for c in merge_fragments(comps) if c['h'] >= fr.h * 0.055]

def classify(fr):
    top = boxes_in_window(fr, 0.105, 0.245)
    bot = boxes_in_window(fr, 0.765, 0.895)
    green = mask_green(fr.rgb[int(fr.h * 0.25):int(fr.h * 0.72)]).mean()
    navy = fr.navy[int(fr.h * 0.13):int(fr.h * 0.28)].mean()
    black = (fr.rgb[:int(fr.h * 0.62)].max(axis=2) <= 40).mean()
    glyphs = menu_glyphs(fr)
    top_cell = cell_pair_present(fr, True)
    bot_cell = cell_pair_present(fr, False)
    if (bot or bot_cell) and green >= 0.22: return 'BANNER'
    if (top or top_cell) and navy >= 0.30: return 'STATS'
    if black >= 0.45 and glyphs: return 'MENU'
    if top or bot or top_cell or bot_cell: return 'UNKNOWN'
    return 'NONE'

def glyph_from_box(fr, box):
    ix0 = box['x0'] + int(box['w'] * 0.16); ix1 = box['x1'] - int(box['w'] * 0.16)
    iy0 = box['y0'] + int(box['h'] * 0.16); iy1 = box['y1'] - int(box['h'] * 0.16)
    if ix1 - ix0 < 4 or iy1 - iy0 < 4: return None
    sub = fr.dark[iy0:iy1, ix0:ix1] & ~fr.yellow[iy0:iy1, ix0:ix1]
    if sub.sum() < 10: return None
    return sub

def read_box_digits(fr, box):
    g = glyph_from_box(fr, box)
    if g is None: return None
    comps = [c for c in components(g, min_area=8)]
    if not comps: return None
    maxh = max(c['h'] for c in comps)
    comps = [c for c in comps if c['h'] >= maxh * 0.62]
    comps.sort(key=lambda c: c['x0'])
    digits, confs = '', []
    for c in comps:
        sub = g[c['y0']:c['y1'], c['x0']:c['x1']]
        d, dist, margin = DigitReader.best(sub)
        if d is None or dist > 0.55 or margin < 0.045: return None
        digits += str(d); confs.append(dist)
    return (int(digits), sum(confs) / len(confs)) if digits else None

def pick_score_pair(boxes, fr):
    boxes = sorted(boxes, key=lambda b: b['x0'])
    if len(boxes) >= 3:
        tries = [(boxes[0], boxes[-1]), (boxes[0], boxes[1]), (boxes[-2], boxes[-1])]
    elif len(boxes) == 2:
        tries = [(boxes[0], boxes[1])]
    else:
        return None
    for hb, ab in tries:
        hv = read_box_digits(fr, hb); av = read_box_digits(fr, ab)
        if hv and av:
            return hv[0], av[0], (hv[1] + av[1]) / 2
    return None

def read_fixed_cell(fr, x0f, x1f, y0f, y1f):
    x0, x1 = int(x0f * fr.w), int(x1f * fr.w)
    y0, y1 = int(y0f * fr.h), int(y1f * fr.h)
    cellY = fr.yellow[y0:y1, x0:x1]
    if cellY.mean() < 0.20: return None
    ys, xs = np.nonzero(cellY)
    bx0, bx1, by0, by1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    bw, bh = bx1 - bx0, by1 - by0
    if bw < 0.030 * fr.w or bh < 0.040 * fr.h: return None
    aspect = bw / max(1, bh)
    if not (0.60 <= aspect <= 1.85): return None
    if cellY[by0:by1, bx0:bx1].mean() < 0.52: return None
    ix0 = bx0 + int(bw * 0.14); ix1 = bx1 - int(bw * 0.14)
    iy0 = by0 + int(bh * 0.14); iy1 = by1 - int(bh * 0.14)
    if ix1 - ix0 < 4 or iy1 - iy0 < 4: return None
    sub = fr.dark[y0 + iy0:y0 + iy1, x0 + ix0:x0 + ix1] & ~cellY[iy0:iy1, ix0:ix1]
    if sub.sum() < 12: return None
    comps = components(sub, min_area=8)
    if not comps: return None
    maxh = max(c['h'] for c in comps)
    comps = [c for c in comps if c['h'] >= maxh * 0.60]
    comps.sort(key=lambda c: c['x0'])
    if len(comps) > 2: return None
    digits, confs = '', []
    for c in comps:
        d, dist, margin = DigitReader.best(sub[c['y0']:c['y1'], c['x0']:c['x1']])
        if d is None or dist > 0.55 or margin < 0.045: return None
        digits += str(d); confs.append(dist)
    return (int(digits), sum(confs) / len(confs)) if digits else None

def read_fixed_cells(fr, top):
    y0f, y1f = CELL_TOP_Y if top else CELL_BOT_Y
    hv = read_fixed_cell(fr, *CELL_HOME_X, y0f, y1f)
    av = read_fixed_cell(fr, *CELL_AWAY_X, y0f, y1f)
    if hv is None or av is None: return None
    return hv[0], av[0], (hv[1] + av[1]) / 2

def read_menu_score(fr):
    y0, y1 = int(fr.h * 0.105), int(fr.h * 0.245)
    x0, x1 = int(fr.w * 0.36), int(fr.w * 0.64)
    win = close3(fr.yellow[y0:y1, x0:x1])
    clusters = [c for c in components(win, min_area=60) if c['h'] >= fr.h * 0.012]
    clusters = merge_fragments(clusters) if clusters else []
    digits = [c for c in clusters if c['h'] >= fr.h * 0.055]
    if not digits: return None
    dash = [c for c in clusters if c['w'] / max(1, c['h']) > 1.35 and c['h'] < fr.h * 0.045]
    dx = (dash[0]['x0'] + dash[0]['x1']) / 2 if dash else (x1 - x0) / 2
    left = [c for c in digits if c['x1'] <= dx]; right = [c for c in digits if c['x0'] >= dx]
    def val(cs):
        parts = ''
        for c in sorted(cs, key=lambda c: c['x0']):
            d, dist, margin = DigitReader.best(win[c['y0']:c['y1'], c['x0']:c['x1']])
            if d is None or dist > 0.52 or margin < 0.045: return None
            parts += str(d)
        return int(parts) if parts else None
    hv, av = val(left), val(right)
    return None if hv is None or av is None else (hv, av)

def read_stats(fr):
    rows = []
    for i in range(13):
        cy = int((0.2944 + 0.04472 * i) * fr.h)
        y0, y1 = max(0, cy - int(0.0155 * fr.h)), min(fr.h, cy + int(0.0155 * fr.h))
        vals = []
        for x0f, x1f in ((0.218, 0.345), (0.615, 0.752)):
            x0, x1 = int(x0f * fr.w), int(x1f * fr.w)
            cell = fr.yellow[y0:y1, x0:x1]
            cw = x1 - x0
            comps = [c for c in components(cell, min_area=14)
                     if c['h'] >= 0.018 * fr.h and c['h'] <= 0.031 * fr.h and c['w'] <= 0.30 * cw]
            if not comps:
                vals.append(None); continue
            maxh = max(c['h'] for c in comps)
            comps = [c for c in comps if c['h'] >= maxh * 0.60]
            comps.sort(key=lambda c: c['x0'])
            digits = ''
            for c in comps:
                d, dist, margin = DigitReader.best(cell[c['y0']:c['y1'], c['x0']:c['x1']])
                if d is None or dist > 0.50: continue
                # 0.040: statistics digits render ~12 px on downscaled frames
                if margin < 0.040: digits = ''; break
                digits += str(d)
            vals.append(int(digits) if digits else None)
        rows.append((STAT_LABELS[i], vals[0], vals[1]))
    return rows

def read_finality(fr, stats_layout):
    if stats_layout:
        y0, y1 = int(fr.h * 0.222), int(fr.h * 0.276)
        bw0, bw1 = int(fr.w * 0.30), int(fr.w * 0.70)
        band = fr.yellow[y0:y1, bw0:bw1]
        yfrac = band.mean(axis=1)
        best_s = best_e = cur = 0
        cur = None
        for i, f in enumerate(yfrac):
            if f > 0.55:
                if cur is None: cur = i
            else:
                if cur is not None and i - cur > best_e - best_s: best_s, best_e = cur, i
                cur = None
        if cur is not None and len(yfrac) - cur > best_e - best_s: best_s, best_e = cur, len(yfrac)
        pure = [i for i in range(best_s, best_e) if yfrac[i] >= 0.92]
        if pure: best_s, best_e = pure[0], pure[-1] + 1
        if best_e <= best_s: return None
        x0, x1 = int(fr.w * 0.42), int(fr.w * 0.58)
        w = x1 - x0
        if w <= 0: return None
        text = np.zeros((y1 - y0, w), dtype=bool)
        for y in range(best_s, best_e):
            # darkness-only cut: JPEG bleeds the colour out of thin strokes
            text[y] = fr.rgb[y0 + y, x0:x1].max(axis=1) <= 150
        hh, ww = text.shape
    else:
        y0, y1 = int(fr.h * 0.030), int(fr.h * 0.095)
        x0, x1 = int(fr.w * 0.36), int(fr.w * 0.64)
        text = fr.yellow[y0:y1, x0:x1]
        hh, ww = text.shape
    if text.sum() < 30: return None
    # edge + slab cleaning
    comps = components(text, min_area=6)
    max_glyph_w = max(24, int(fr.w * 0.045))
    clean = np.zeros_like(text)
    kept = 0
    for c in comps:
        if c['y0'] == 0 or c['y1'] == hh or c['w'] > max_glyph_w: continue
        clean[c['y0']:c['y1'], c['x0']:c['x1']] |= text[c['y0']:c['y1'], c['x0']:c['x1']]
        kept += 1
    if kept == 0 or clean.sum() < 40: return None
    # largest contiguous ink-row run
    ink_rows = clean.any(axis=1)
    bs = be = 0; cs = None; gap = 0
    for i, has in enumerate(ink_rows):
        if has:
            if cs is None: cs = i
            gap = 0
        elif cs is not None:
            gap += 1
            if gap > 2:
                if (i - gap + 1) - cs > be - bs: bs, be = cs, i - gap + 1
                cs = None; gap = 0
    if cs is not None and len(ink_rows) - cs > be - bs: bs, be = cs, len(ink_rows)
    if be <= bs: return None
    strip = np.zeros_like(clean)
    strip[bs:be] = clean[bs:be]
    if strip.sum() < 40: return None
    ys, xs = np.nonzero(strip)
    x0, x1 = xs.min(), xs.max() + 1
    w = x1 - x0
    prof = strip[:, x0:x1].sum(axis=0)
    inner = []
    run = 0
    for i, v in enumerate(prof):
        if v == 0: run += 1
        else:
            if run > 0 and i - run > 0: inner.append((i - run, run))
            run = 0
    if stats_layout:
        mid = [n for s, n in inner if s / w >= 0.30 and (s + n) / w <= 0.72]
        big = max(mid) if mid else 0
        if big >= 4: return 'FT'
        if big <= 2: return 'HT'
        return None
    comps2 = [c for c in components(strip, min_area=8) if c['h'] >= 4]
    if not comps2: return None
    heights = sorted(c['h'] for c in comps2)
    spread = (heights[-1] - heights[0]) / max(1, heights[-1])
    midgap = max([n for s, n in inner if s / w >= 0.30 and (s + n) / w <= 0.70] or [0])
    aspect = w / (ys.max() - ys.min() + 1)
    if spread <= 0.25 and aspect <= 4.1: return 'HT'
    if midgap >= 5 and aspect >= 4.2: return 'FT'
    return None

def read_frame(fr):
    layout = classify(fr)
    home = away = None
    finality = None
    stats = None
    if layout == 'BANNER':
        score = pick_score_pair(boxes_in_window(fr, 0.765, 0.895), fr) or read_fixed_cells(fr, False)
        if score: home, away = score[0], score[1]
    elif layout == 'STATS':
        score = pick_score_pair(boxes_in_window(fr, 0.105, 0.245), fr) or read_fixed_cells(fr, True)
        if score: home, away = score[0], score[1]
        stats = read_stats(fr)
        finality = read_finality(fr, True)
    elif layout == 'MENU':
        score = read_menu_score(fr)
        if score: home, away = score
        finality = read_finality(fr, False)
    elif layout == 'UNKNOWN':
        score = (pick_score_pair(boxes_in_window(fr, 0.105, 0.245), fr)
                 or read_fixed_cells(fr, True)
                 or pick_score_pair(boxes_in_window(fr, 0.765, 0.895), fr)
                 or read_fixed_cells(fr, False))
        if score: home, away = score[0], score[1]
    return layout, home, away, finality, stats

# ---------------------------------------------------------------------------
TRUTH = {
    'Screenshot_20260808-135907.png': ('STATS', 1, 2, 'HT',
        [(50,50),(4,3),(2,3),(0,0),(0,0),(1,1),(0,0),(37,38),(34,30),(1,0),(6,2),(0,4),(1,1)]),
    'Screenshot_20260808-140853.png': ('STATS', 4, 2, 'HT',
        [(50,50),(8,2),(6,2),(0,0),(0,0),(1,0),(0,0),(32,46),(26,40),(0,0),(5,4),(1,0),(0,2)]),
    'Screenshot_20260808-140859.png': ('MENU', 4, 2, 'HT', None),
    'Screenshot_20260905-005550.png': ('STATS', 0, 0, 'HT',
        [(54,46),(2,2),(2,1),(1,0),(0,0),(1,1),(0,1),(35,34),(29,25),(0,1),(8,5),(2,5),(1,2)]),
    'Screenshot_20260905-010207.png': ('BANNER', 0, 1, None, None),
    'Screenshot_20260905-184444.png': ('STATS', 0, 1, 'FT',
        [(55,45),(4,1),(2,1),(0,1),(0,1),(1,0),(1,0),(68,80),(55,62),(0,0),(13,11),(3,5),(0,3)]),
    'Screenshot_20260906-204840.png': ('MENU', 2, 2, 'FT', None),
}

def main():
    global TEMPLATES
    TEMPLATES = load_templates()
    print('templates parsed from DigitTemplates.kt: digits', sorted(TEMPLATES))
    failures = 0
    checks = 0
    for jpeg_q, scale in ((None, 1.0), (88, 1.0), (88, 0.75)):
        for name, truth in TRUTH.items():
            layout_t, home_t, away_t, fin_t, stats_t = truth
            path = ROOT / name
            if not path.exists():
                print(f'SKIP {name}: capture not found (place it next to the repo root)')
                continue
            t0 = time.perf_counter()
            fr = load_frame(path, jpeg_q=jpeg_q, scale=scale)
            layout, home, away, fin, stats = read_frame(fr)
            dt = (time.perf_counter() - t0) * 1000
            errs = []
            if layout != layout_t: errs.append(f'layout {layout}!={layout_t}')
            if home != home_t or away != away_t: errs.append(f'score {home}-{away}!={home_t}-{away_t}')
            if fin_t and fin != fin_t: errs.append(f'finality {fin}!={fin_t}')
            if stats_t and stats:
                # A wrong value is always a failure. A refused read (None) is
                # tolerated only on downscaled frames, where the documented
                # behaviour is to fail safe rather than guess.
                for i in range(13):
                    gh, ga = stats[i][1], stats[i][2]
                    eh, ea = stats_t[i]
                    if scale >= 1.0:
                        if (gh, ga) != (eh, ea):
                            errs.append(f'stats row {i} {stats[i]} != {stats_t[i]}')
                    else:
                        if gh is not None and gh != eh: errs.append(f'stats row {i} home {gh}!={eh}')
                        if ga is not None and ga != ea: errs.append(f'stats row {i} away {ga}!={ea}')
            checks += 1
            if errs:
                failures += 1
                print(f'FAIL jpeg={jpeg_q} scale={scale} {name} {dt:6.0f}ms: ' + '; '.join(errs))
            else:
                print(f'OK   jpeg={jpeg_q} scale={scale} {name} {dt:6.0f}ms {layout} '
                      f'{home}-{away} fin={fin}')
    if checks == 0:
        print('No captures found next to the repo root; nothing to validate.')
        return
    if failures:
        raise SystemExit(f'{failures}/{checks} capture checks FAILED')
    print(f'ALL {checks} capture checks PASSED')

if __name__ == '__main__':
    main()
