#!/usr/bin/env python3
"""F32 structural regression: two-stage score reader, statistics capture,
recognise-then-read pipeline, v5 full-crop Prime frame."""
from pathlib import Path

checks = []

def has(path, needle, label):
    text = Path(path).read_text()
    if needle not in text:
        raise AssertionError(f'{label}: missing {needle!r} in {path}')
    checks.append(label)

def lacks(path, needle, label):
    text = Path(path).read_text()
    if needle in text:
        raise AssertionError(f'{label}: unexpectedly found {needle!r} in {path}')
    checks.append(label)

engine = 'app/src/main/java/com/peerlink/app/service/MatchAutomationEngine.kt'
detector = 'app/src/main/java/com/peerlink/app/service/PrimeScreenScoreDetector.kt'
reader = 'app/src/main/java/com/peerlink/app/service/ScoreScreenReader.kt'
masks = 'app/src/main/java/com/peerlink/app/service/ScorePixelMasks.kt'
templates = 'app/src/main/java/com/peerlink/app/service/DigitTemplates.kt'
prep = 'app/src/main/java/com/peerlink/app/service/ScoreVisualPreprocessor.kt'
client = 'app/src/main/java/com/peerlink/app/godmode/PrimeClient.kt'
server = 'app/src/main/java/com/peerlink/app/godmode/PrimeServer.kt'
build = 'app/build.gradle.kts'

# --- the measured colour fix -------------------------------------------------
has(prep, 'hsv[0] in 40f..75f', 'F31 orange-yellow window (15..45) is replaced by the measured eFootball yellow (~60)')
lacks(prep, 'hsv[0] in 15f..45f', 'no stale 15..45 yellow window remains')
has(prep, 'hsv[0] in 190f..290f', 'score digit navy is matched at hue ~240')

# --- two-stage reader --------------------------------------------------------
has(reader, 'enum class Layout { NONE, BANNER, STATS, MENU, UNKNOWN_SCORE }',
    'reader classifies the three result screens and an unknown-score fallback')
has(reader, 'enum class Finality { FULL_TIME, HALF_TIME }',
    'reader distinguishes Full Time from Halftime')
has(reader, 'CELL_HOME_X0 = 0.373f', 'fixed home score-box cell is pinned')
has(reader, 'CELL_AWAY_X0 = 0.505f', 'fixed away score-box cell is pinned')
has(reader, 'STAT_LABELS', 'the 13 fixed statistics rows are named')
has(reader, "'Possession', \"Total Shots\", 'Shots on Target'".replace("'", '"'),
    'statistics labels include Possession/Total Shots/Shots on Target')
has(reader, 'MIN_MARGIN = 0.045f', 'ambiguous glyphs are gated by a second-best margin')
has(reader, 'MIN_MARGIN_STAT = 0.040f', 'statistics digits use a slightly softer margin')
has(reader, 'cellPairPresent', 'fixed-cell yellow presence rescues merged-box frames')
has(reader, 'big >= 4 -> Finality.FULL_TIME', 'stats label: a mid word-gap means Full Time')
has(reader, 'big <= 2 -> Finality.HALF_TIME', 'stats label: no mid gap means Halftime')
has(reader, 'else -> null   // small scales shrink the gap; refuse, never guess',
    'an ambiguous 3px word gap refuses to guess')
has(reader, 'spread <= 0.25f && aspect <= 4.1f -> Finality.HALF_TIME',
    'menu clock digits (45:00) are recognised by uniform height')
has(masks, 'fun close3(', '3x3 closing bridges hairline glyph gaps')
has(masks, 'fun mergeFragments(', 'stacked/side-by-side fragment merging exists')
has(masks, 'r >= 140 && g >= 120 && b <= 120', 'yellow mask matches measured rgb(216..240,216..240,0)')

# --- frozen templates --------------------------------------------------------
for d in range(10):
    has(templates, f'{d} to intArrayOf(0x', f'template digit {d} is frozen in the table')
has(templates, 'fun best(glyph: BooleanArray): Match?', 'template matcher entry point exists')

# --- detector wiring ---------------------------------------------------------
has(detector, 'fun analyzeFrame(frame: CapturedFrame): Analysis?', 'detector exposes full analysis (score + layout + finality + stats)')
has(detector, 'mlKitFallback(frame)', 'ML Kit remains as a fallback path only')
has(detector, 'reading.layout != ScoreScreenReader.Layout.NONE', 'fallback runs only on recognised screens')
has(detector, 'fullCrop = true', 'v5 full-crop frames are marked for the reader')
has(detector, 'latch.await(1_200L', 'fallback OCR wait is shorter than the F31 1.8 s')

# --- v5 Prime protocol -------------------------------------------------------
has(server, 'makeFullCropScoreFrame', 'Prime builds the full-height central crop for v5')
has(server, 'if (requestedVersion >= 5) return makeFullCropScoreFrame', 'v4 band path stays for resident old APKs')
has(server, "if (frame.version >= 5) put(\"v\", 5)", 'v5 responses are versioned')
has(client, 'put("v", 5)', 'the app requests the v5 statistics-capable frame')
has(client, 'val version: Int = 4', 'old daemons default to v4 parsing')
lacks(server, 'rawWidth > 0.60f', 'no accidental widening of the v4 band crop')

# --- engine: statistics + settle rules ---------------------------------------
has(engine, 'lastStatsCandidate: List<ScoreScreenReader.StatRow>?', 'engine tracks the statistics candidate')
has(engine, 'statsCandidateHits', 'statistics need repeated reads before attachment')
has(engine, 'statsConfirmedLocked', 'statistics attach only after two agreeing full-table reads')
has(engine, 'Finality.HALF_TIME', 'halftime statistics screens never settle the match')
has(engine, "Halftime statistics screen seen", 'halftime observation is logged')
has(engine, 'commitDetectedScore(score, "auto", generation, burst, analysis.stats)', 'stats ride along on the automatic commit')
has(engine, '[MATCH-STAT] ', 'statistics rows are written to the match log')
has(engine, 'PrimeScreenScoreDetector.analyzeFrame(frame)', 'engine consumes the fast analysis path')
lacks(engine, 'PrimeScreenScoreDetector.detectFrame(frame)', 'the engine no longer pushes every frame through ML Kit')
has(engine, 'autoCandidateHits >= 2', 'automatic settlement still needs two matching reads')
has(build, '5.0.8-f32', 'build version is bumped to F32')

print(f'F32 score reader regression PASS {len(checks)}/{len(checks)}')
for c in checks:
    print('PASS ' + c)
