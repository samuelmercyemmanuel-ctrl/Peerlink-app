# PeerLink F32 validation record

## Real supplied captures — full pipeline replica

`tests/f32_score_reader_replica.py` parses the frozen templates straight out of
`DigitTemplates.kt` and re-runs the complete reader (classification, score,
statistics, finality) over the seven supplied 1600x720 captures. The captures
ship at the repository root; the replica runs them as PNG, as JPEG q88
re-encode (matching the Prime transfer), and at 0.75 scale (simulating a
2400-px-wide panel).

- Native scale, PNG: **7/7 PASS** — layout, score, finality and the full
  13-row statistics table on every statistics screen.
- Native scale, JPEG q88: **7/7 PASS**.
- 0.75 scale, JPEG q88: score, layout and finality all correct; the replica
  additionally enforces that a statistics cell is never *misread* at any
  scale. Downscaled frames may refuse a read (documented fail-safe); the one
  such case is a "34" whose digits fuse into a single component under the
  simulated blur — it is rejected, never guessed.
- Suite total: **ALL 21 capture checks PASSED**.
- Per-frame latency of the replica (classify + read, Python): **9–17 ms** at
  native scale versus the F31 ~1.5 s ML Kit path — about **100× faster**.

Ground truth used: walking banner 0–1; statistics screens 1–2 (Halftime),
4–2 (Halftime), 0–0 (Halftime), 0–1 (Full Time); menus 4–2 (45:00) and 2–2
(Full Time). All statistics rows, including possession percentages with the
"%" glyph, dashes, and two-digit values, are read exactly.

## Structural regressions

- `tests/f32_match_automation_regression.py`: **PASS** — measured colour
  windows, two-stage reader, frozen templates, v5 Prime protocol, engine
  statistics attachment, halftime guard, settle-on-FT-stats rule, version bump.
- `tests/f31_match_automation_regression.py`: **53/53 PASS** (all F31 engine,
  overlay, control-channel, Prime and ledger guarantees retained).
- `tests/kotlin_structural.py`: **142 checks, 0 failures**.

## JVM unit tests (source provided, device build pending)

- `ScorePixelMasksTest` — measured colour classification (yellow/navy/dark/
  green/label shades), closing bridge, fragment merging (side-by-side and
  stacked pieces, dash separation).
- `DigitTemplatesTest` — all ten templates frozen, self-match distance 0.
- `ScoreScreenReaderTest` — plain gameplay discarded without reading; stats,
  banner and menu classification; boxed score read; fixed-cell rescue of a
  merged-box frame; statistics row read; filled-blob ambiguity fails safe;
  Full Time vs Halftime label classification.

## Template provenance

Digit templates were harvested from the supplied captures only: score-box
digits (0,1,2,4), menu digits (2,4) and statistics values covering
0–9 (0:34, 1:23, 2:16, 3:12, 4:8, 5:8, 6:6, 7:1, 8:5, 9:1 samples), merged by
majority vote into one 24x32 cell per digit. Digits 7 and 9 have a single
sample each; the validation set contains 37, 29, 68, 80, 62, 35, 13 etc., and
all read correctly, but a future capture-heavy font change would require
re-harvesting.

## Android build limitation

As with F31, a complete Gradle Android build could not be executed in this
offline environment (Gradle 8.11.1 not cached, no distribution download). The
F32 sources are structured so the reader core (`ScoreScreenReader`,
`ScorePixelMasks`, `DigitTemplates`) has no Android imports and compiles as
plain JVM Kotlin; the Android glue (`PrimeScreenScoreDetector`, `PrimeServer`,
`PrimeClient`) keeps the F31 call shapes. Physical two-phone verification of
the automatic settlement remains required before competition use.
