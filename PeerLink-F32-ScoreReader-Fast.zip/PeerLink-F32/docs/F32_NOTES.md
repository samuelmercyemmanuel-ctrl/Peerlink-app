# PeerLink F32 — recognise-then-read score capture with statistics

F32 rebuilds the F31 result-capture pipeline around the way the game actually
behaves: after the final whistle eFootball shows a fixed sequence — the
walking-pitch banner (score at the bottom), the statistics screen (score on
top, Full-Time label, 13-row table, Next button) and finally the Full-Time
menu. Only the numbers change between matches. Everything that is not one of
these screens is now discarded without any OCR, and the screens that matter
are read with deterministic, template-based digits instead of a generic OCR
pass.

## Root causes fixed from F31

1. **The yellow detector could never fire.** F31 searched hue 15..45 (orange)
   while the real eFootball scoreboard yellow measures hue ~60
   (rgb 216..240, 216..240, 0). Every score-box crop therefore came back
   empty and the reader "was unable to read the score". The masks are now the
   measured values, applied consistently in the fast reader and in the ML Kit
   fallback preprocessor (digit navy moved from hue 90..145 to the measured
   ~240).
2. **Every frame cost ~1.5 s of ML Kit OCR.** F32 adds a cheap pixel
   classifier (BANNER / STATS / MENU / unknown / none). Non-score frames are
   thrown away immediately; recognised frames are read from frozen digit
   templates in single-digit milliseconds. Measured on the supplied captures:
   9–17 ms per frame including classification, roughly 100× faster than F31.
3. **The statistics table was unreachable.** The F31 composite threw away the
   middle 38% of the display — exactly where 10 of the 13 statistics rows
   live. Prime protocol v5 now sends the central 56% column at FULL height
   (same 960 px ceiling and JPEG quality), so the whole table plus both
   scorelines and the label band are inside the frame.

## What was added

- `ScoreScreenReader.kt` — two-stage reader: layout signatures
  (green pitch + bottom box pair = BANNER, navy band + top box pair = STATS,
  black + white tiles + big yellow digits = MENU), fixed-cell and
  component-based score reading, the 13-row statistics table, and a
  font-independent Full-Time/Halftime label classifier (word-gap profile on
  the stats band; uniform digit heights for the 45:00 clock on the menu).
- `DigitTemplates.kt` — the ten digit templates harvested from the supplied
  captures (score boxes, menu digits, statistics values), frozen as bits.
  Matching uses Jaccard distance; a glyph whose best two candidates are too
  close fails its whole cell, because a wrong read must never beat a no-read.
- `ScorePixelMasks.kt` — measured colour masks, tiny-window connected
  components, 3×3 closing (bridges hairline strokes in menu digits) and
  fragment merging (menu digits split into stacked halves after JPEG).
- `MatchAutomationEngine.kt` — consumes the full analysis: the statistics
  table is attached to a commit only after two agreeing full-table reads, a
  Halftime statistics screen is logged and explicitly never settles the match,
  and a Full-Time statistics screen settles immediately — the game's third
  screen (the menu after Next) is no longer required. Manual FT, the 5:00
  gate, PPS cancellation, forfeits and disconnect attribution are unchanged.
- `PrimeServer.kt` / `PrimeClient.kt` — versioned v5 capture protocol. A
  resident v4-era daemon keeps serving the old band composite and the reader
  still understands it (score-only, degraded statistics).

## What was retained

Unrelated gameplay forwarding, tunnel policy, STUN handling, Prime
activation/restore logic, side selection, ledger rules, the single-flight ML
Kit fallback (now with corrected colour windows and a shorter 1.2 s wait), and
all F31 engine guards (two matching score reads, eFootball foreground checks,
fake-FT forfeit).

## Validation

See F32_VALIDATION.md. Host-side highlights: the full pipeline replica reads
all seven supplied captures correctly (layout, score, statistics, finality) on
PNG and JPEG q88 re-encodes at native scale, 53/53 F31 regression checks still
pass, 142/142 Kotlin structural checks pass, and the new F32 structural
regression plus JVM unit tests (ScoreScreenReaderTest, DigitTemplatesTest,
ScorePixelMasksTest) cover the classification, template matching and fail-safe
gates.

## Limits

An Android Gradle build still cannot run in the offline authoring environment
(Gradle 8.11.1 not cached, no distribution download). The reader constants
were validated on the supplied 1600x720 captures and by JPEG/downscale
simulation; other devices, HDR display variants and future game-font changes
still need a physical-device confirmation before trusting automatic
settlement. A missing or ambiguous read always degrades to "no read" — the
engine then keeps waiting for the next frame or the manual FT tap.
