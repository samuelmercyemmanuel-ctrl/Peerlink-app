# PeerLink F32

Android source for PeerLink 5.0.8-f32 (version code 11), based on F31. This update rebuilds the result capture around a recognise-then-read pipeline: frames that are not one of the three eFootball result screens are discarded without OCR, and the score, the 13-row statistics table and the Full-Time/Halftime label are read with frozen eFootball-font digit templates in a few milliseconds per frame (F31 spent ~1.5 s of ML Kit OCR per frame and could not read the score at all because its yellow detector searched the wrong hue window).

Open this directory in Android Studio. The application ID remains `com.peerlink.app`. Older source archives and patches are historical and must not be reapplied.

Build with JDK 21, Android platform 36, CMake 3.22.1 and NDK 27.0.12077973:

```sh
bash gradlew :app:testDebugUnitTest :app:assembleDebug
```

Run the host regression suite (includes the F32 capture replica over the seven supplied screenshots at the repository root):

```sh
python3 tests/run_checks.py
```

Read [F32 notes](docs/F32_NOTES.md) for the root causes fixed, the new reader architecture and the v5 Prime capture protocol, and [F32 validation](docs/F32_VALIDATION.md) for the measured results and limits.
