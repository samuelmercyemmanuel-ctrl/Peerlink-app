from pathlib import Path
import re

manager_path = Path('app/src/main/java/com/peerlink/app/godmode/GodModeManager.kt')
manager = manager_path.read_text()

flow_anchor = '    val frameStats:          StateFlow<PrimeFrameStats> = _frameStats.asStateFlow()\n'
if flow_anchor not in manager:
    raise SystemExit('F21 postfix: frameStats public-flow anchor not found')
if 'val primeLinkState:' not in manager:
    manager = manager.replace(
        flow_anchor,
        flow_anchor +
        '    val primeLinkState:      StateFlow<PrimeLinkState> = _primeLinkState.asStateFlow()\n' +
        '    val actionFeedback:      StateFlow<PrimeActionFeedback> = _actionFeedback.asStateFlow()\n',
        1,
    )

render_pattern = re.compile(
    r'    fun setRenderScale\(scale: String\) \{.*?\n    \}\n\n    fun getTargetFps',
    re.S,
)
render_replacement = '''    fun setRenderScale(scale: String) {
        val allowed = setOf("1.00", "0.90", "0.85", "0.80", "0.75", "0.70")
        if (scale !in allowed) return
        if (PrimeClient.isAlive(timeoutMs = 250) && _capabilities.value.gameDownscale) {
            publishAction("graphics_scale", PrimeActionPhase.WORKING, "Applying ${scaleLabel(scale)} render scale…")
            scope.launch {
                val ok = autoTuner?.applyScale(scale) == true
                if (ok) {
                    publishAction("graphics_scale", PrimeActionPhase.SUCCESS, "${scaleLabel(scale)} render scale verified")
                } else {
                    publishAction("graphics_scale", PrimeActionPhase.ERROR, "Android did not verify that render-scale change")
                }
            }
        } else {
            prefs().edit().putString(KEY_RENDER_SCALE, scale).apply()
            AppState.appendLog("[PRIME-GPU  ] Render scale $scale saved; will apply when Prime is active")
            publishAction("graphics_scale", PrimeActionPhase.SUCCESS, "${scaleLabel(scale)} saved for next Prime activation")
        }
    }

    private fun scaleLabel(scale: String): String =
        if (scale == "1.00") "Native" else "${(scale.toFloat() * 100).toInt()}%"

    private fun publishAction(action: String, phase: PrimeActionPhase, message: String) {
        _actionFeedback.value = PrimeActionFeedback(action, phase, message, System.currentTimeMillis())
    }

    fun clearActionFeedback() { _actionFeedback.value = PrimeActionFeedback() }

    fun getTargetFps'''
manager, n = render_pattern.subn(render_replacement, manager, count=1)
if n != 1:
    raise SystemExit(f'F21 postfix: render-scale function replacement count={n}')

recheck_pattern = re.compile(
    r'    fun recheckPerformanceCapabilities\(\) \{.*?\n    \}\n',
    re.S,
)
recheck_replacement = '''    fun recheckPerformanceCapabilities() {
        if (!PrimeClient.isAlive(timeoutMs = 300)) {
            AppState.appendLog("[PRIME-CAPS ] Recheck needs an active Prime Server")
            publishAction("capability_recheck", PrimeActionPhase.ERROR, "Prime engine is offline")
            return
        }
        if (PrimeGameplayTracker.isMatchProtected()) {
            AppState.appendLog("[PRIME-CAPS ] Recheck deferred — live P2P match protected")
            publishAction("capability_recheck", PrimeActionPhase.ERROR, "Compatibility checks are locked during a live match")
            return
        }
        publishAction("capability_recheck", PrimeActionPhase.WORKING, "Testing Android graphics backends…")
        scope.launch {
            probePerformanceCapabilities(forceGraphics = true)
            if (_capabilities.value.gameDownscale) {
                publishAction(
                    "capability_recheck",
                    PrimeActionPhase.SUCCESS,
                    "Graphics backend verified: ${_capabilities.value.graphicsBackend.name.replace('_', ' ')}"
                )
            } else {
                publishAction(
                    "capability_recheck",
                    PrimeActionPhase.ERROR,
                    "No graphics backend passed Android readback verification"
                )
            }
        }
    }

    /**
     * Foreground-service heartbeat for the detached privileged engine.
     * mDNS disappearing is not treated as server death; loopback health is the
     * authority. Recovery is throttled so OEM failures cannot create a spin loop.
     */
    fun guardianPulse() {
        if (!::appContext.isInitialized) return
        val active = AppState.isGodModeActive.get()
        val restorePending = prefs().getBoolean(KEY_RESTORE_PENDING, false)
        if (!active && !restorePending) {
            _primeLinkState.value = PrimeLinkState.IDLE
            return
        }
        if (!guardianPulseRunning.compareAndSet(false, true)) return
        scope.launch {
            try {
                if (PrimeClient.isAlive(timeoutMs = 650)) {
                    AppState.primeServerAlive = true
                    _primeLinkState.value = PrimeLinkState.CONNECTED
                    updateSetupSnapshot(primeServerAlive = true)
                    return@launch
                }

                AppState.primeServerAlive = false
                updateSetupSnapshot(primeServerAlive = false)
                _primeLinkState.value = PrimeLinkState.DEGRADED
                val now = System.currentTimeMillis()
                if (now - lastGuardianRecoveryAttemptMs < GUARDIAN_RECOVERY_COOLDOWN_MS) return@launch
                lastGuardianRecoveryAttemptMs = now
                _primeLinkState.value = PrimeLinkState.RECOVERING
                AppState.appendLog("[PRIME-GUARD] PrimeServer heartbeat lost — automatic recovery starting")

                commandGate.withPermit {
                    if (!PrimeClient.isAlive(timeoutMs = 350)) {
                        val recovered = ensurePrimeServerAlive(needBootstrap = false)
                        if (!recovered) {
                            _primeLinkState.value = PrimeLinkState.DEGRADED
                            if (active) setState(State.PRIME_MODE_ACTIVE, "Prime active · engine reconnect pending")
                            return@withPermit
                        }
                    }

                    _primeLinkState.value = PrimeLinkState.CONNECTED
                    AppState.primeServerAlive = true
                    updateSetupSnapshot(primeServerAlive = true)
                    if (AppState.isGodModeActive.get()) {
                        ensurePerformanceEngines()
                        memoryDirector?.start()
                        autoTuner?.start()
                        setState(State.PRIME_MODE_ACTIVE, "Prime Mode active · engine recovered")
                        AppState.appendLog("[PRIME-GUARD] PrimeServer recovered without user action")
                    } else if (prefs().getBoolean(KEY_RESTORE_PENDING, false)) {
                        if (restoreExactSettingsNow()) {
                            setState(State.PAIRED_IDLE, "Recovered engine and restored interrupted Prime settings")
                            LanLinkForegroundService.stop(appContext)
                        }
                    }
                }
            } catch (t: Throwable) {
                _primeLinkState.value = PrimeLinkState.DEGRADED
                AppState.appendLog("[PRIME-GUARD] Recovery pulse failed: ${t.message}")
            } finally {
                guardianPulseRunning.set(false)
            }
        }
    }
'''
manager, n = recheck_pattern.subn(recheck_replacement, manager, count=1)
if n != 1:
    raise SystemExit(f'F21 postfix: capability-recheck replacement count={n}')
manager_path.write_text(manager)

service_path = Path('app/src/main/java/com/peerlink/app/service/LanLinkForegroundService.kt')
service = service_path.read_text()
status_pattern = re.compile(
    r'    private fun startStatusLoop\(\) \{.*?\n    \}\n',
    re.S,
)
status_replacement = '''    private fun startStatusLoop() {
        statusJob = serviceScope.launch {
            while (true) {
                GodModeManager.guardianPulse()
                val link = GodModeManager.primeLinkState.value
                val status = when {
                    GodModeManager.state.value == GodModeManager.State.PRIME_MODE_ACTIVE &&
                        link == com.peerlink.app.godmode.PrimeLinkState.RECOVERING -> "Prime active · recovering engine"
                    GodModeManager.state.value == GodModeManager.State.PRIME_MODE_ACTIVE &&
                        link == com.peerlink.app.godmode.PrimeLinkState.DEGRADED -> "Prime active · engine retry pending"
                    AppState.isRunning.get() -> "Peer session active"
                    GodModeManager.state.value == GodModeManager.State.PRIME_MODE_ACTIVE -> "Prime Mode active"
                    GodModeManager.isApexMasterEnabled() -> "Prime Mode ready"
                    else -> "PeerLink ready"
                }
                updateNotification(status)
                delay(STATUS_INTERVAL_MS)
            }
        }
    }
'''
service, n = status_pattern.subn(status_replacement, service, count=1)
if n != 1:
    raise SystemExit(f'F21 postfix: guardian status-loop replacement count={n}')
service_path.write_text(service)

manifest_path = Path('app/src/main/AndroidManifest.xml')
manifest = manifest_path.read_text()
if '.service.LanLinkForegroundService' not in manifest:
    pairing_anchor = '''        <service
            android:name=".godmode.GodModePairingService"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="Maintains local ADB wireless debugging session for WiFi low-latency lock" />
        </service>
'''
    if pairing_anchor not in manifest:
        raise SystemExit('F21 postfix: pairing-service manifest anchor not found')
    guardian_decl = pairing_anchor + '''
        <!-- Keeps Prime's in-app directors alive while eFootball is foreground
             and independently supervises the detached privileged engine. -->
        <service
            android:name=".service.LanLinkForegroundService"
            android:exported="false"
            android:stopWithTask="false"
            android:foregroundServiceType="dataSync" />
'''
    manifest = manifest.replace(pairing_anchor, guardian_decl, 1)
manifest_path.write_text(manifest)

ui_path = Path('app/src/main/java/com/peerlink/app/ui/PeerLinkScreen.kt')
ui = ui_path.read_text()

# The last F21 UI patch historically had only one trailing context line, so GNU
# patch could legally fuzz that line away and place the helper block at byte 0.
# Repair that deterministically before any Kotlin-aware transformations: move
# the generated helper prefix to the intended top-level position immediately
# before PrimeStatusPill, after package/import declarations and the main UI.
misplaced_prefix = '@Composable\nprivate fun PrimeEngineStrip('
package_anchor = 'package com.peerlink.app.ui\n'
status_anchor = '@Composable private fun PrimeStatusPill(modifier: Modifier, label: String, on: Boolean) =\n'
if ui.startswith(misplaced_prefix):
    package_pos = ui.find(package_anchor)
    if package_pos <= 0:
        raise SystemExit('F21 postfix: misplaced UI helpers found but package anchor missing')
    helper_block = ui[:package_pos].rstrip() + '\n\n'
    ui = ui[package_pos:]
    if status_anchor not in ui:
        raise SystemExit('F21 postfix: PrimeStatusPill anchor missing while relocating UI helpers')
    ui = ui.replace(status_anchor, helper_block + status_anchor, 1)

# After relocation there must be exactly one helper definition and package must
# be the first declaration in the Kotlin file.
if ui.count('private fun PrimeEngineStrip(') != 1:
    raise SystemExit('F21 postfix: expected exactly one PrimeEngineStrip definition')
if not ui.startswith(package_anchor):
    raise SystemExit('F21 postfix: PeerLinkScreen package declaration is not first')

early = '''    LaunchedEffect(actionFeedback.changedAtMs) {
        if (actionFeedback.changedAtMs == 0L) return@LaunchedEffect
        if (actionFeedback.action == "graphics_scale" && actionFeedback.phase == PrimeActionPhase.ERROR) {
            renderScale = GodModeManager.getRenderScale()
        }
        if (actionFeedback.phase == PrimeActionPhase.SUCCESS || actionFeedback.phase == PrimeActionPhase.ERROR) {
            val stamp = actionFeedback.changedAtMs
            delay(3_800L)
            if (GodModeManager.actionFeedback.value.changedAtMs == stamp) GodModeManager.clearActionFeedback()
        }
    }
'''
if early not in ui:
    raise SystemExit('F21 postfix: early feedback effect not found')
ui = ui.replace(early, '', 1)

anchor = '    var autoTuner by remember { mutableStateOf(GodModeManager.isAutoTunerEnabled()) }\n'
if anchor not in ui:
    raise SystemExit('F21 postfix: Prime local-state anchor not found')
late = anchor + '''    LaunchedEffect(actionFeedback.changedAtMs) {
        if (actionFeedback.changedAtMs == 0L) return@LaunchedEffect
        if (actionFeedback.action == "graphics_scale" && actionFeedback.phase == PrimeActionPhase.ERROR) {
            renderScale = GodModeManager.getRenderScale()
        }
        if (actionFeedback.phase == PrimeActionPhase.SUCCESS || actionFeedback.phase == PrimeActionPhase.ERROR) {
            val stamp = actionFeedback.changedAtMs
            delay(3_800L)
            if (GodModeManager.actionFeedback.value.changedAtMs == stamp) GodModeManager.clearActionFeedback()
        }
    }
'''
ui = ui.replace(anchor, late, 1)

replacements = {
'''                            PrimeActionButton(
                                actionId = "capability_recheck",
                                "Recheck graphics compatibility",
                                Icons.Rounded.Autorenew,
                                feedback = actionFeedback,
''': '''                            PrimeActionButton(
                                actionId = "capability_recheck",
                                label = "Recheck graphics compatibility",
                                icon = Icons.Rounded.Autorenew,
                                feedback = actionFeedback,
''',
'''                        PrimeActionButton(
                            actionId = "art_optimize",
                            "Optimize eFootball runtime now",
                            Icons.Rounded.Bolt,
                            feedback = actionFeedback,
''': '''                        PrimeActionButton(
                            actionId = "art_optimize",
                            label = "Optimize eFootball runtime now",
                            icon = Icons.Rounded.Bolt,
                            feedback = actionFeedback,
''',
'''                            else -> PrimeActionButton(
                                actionId = "activate",
                                when {
''': '''                            else -> PrimeActionButton(
                                actionId = "activate",
                                label = when {
''',
'''                                },
                                Icons.Rounded.FlashOn,
                                feedback = actionFeedback,
''': '''                                },
                                icon = Icons.Rounded.FlashOn,
                                feedback = actionFeedback,
''',
}
for old, new in replacements.items():
    if old not in ui:
        raise SystemExit('F21 postfix: expected Kotlin call shape not found:\n' + old)
    ui = ui.replace(old, new, 1)

assert 'actionId = "capability_recheck",\n                                "Recheck' not in ui
assert 'actionId = "art_optimize",\n                            "Optimize' not in ui
assert 'actionId = "activate",\n                                when {' not in ui

ui_path.write_text(ui)

# F15's structural test intentionally rejected LanLinkForegroundService because it
# was unused at that time. F21 deliberately promotes that existing service into
# the Prime Guardian, so the invariant must now require registration instead.
structural_path = Path('tests/kotlin_structural.py')
structural = structural_path.read_text()
old_structural = '''    check("unused LanLink foreground service is not registered",
          not any(name.endswith("LanLinkForegroundService") for name in components))
'''
new_structural = '''    check("F21 guardian LanLink foreground service is registered",
          any(name.endswith("LanLinkForegroundService") for name in components))
'''
if old_structural not in structural:
    raise SystemExit('F21 postfix: obsolete LanLink structural assertion not found')
structural = structural.replace(old_structural, new_structural, 1)
structural_path.write_text(structural)

print('F21 manager/service/manifest/UI/test-contract postfix: PASS')
