# F23 bundle transport

`part00.b64` through `part08.b64` are ordered Base64 chunks of `PeerLink_F23_wire_capture_bundle.zip`.

The F23 GitHub Actions workflow concatenates them in lexical order, decodes the ZIP, and verifies SHA-256 `b72d49344776f0c68d1f254b46a1a1c75d6cbb3656d4e27e156c83a5a67b366a` before applying any F23 patch.
