from pathlib import Path

ROOT = Path('.')

def replace_once(path, old, new, label):
    p = ROOT / path
    s = p.read_text()
    count = s.count(old)
    if count != 1:
        raise SystemExit(f'{label}: expected exactly 1 match in {path}, found {count}')
    p.write_text(s.replace(old, new, 1))
    print(f'OK {label}')

replace_once(
    'app/src/main/jni/peerlink_backend.cpp',
    'constexpr size_t kUdpTraceCapacity = 0;\nconstexpr bool kPacketDiagnosticsEnabled = false;',
    '// F24: compact timing/metadata trace only. No packet payload bytes are retained.\n'
    '// 32768 six-stage events is enough for the end-of-match analysis window while\n'
    '// keeping the ring much smaller than the old 131072-event diagnostic build.\n'
    'constexpr size_t kUdpTraceCapacity = 32768;\n'
    '// Keep verbose per-flow/action text diagnostics disabled; the CSV timing ring\n'
    '// is the only packet-level diagnostic enabled in this build.\n'
    'constexpr bool kPacketDiagnosticsEnabled = false;',
    'enable compact UDP metadata trace',
)
replace_once('app/src/main/jni/peerlink_backend.cpp', '            enqueue_raw_capture(state, true, tun_buffer.data(), packet_length, t0_ns);\n', '', 'disable outbound raw-byte capture')
replace_once('app/src/main/jni/peerlink_backend.cpp', '                enqueue_raw_capture(state, false, job.bytes.data(), job.bytes.size(), write_start_ns);\n', '', 'disable inbound raw-byte capture')
replace_once(
    'app/src/main/jni/peerlink_backend.cpp',
    '    const bool capture_ok = start_raw_capture(state, raw_capture_path_str);',
    '    // F24: deliberately do not start the PCAPNG writer. Packet forwarding and\n'
    '    // timing metadata continue, but raw IP/UDP bytes are never written to disk.\n'
    '    const bool capture_ok = false;',
    'disable PCAPNG writer startup',
)
replace_once(
    'app/src/main/jni/peerlink_backend.cpp',
    '                  "[WIRE-CAP ] pcapng=%s packetBytes=full mtu=%d ring=%zux2 oldUdpTrace=off textHex=off",\n'
    '                  capture_ok ? "armed" : "unavailable", state->mtu, kRawCaptureRingCapacity);',
    '                  "[F24-TRACE] rawBytes=off udpTiming=on capacity=%zu textPacketDiagnostics=off",\n'
    '                  state->udp_trace_capacity);',
    'update native trace startup log',
)

replace_once(
    'app/src/main/java/com/peerlink/app/tunnel/NativePeerLinkBackend.kt',
    '    fun dumpUdpTrace(): String = "" // F23: superseded by full-fidelity binary PCAPNG capture.',
    '    fun dumpUdpTrace(): String {\n'
    '        val handle = nativeHandle\n'
    '        if (handle == 0L) return ""\n'
    '        return nativeDumpUdpTrace(handle)\n'
    '    }',
    'restore native UDP trace dump',
)

replace_once(
    'app/src/main/java/com/peerlink/app/service/PeerLinkVpnService.kt',
    '        @Volatile\n        private var lastRawCapturePath: String = ""',
    '        @Volatile\n        private var lastNativeUdpTraceDump: String = ""\n\n'
    '        @Volatile\n        private var lastRawCapturePath: String = ""',
    'add UDP trace cache',
)
replace_once(
    'app/src/main/java/com/peerlink/app/service/PeerLinkVpnService.kt',
    '        fun dumpNativeUdpTrace(): String = "" // F23: old timing trace disabled.',
    '        fun dumpNativeUdpTrace(): String {\n'
    '            val active = activeServiceRef?.get()\n'
    '            val liveDump = try {\n'
    '                active?.nativeBackend?.dumpUdpTrace().orEmpty()\n'
    '            } catch (_: Exception) {\n'
    '                ""\n'
    '            }\n'
    '            if (liveDump.isNotBlank()) {\n'
    '                lastNativeUdpTraceDump = liveDump\n'
    '                return liveDump\n'
    '            }\n'
    '            return lastNativeUdpTraceDump\n'
    '        }',
    'restore VPN UDP trace dump',
)
replace_once(
    'app/src/main/java/com/peerlink/app/service/PeerLinkVpnService.kt',
    '            // One bounded-lifetime private file: full raw IP bytes for the latest\n'
    '            // PeerLink session. Export copies it to Downloads as PCAPNG. Keeping\n'
    '            // capture private while live avoids scoped-storage overhead on the\n'
    '            // latency-critical path.\n'
    '            rawCaptureFile = File(filesDir, "peerlink_wire_latest.pcapng").also { file ->\n'
    '                runCatching { if (file.exists()) file.delete() }\n'
    '            }\n'
    '            lastRawCapturePath = rawCaptureFile?.absolutePath.orEmpty()',
    '            // F24: full packet-byte capture is intentionally disabled. Keep the\n'
    '            // backend path empty so no PCAPNG file or writer is created.\n'
    '            rawCaptureFile = null\n'
    '            lastRawCapturePath = ""',
    'disable Kotlin raw capture file',
)
replace_once(
    'app/src/main/java/com/peerlink/app/service/PeerLinkVpnService.kt',
    '        Thread({\n            lastRawCaptureStats = try {\n                backend?.flushRawCapture() ?: lastRawCaptureStats\n            } catch (_: Exception) {\n                lastRawCaptureStats.copy(writeErrors = lastRawCaptureStats.writeErrors + 1L)\n            }\n            AppState.appendLog(\n                "[WIRE-CAP ] pre-stop packets=${lastRawCaptureStats.packets} bytes=${lastRawCaptureStats.bytes} " +\n                    "queueDrops=${lastRawCaptureStats.queueDrops} oversized=${lastRawCaptureStats.oversizedDrops} " +\n                    "writeErrors=${lastRawCaptureStats.writeErrors} complete=${lastRawCaptureStats.complete}"\n            )\n',
    '        Thread({\n            lastNativeUdpTraceDump = try {\n                backend?.dumpUdpTrace().orEmpty().ifBlank { lastNativeUdpTraceDump }\n            } catch (_: Exception) {\n                lastNativeUdpTraceDump\n            }\n            AppState.appendLog(\n                "[F24-TRACE ] UDP timing metadata cached chars=${lastNativeUdpTraceDump.length}; raw packet bytes=off"\n            )\n',
    'cache timing trace before stop',
)
replace_once(
    'app/src/main/java/com/peerlink/app/service/PeerLinkVpnService.kt',
    '        } else {\n            startForeground(NOTIFICATION_ID, buildNotification())\n        }\n        // Re-issue the notification every 3 s so Tunneled/Passthrough counters stay live.',
    '        } else {\n            startForeground(NOTIFICATION_ID, buildNotification())\n        }\n        MatchMarkerOverlay.show(this)\n        // Re-issue the notification every 3 s so Tunneled/Passthrough counters stay live.',
    'show marker overlay with VPN',
)
replace_once(
    'app/src/main/java/com/peerlink/app/service/PeerLinkVpnService.kt',
    '                        getSystemService(NotificationManager::class.java)\n                            ?.notify(NOTIFICATION_ID, buildNotification())\n                    } catch (_: Exception) { }',
    '                        getSystemService(NotificationManager::class.java)\n                            ?.notify(NOTIFICATION_ID, buildNotification())\n                        MatchMarkerOverlay.show(this)\n                    } catch (_: Exception) { }',
    'refresh marker overlay permission state',
)
replace_once(
    'app/src/main/java/com/peerlink/app/service/PeerLinkVpnService.kt',
    '        AppState.isRunning.set(false)\n        AppState.sessionPhase.set(PeerSessionPhase.IDLE)',
    '        AppState.isRunning.set(false)\n        AppState.sessionPhase.set(PeerSessionPhase.IDLE)\n        MatchMarkerOverlay.hide()',
    'hide marker overlay on stop',
)
replace_once(
    'app/src/main/java/com/peerlink/app/service/PeerLinkVpnService.kt',
    '        val mainPi = PendingIntent.getActivity(\n            this,\n            0,\n            Intent(this, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) },\n            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,\n        )\n\n        val transportLabel = "Wi-Fi"',
    '        val mainPi = PendingIntent.getActivity(\n            this,\n            0,\n            Intent(this, MainActivity::class.java).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) },\n            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,\n        )\n        val overlayPi = PendingIntent.getActivity(\n            this,\n            41,\n            Intent(\n                android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,\n                android.net.Uri.parse("package:$packageName"),\n            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) },\n            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,\n        )\n\n        val transportLabel = "Wi-Fi"',
    'add overlay permission pending intent',
)
replace_once(
    'app/src/main/java/com/peerlink/app/service/PeerLinkVpnService.kt',
    '        return (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {\n            Notification.Builder(this, NOTIFICATION_CHANNEL_ID)\n        } else {\n            @Suppress("DEPRECATION")\n            Notification.Builder(this)\n        })\n            .setContentTitle(if (AppState.isRunning.get()) "PeerLink Active" else "PeerLink Starting")\n            .setContentText("▲▼ $pktsStr · $transportLabel")\n            .setSmallIcon(android.R.drawable.ic_menu_share)\n            .setContentIntent(mainPi)\n            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi)\n            .setOngoing(true)\n            .build()',
    '        val builder = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {\n            Notification.Builder(this, NOTIFICATION_CHANNEL_ID)\n        } else {\n            @Suppress("DEPRECATION")\n            Notification.Builder(this)\n        })\n            .setContentTitle(if (AppState.isRunning.get()) "PeerLink Active" else "PeerLink Starting")\n            .setContentText("▲▼ $pktsStr · $transportLabel")\n            .setSmallIcon(android.R.drawable.ic_menu_share)\n            .setContentIntent(mainPi)\n            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi)\n            .setOngoing(true)\n        if (!android.provider.Settings.canDrawOverlays(this)) {\n            builder.addAction(android.R.drawable.ic_menu_view, "Enable match marker", overlayPi)\n        }\n        return builder.build()',
    'add overlay permission notification action',
)

main_export_old = '''                                val raw = runCatching { PeerLinkVpnService.snapshotRawCapture() }
                                    .getOrElse { PeerLinkVpnService.Companion.RawCaptureExport(null, com.peerlink.app.tunnel.RawCaptureStats(writeErrors = 1L)) }
                                val captureOk = raw.file?.let {
                                    saveFileToDownloads(
                                        filename = "peerlink_wire_$stamp.pcapng",
                                        source = it,
                                        mimeType = "application/octet-stream",
                                    )
                                } ?: false
                                runOnUiThread {
                                    android.widget.Toast.makeText(
                                        this@MainActivity,
                                        when {
                                            !logOk || !captureOk -> "Export incomplete — check Downloads access"
                                            !raw.stats.complete -> "Wire capture saved with integrity warnings — send the match log too"
                                            else -> "Match log + full raw wire capture saved to Downloads"
                                        },
                                        android.widget.Toast.LENGTH_LONG
                                    ).show()
                                }
                                AppState.appendLog(
                                    "[EXPORT ] Match log chars=${fullLog.length} ok=$logOk; " +
                                        "PCAPNG ok=$captureOk packets=${raw.stats.packets} bytes=${raw.stats.bytes} " +
                                        "queueDrops=${raw.stats.queueDrops} oversized=${raw.stats.oversizedDrops} " +
                                        "writeErrors=${raw.stats.writeErrors} fileBytes=${raw.stats.fileBytes}"
                                )'''
main_export_new = '''                                val udpTrace = runCatching { PeerLinkVpnService.dumpNativeUdpTrace() }
                                    .getOrDefault("")
                                val traceOk = udpTrace.isBlank() ||
                                    saveLogsToDownloads("peerlink_udp_trace_$stamp.csv", udpTrace)
                                runOnUiThread {
                                    android.widget.Toast.makeText(
                                        this@MainActivity,
                                        when {
                                            !logOk || !traceOk -> "Export incomplete — check Downloads access"
                                            udpTrace.isBlank() -> "Match log saved; no UDP timing trace was available"
                                            else -> "Match log + lightweight UDP timing trace saved to Downloads"
                                        },
                                        android.widget.Toast.LENGTH_LONG
                                    ).show()
                                }
                                AppState.appendLog(
                                    "[EXPORT ] Match log chars=${fullLog.length} ok=$logOk; " +
                                        "UDP timing trace chars=${udpTrace.length} ok=$traceOk rawBytes=off"
                                )'''
replace_once('app/src/main/java/com/peerlink/app/ui/MainActivity.kt', main_export_old, main_export_new, 'restore lightweight trace export')

manifest = ROOT / 'app/src/main/AndroidManifest.xml'
s = manifest.read_text()
needle = '    <uses-permission android:name="android.permission.WAKE_LOCK" />\n'
if s.count(needle) != 1:
    raise SystemExit('overlay permission: WAKE_LOCK anchor missing/ambiguous')
s = s.replace(needle, needle + '    <!-- Manual GOAL / FT marker shown over eFootball during diagnostic sessions. -->\n    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />\n', 1)
manifest.write_text(s)
print('OK overlay permission')

overlay = ROOT / 'app/src/main/java/com/peerlink/app/service/MatchMarkerOverlay.kt'
overlay.write_text(r'''package com.peerlink.app.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.peerlink.app.core.AppState

/** Tiny manual GOAL / full-time evidence marker. No screen capture and no polling. */
object MatchMarkerOverlay {
    private val main = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var root: View? = null

    fun show(context: Context) {
        val app = context.applicationContext
        main.post {
            if (root != null) return@post
            if (!Settings.canDrawOverlays(app)) return@post
            val wm = app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@post
            val density = app.resources.displayMetrics.density
            fun dp(value: Int): Int = (value * density + 0.5f).toInt()
            val panel = LinearLayout(app).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(4), dp(4), dp(4))
                background = GradientDrawable().apply {
                    setColor(0xB8181818.toInt()); cornerRadius = dp(14).toFloat(); setStroke(dp(1), 0x66FFFFFF)
                }
            }
            fun markerButton(label: String, type: String): TextView = TextView(app).apply {
                text = label; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
                minWidth = dp(if (label == "FT") 42 else 34); minHeight = dp(34); setPadding(dp(6), 0, dp(6), 0)
                background = GradientDrawable().apply {
                    setColor(if (type == "FULL_TIME") 0xCCB71C1C.toInt() else 0xCC1E6B36.toInt()); cornerRadius = dp(10).toFloat()
                }
                setOnClickListener { mark(type) }
            }
            val goal = markerButton("G", "GOAL")
            val ft = markerButton("FT", "FULL_TIME")
            panel.addView(goal, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = dp(4) })
            panel.addView(ft)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT,
            ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(10); y = dp(86) }
            runCatching {
                wm.addView(panel, params); windowManager = wm; root = panel
                AppState.appendLog("[MANUAL-MARK] overlay=shown buttons=GOAL,FT rawBytes=off")
            }.onFailure { AppState.appendLog("[MANUAL-MARK] overlay show failed: ${it.message}") }
        }
    }

    fun hide() {
        main.post {
            val view = root ?: return@post
            runCatching { windowManager?.removeView(view) }
            root = null; windowManager = null
        }
    }

    private fun mark(type: String) {
        val wallMs = System.currentTimeMillis()
        val monoNs = System.nanoTime()
        AppState.appendLog(
            "[MANUAL-MARK] type=$type wallMs=$wallMs monoNs=$monoNs " +
                "tunneled=${AppState.tunneled.get()} passthrough=${AppState.passthrough.get()}"
        )
    }
}
''')
print('OK marker overlay file')
print('F24 light trace + manual marker applied successfully')
