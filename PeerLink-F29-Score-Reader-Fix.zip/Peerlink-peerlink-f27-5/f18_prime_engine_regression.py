from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
checks=[]

def check(name, cond):
    checks.append((name,bool(cond)))
    print(('PASS ' if cond else 'FAIL ') + name)

tracker=(root/'app/src/main/java/com/peerlink/app/core/PrimeGameplayTracker.kt').read_text()
tunnel=(root/'app/src/main/java/com/peerlink/app/tunnel/TunnelEngine.kt').read_text()
mem=(root/'app/src/main/java/com/peerlink/app/godmode/PrimeMemoryDirector.kt').read_text()
auto=(root/'app/src/main/java/com/peerlink/app/godmode/PrimeAutoTuner.kt').read_text()
manager=(root/'app/src/main/java/com/peerlink/app/godmode/GodModeManager.kt').read_text()
models=(root/'app/src/main/java/com/peerlink/app/godmode/PrimePerformanceModels.kt').read_text()
ui=(root/'app/src/main/java/com/peerlink/app/ui/PeerLinkScreen.kt').read_text()
nsd=(root/'app/src/main/java/com/peerlink/app/discovery/NsdDiscovery.kt').read_text()
pair=(root/'app/src/main/java/com/peerlink/app/network/HotspotPairing.kt').read_text()

# F17 transport must survive F18.
check('Discovery RX remains wildcard', 'bind(InetSocketAddress(null as InetAddress?, DISCOVERY_PORT))' in nsd)
check('Discovery has LAN-pinned TX socket', 'sendSocketPinnedToLan' in nsd and 'InetSocketAddress(bindAddr, 0)' in nsd)
check('Pairing RX remains wildcard', 'bind(InetSocketAddress(null as InetAddress?, PAIR_PORT))' in pair)
check('Pairing has LAN-pinned TX socket', 'sendSocketPinnedToLan' in pair and 'InetSocketAddress(bindAddr, 0)' in pair)

# Gameplay detector is driven by real tunneled UDP in both directions.
check('Gameplay tracker uses sustained bidirectional P2P', 'MIN_PPS_EACH_DIRECTION = 8' in tracker and 'MATCH_GRACE_MS = 65_000L' in tracker)
check('IPv4/IPv6 outbound UDP feeds tracker', tunnel.count('PrimeGameplayTracker.noteOutboundPeerUdp()') >= 2)
check('IPv4/IPv6 inbound UDP feeds tracker', tunnel.count('PrimeGameplayTracker.noteInboundPeerUdp()') >= 2)
check('No TCP tracker feed', 'if (parsed.protocol == PacketParser.PROTOCOL_UDP)' in tunnel)

# Memory policy: immediate safe vault + match return shield + protected current foreground.
check('Instant vault command exists', 'am freeze --sticky $GAME' in mem)
check('Immediate unvault command exists', 'am unfreeze --sticky $GAME' in mem)
check('Live match blocks vault', '!matchProtected && instantVaultEnabled()' in mem)
check('Return Shield is explicit', 'Return Shield, no freeze' in mem)
check('Temporary foreground app is protected', 'uid == foregroundUid' in mem and 'temporaryForegroundPkg' in mem)
check('PeerLink UID is protected', 'uid == peerLinkUid' in mem)
check('Game UID is protected from Cannon', 'uid == gameUid' in mem)
check('Only cached-ish apps are reclaim candidates', 'if (adj < 500)' in mem and 'if (proc.adj < 800)' in mem)
check('Memory Cannon compacts before kill where useful', 'am compact $profile' in mem and 'am kill ${shellQuote(pkg)}' in mem)
check('ZRAM compression ratio is measured', '/sys/block/zram0/mm_stat' in mem and 'orig.toFloat() / used.toFloat()' in mem)
check('Memory PSI participates in pressure', '/proc/pressure/memory' in mem and 'psiSomeAvg10' in mem)

# GPU and CPU controls remain capability-aware and user controlled.
for scale in ['1.00','0.90','0.85','0.80','0.75','0.70']:
    check(f'Render scale {scale} exposed', f'"{scale}"' in ui and f'"{scale}"' in manager)
check('No unsupported 0.95 user scale', '"0.95"' not in manager and '"0.95"' not in ui)
check('Auto and Manual graphics modes exist', 'PrimeGraphicsMode.AUTO' in ui and 'PrimeGraphicsMode.MANUAL' in ui)
check('User FPS targets are 30/60', '30 FPS' in ui and '60 FPS' in ui and 'getTargetFps' in manager)
check('Modern downscale avoids clobbering Performance mode', 'cmd game set --mode 2 --downscale' in auto)
check('Legacy downscale fallback remains', 'cmd game downscale $normalized $GAME' in auto)
check('SurfaceFlinger real frame sampling drives tuner', 'dumpsys SurfaceFlinger --timestats' in auto and 'averageFPS' in auto)
check('Auto only steps down after repeated bad samples', 'badSamples >= 2' in auto and 'nextLowerScale' in auto)
check('Manual graphics mode prevents auto override', 'graphicsMode() == PrimeGraphicsMode.AUTO' in auto)
check('Performance Game Mode is capability gated', 'gamePerformanceMode' in manager and 'cmd game mode performance' in manager)
check('ART profile/full optimizer exists', 'speed-profile' in manager and '"speed"' in manager and 'cmd package compile' in manager)
check('Capability probe drives Android/OEM-specific UI', 'PrimeCapabilities.coarse()' in manager and 'capabilities.processFreeze' in ui and 'capabilities.gameDownscale' in ui and 'capabilities.gamePerformanceMode' in ui)

# New UI organization.
for title in ['Prime Memory','Prime Graphics','Prime CPU','Prime Auto Tuner']:
    check(f'UI section {title}', f'title = "{title}"' in ui)
check('Auto tuner has independent user toggle', 'isAutoTunerEnabled' in manager and 'Adaptive tuning' in ui)
check('UI preserves non-root RAM honesty', 'cannot truly pin another app in RAM' in ui)

failed=[n for n,ok in checks if not ok]
print(f'SUMMARY checks={len(checks)} failures={len(failed)}')
if failed:
    print('FAILED: ' + ', '.join(failed))
    sys.exit(1)
