# PeerLink

The current Android application source is in **[project/](project/)**. Open that directory in Android Studio or run its Gradle wrapper there.

F27 updates packet forwarding, Wi-Fi power requests, the interface and the launcher icon. See [the F27 notes](project/docs/F27_NOTES.md) for confirmed findings and validation limits.

- [Download a release](https://github.com/EdenAlpha/Peerlink/releases)
- [F27 build and UI checks](https://github.com/EdenAlpha/Peerlink/actions/workflows/f27-build.yml)
- [Build instructions](project/README.md)

The source archives, patch files and earlier version workflows at the repository root are retained as history. F27 builds the assembled source in `project/` directly; do not apply historical patches to it.
