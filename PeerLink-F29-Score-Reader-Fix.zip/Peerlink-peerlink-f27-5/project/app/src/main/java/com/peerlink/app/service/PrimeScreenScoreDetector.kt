package com.peerlink.app.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.peerlink.app.core.AppState
import com.peerlink.app.godmode.PrimeClient
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

/**
 * Very small, on-device eFootball final-score reader.
 *
 * Prime v4 performs the expensive full-display screenshot in the privileged
 * process and returns only the two narrow score-bearing bands. The app therefore
 * decodes/OCRs roughly a third of a frame instead of a complete game frame.
 * ML Kit is kept as the recognizer because it is substantially more tolerant of
 * eFootball font/rendering changes than fixed digit templates, while geometry +
 * screen anchors keep false positives out of the statistics table.
 */
object PrimeScreenScoreDetector {
    data class Score(val home: Int, val away: Int, val source: String)

    class CapturedFrame internal constructor(
        val bitmap: Bitmap,
        val topHeight: Int,
        val gap: Int,
        val referenceHeight: Int,
    ) {
        fun recycle() {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /** Capture only. Kept separate so the 4 Hz producer is not blocked by OCR. */
    fun captureFrame(context: Context): CapturedFrame? {
        // Preferred path: Prime crops/scales before the bytes cross loopback.
        PrimeClient.captureScoreFrame()?.let { frame ->
            val bitmap = BitmapFactory.decodeByteArray(frame.bytes, 0, frame.bytes.size) ?: return@let
            if (frame.topHeight >= bitmap.height || frame.referenceHeight <= 0) {
                bitmap.recycle()
                return@let
            }
            return CapturedFrame(bitmap, frame.topHeight, frame.gap, frame.referenceHeight)
        }

        // A v3 Prime daemon can survive an APK update until reboot/recovery.
        // Keep it usable by taking the old full PNG and cropping locally.
        val png = PrimeClient.captureScreenPng() ?: captureViaLegacyPrime(context) ?: return null
        val source = BitmapFactory.decodeByteArray(png, 0, png.size) ?: return null
        return try {
            makeComposite(source)
        } finally {
            if (!source.isRecycled) source.recycle()
        }
    }

    /** OCR one already-captured compact frame. Call from a background thread. */
    fun detectFrame(frame: CapturedFrame): Score? {
        // Prime already removed most of the display. Narrow it once more to the
        // exact centre score lanes from the real eFootball result screens the
        // app supports. This is intentionally geometry-first: relying on OCR to
        // also read tiny anchor words such as "Full Time" made valid scores get
        // rejected even when the digits themselves were clear.
        val prepared = makeScoreOnlyComposite(frame) ?: return null
        return try {
            val text = recognizeBlocking(prepared.bitmap) ?: return null
            parse(text, prepared.bitmap.width, prepared.topHeight, prepared.gap, prepared.referenceHeight)
        } finally {
            if (!prepared.bitmap.isRecycled) prepared.bitmap.recycle()
        }
    }

    private data class PreparedFrame(
        val bitmap: Bitmap,
        val topHeight: Int,
        val gap: Int,
        val referenceHeight: Int,
    )

    /**
     * The supplied eFootball screens put the final score in one of two places:
     *   - centre/top: Full-Time menu and statistics screen
     *   - centre/bottom: the post-whistle players-walking banner
     *
     * Keep only those lanes. The resulting bitmap is roughly one quarter of the
     * already-small Prime composite, so ML Kit sees large score glyphs with very
     * little unrelated text and does substantially less work.
     */
    private fun makeScoreOnlyComposite(frame: CapturedFrame): PreparedFrame? {
        val source = frame.bitmap
        if (source.width < 180 || source.height < 120 || frame.referenceHeight <= 0) return null

        // Prime's v4 composite spans original X 22%..78%, top Y 0..32%, and
        // bottom Y 70%..100%. Convert the observed score lanes back into that
        // coordinate system. Deliberately keep a little margin for aspect-ratio
        // and renderer differences.
        val left = (source.width * 0.29f).toInt().coerceIn(0, source.width - 2)
        val right = (source.width * 0.71f).toInt().coerceIn(left + 1, source.width)

        val refH = frame.referenceHeight
        val topStart = (refH * 0.035f).toInt().coerceAtLeast(0)
        val topEnd = (refH * 0.265f).toInt().coerceAtMost(frame.topHeight)

        // The lower Prime band begins at original Y=70%.
        val bottomBandBase = frame.topHeight + frame.gap
        val bottomStart = (bottomBandBase + refH * 0.055f).toInt().coerceIn(0, source.height - 1)
        val bottomEnd = (bottomBandBase + refH * 0.225f).toInt().coerceIn(bottomStart + 1, source.height)

        if (topEnd <= topStart || bottomEnd <= bottomStart) return null
        val width = right - left
        val topHeight = topEnd - topStart
        val bottomHeight = bottomEnd - bottomStart
        val gap = (refH / 180).coerceIn(3, 8)
        val output = Bitmap.createBitmap(width, topHeight + gap + bottomHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(
            source,
            Rect(left, topStart, right, topEnd),
            Rect(0, 0, width, topHeight),
            null,
        )
        canvas.drawBitmap(
            source,
            Rect(left, bottomStart, right, bottomEnd),
            Rect(0, topHeight + gap, width, topHeight + gap + bottomHeight),
            null,
        )
        return PreparedFrame(output, topHeight, gap, refH)
    }

    /** One-shot helper used by the manual FT button. */
    fun captureScore(context: Context): Score? {
        val frame = captureFrame(context) ?: return null
        return try {
            detectFrame(frame)
        } finally {
            frame.recycle()
        }
    }

    /** Compatibility path for a resident v2 PrimeServer. */
    private fun captureViaLegacyPrime(context: Context): ByteArray? {
        val dir = context.externalCacheDir ?: return null
        if (!dir.exists()) runCatching { dir.mkdirs() }
        val file = java.io.File(dir, "match_score_frame.png")
        return try {
            if (!PrimeClient.captureScreenPngToPath(file.absolutePath)) return null
            if (!file.isFile || file.length() !in 64L..(12L * 1024L * 1024L)) return null
            file.readBytes()
        } catch (_: Exception) {
            null
        } finally {
            runCatching { file.delete() }
        }
    }

    /** Used by tests and by pre-v4 Prime compatibility. */
    internal fun detectScore(source: Bitmap): Score? {
        val frame = makeComposite(source) ?: return null
        return try {
            detectFrame(frame)
        } finally {
            frame.recycle()
        }
    }

    private fun makeComposite(source: Bitmap): CapturedFrame? {
        if (source.width < 400 || source.height < 240) return null

        // These bands cover all three observed eFootball result presentations:
        // top Full-Time menu, top statistics result, and the bottom walking-pitch
        // score banner. The normal top-left in-game clock/scoreboard is excluded.
        val left = (source.width * 0.22f).toInt().coerceIn(0, source.width - 2)
        val right = (source.width * 0.78f).toInt().coerceIn(left + 1, source.width)
        val topHeight = (source.height * 0.32f).toInt().coerceAtLeast(1)
        val lowerTop = (source.height * 0.70f).toInt().coerceIn(0, source.height - 1)
        val gap = (source.height / 140).coerceIn(4, 10)
        val width = right - left
        val height = topHeight + gap + (source.height - lowerTop)
        val composite = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(composite)
        canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(
            source,
            Rect(left, 0, right, topHeight),
            Rect(0, 0, width, topHeight),
            null,
        )
        canvas.drawBitmap(
            source,
            Rect(left, lowerTop, right, source.height),
            Rect(0, topHeight + gap, width, height),
            null,
        )
        return CapturedFrame(composite, topHeight, gap, source.height)
    }

    private fun recognizeBlocking(bitmap: Bitmap): Text? {
        val latch = CountDownLatch(1)
        val result = java.util.concurrent.atomic.AtomicReference<Text?>()
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener {
                result.set(it)
                latch.countDown()
            }
            .addOnFailureListener {
                AppState.appendFileOnly("[MATCH-OCR ] OCR failed: ${it.message}")
                latch.countDown()
            }
        return if (latch.await(1_800L, TimeUnit.MILLISECONDS)) result.get() else null
    }

    private data class Digit(
        val value: Int,
        val x: Float,
        val y: Float,
        val height: Int,
        val region: Int,
    )

    /**
     * Parse only the two score lanes produced by [makeScoreOnlyComposite].
     * Finality is supplied by MatchAutomationEngine (post-5-minute PPS drop) or
     * by the user's explicit FT tap, so this parser must not depend on ML Kit
     * also recognizing small words such as "Full Time". That previous anchor
     * requirement was the main false-negative path on the supplied screenshots.
     */
    private fun parse(text: Text, width: Int, topHeight: Int, gap: Int, referenceHeight: Int): Score? {
        if (width <= 0 || topHeight <= 0 || referenceHeight <= 0) return null
        val minDigitHeight = max(9, (referenceHeight * 0.018f).toInt())

        fun regionForY(y: Float): Int = when {
            y <= topHeight -> 0
            y >= topHeight + gap -> 1
            else -> -1
        }

        fun normalizeScoreToken(raw: String): Int? {
            val compact = raw.trim().replace(" ", "").trim { !it.isLetterOrDigit() && it !in "|!" }
            compact.toIntOrNull()?.let { if (it in 0..20) return it }
            if (compact.length !in 1..2) return null

            val mapped = StringBuilder(compact.length)
            for (ch in compact) {
                val digit = when (ch) {
                    in '0'..'9' -> ch
                    'O', 'o', 'Q', 'q', 'D' -> '0'
                    'I', 'i', 'l', 'L', '|', '!' -> '1'
                    'Z', 'z' -> '2'
                    'S', 's' -> '5'
                    'B' -> '8'
                    else -> return null
                }
                mapped.append(digit)
            }
            return mapped.toString().toIntOrNull()?.takeIf { it in 0..20 }
        }

        // A menu score such as "2-2" is often returned as a single line/element.
        // Accept any non-score separator because the eFootball logo may be OCR'd
        // as punctuation or a letter on other result presentations.
        val scoreChars = "0-9OoQqDIilL|!ZzSsB"
        val pairRegex = Regex("^\\s*([$scoreChars]{1,2})\\s*[^$scoreChars]+\\s*([$scoreChars]{1,2})\\s*$")
        fun acceptPair(raw: String, box: Rect?): Score? {
            box ?: return null
            if (box.height() < minDigitHeight) return null
            val region = regionForY(box.exactCenterY())
            if (region < 0) return null
            val centerX = box.exactCenterX() / width.toFloat()
            if (centerX !in 0.18f..0.82f) return null
            val pair = pairRegex.matchEntire(raw) ?: return null
            val home = normalizeScoreToken(pair.groupValues[1]) ?: return null
            val away = normalizeScoreToken(pair.groupValues[2]) ?: return null
            return Score(home, away, if (region == 0) "top_pair" else "bottom_pair")
        }

        for (block in text.textBlocks) {
            for (line in block.lines) {
                acceptPair(line.text, line.boundingBox)?.let { return it }
                for (element in line.elements) {
                    acceptPair(element.text, element.boundingBox)?.let { return it }
                }
            }
        }

        // Most statistics/walking screens segment the left and right score as two
        // independent elements with the eFootball logo between them. Select the
        // biggest score-like token in the expected left/right halves of each row.
        val digits = ArrayList<Digit>(10)
        for (block in text.textBlocks) {
            for (line in block.lines) {
                for (element in line.elements) {
                    val box = element.boundingBox ?: continue
                    if (box.height() < minDigitHeight) continue
                    val value = normalizeScoreToken(element.text) ?: continue
                    val region = regionForY(box.exactCenterY())
                    if (region < 0) continue
                    val x = box.exactCenterX() / width.toFloat()
                    if (x !in 0.12f..0.88f) continue
                    digits += Digit(value, x, box.exactCenterY(), box.height(), region)
                }
            }
        }

        fun bestFor(region: Int, leftSide: Boolean): Digit? {
            val range = if (leftSide) 0.15f..0.495f else 0.505f..0.85f
            val idealX = if (leftSide) 0.34f else 0.66f
            return digits.asSequence()
                .filter { it.region == region && it.x in range }
                .maxByOrNull { it.height * 4f - abs(it.x - idealX) * 100f }
        }

        fun rowScore(region: Int): Score? {
            val home = bestFor(region, leftSide = true) ?: return null
            val away = bestFor(region, leftSide = false) ?: return null
            val dy = abs(home.y - away.y)
            val allowedDy = max(home.height, away.height) * 1.15f
            if (dy > allowedDy) return null
            val sizeRatio = minOf(home.height, away.height).toFloat() /
                max(home.height, away.height).toFloat()
            if (sizeRatio < 0.45f) return null
            return Score(home.value, away.value, if (region == 0) "top_digits" else "bottom_digits")
        }

        // The top result screens are the most stable and visually largest.
        return rowScore(0) ?: rowScore(1)
    }

}
