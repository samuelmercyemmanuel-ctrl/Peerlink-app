# PeerLink F29 Score Reader Fix

## Why F28 missed visible scores
The capture trigger and Prime screenshot path were operating, but F28's OCR acceptance rule was too strict. A frame was rejected unless OCR also recognized small final-state anchor text such as `Full Time` or the walking-screen `Online Match ... Stadium` line. On the supplied eFootball result screens, the score digits are much larger and more stable than those labels, so a valid visible score could be discarded when only the small anchor text was missed.

## F29 change
Only the score-reader implementation and its regression expectations were changed. The VPN/native forwarding path, PPS thresholds, five-minute gate, Home/Away handshake, disconnect settlement, and result-lock logic are unchanged.

The reader now:
- performs a second in-app crop on the already compact Prime score frame, retaining only the center/top and center/bottom score lanes observed in the supplied eFootball screenshots;
- no longer requires OCR to recognize `Full Time`, `Online Match`, `eFootball`, or `Stadium` before accepting score digits;
- constrains candidates by left/right score geometry instead, so statistics-table numbers outside the score positions are ignored;
- accepts either a single OCR pair such as `2-2` or two separately segmented left/right score elements around the eFootball logo;
- normalizes common OCR confusions for isolated score glyphs (`O/Q/D -> 0`, `I/l/L/|/! -> 1`, `Z -> 2`, `S -> 5`, `B -> 8`);
- keeps football score values bounded to 0..20;
- increases the per-frame OCR wait ceiling from 1.25 s to 1.8 s for low-end/cold-start cases, without adding queues or extra parallel OCR work.

## Efficiency
Prime still performs the expensive display capture outside the app and sends only its cropped JPEG. F29 then OCRs roughly one quarter of that already-small composite. The existing capacity-1 frame pipeline remains unchanged, so stale frames are recycled rather than queued and OCR cannot accumulate memory pressure.

No extra OCR engine or heavyweight dependency was added. ML Kit remains on-device and is invoked only during manual FT or the post-five-minute low-PPS capture burst.

## Validation
- F28/F29 match automation structural regression: PASS (47 checks).
- Full host check run passed through the core Kotlin/Python/Java/native suites before the long sanitizer batch exceeded the container execution window.
- F25 runtime native regression: PASS (16 checks).
- F26 Wi-Fi socket regression: PASS (38 checks).
- `PrimeScreenScoreDetector.kt` isolated Kotlin compilation with dependency stubs: PASS.
- Parser regression for `2-2`, split `0`/`1`, OCR-confused `O`/`I`, and isolated-statistic rejection: PASS.
- Full Android Gradle compilation could not be executed because Gradle 8.11.1 is not cached and this environment cannot resolve `services.gradle.org`.

## Files intentionally changed from F28
- `app/src/main/java/com/peerlink/app/service/PrimeScreenScoreDetector.kt`
- `tests/f28_match_automation_regression.py`
- `F29_FINAL_REPORT.md`
- `SOURCE_MANIFEST.sha256`
