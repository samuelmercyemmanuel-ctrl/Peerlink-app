from pathlib import Path
import re

# F22: runtime performance repair based on the first F21 real-device log.
# Goals:
# 1) keep/recover PrimeServer independently of the UI foreground state;
# 2) never report a graphics choice as applied when it was merely persisted;
# 3) let Auto Tuner observe eFootball foreground gameplay even without a PeerLink P2P session;
# 4) lower monitoring overhead during gameplay;
# 5) harden the detached shell daemon against parent/session teardown and retain diagnostics.

manager_path = Path('app/src/main/java/com/peerlink/app/godmode/GodModeManager.kt')
manager = manager_path.read_text()

anchor = '''    private val guardianPulseRunning = AtomicBoolean(false)\n    @Volatile private var lastGuardianRecoveryAttemptMs = 0L\n    private const val GUARDIAN_RECOVERY_COOLDOWN_MS = 15_000L\n'''
replacement = '''    private val guardianPulseRunning = AtomicBoolean(false)\n    @Volatile private var lastGuardianRecoveryAttemptMs = 0L\n    private var guardianJob: Job? = null\n    private const val GUARDIAN_RECOVERY_COOLDOWN_MS = 6_000L\n    private const val GUARDIAN_PULSE_MS = 2_000L\n'''
if anchor not in manager:
    raise SystemExit('F22: guardian field anchor not found')
manager = manager.replace(anchor, replacement, 1)

render_pattern = re.compile(
    r'    fun setRenderScale\(scale: String\) \{.*?\n    \}\n\n    private fun scaleLabel',
    re.S,
)
render_replacement = '''    fun setRenderScale(scale: String) {
        val allowed = setOf("1.00", "0.90", "0.85", "0.80", "0.75", "0.70")
        if (scale !in allowed) return
        prefs().edit().putString(KEY_RENDER_SCALE, scale).apply()
        publishAction("graphics_scale", PrimeActionPhase.WORKING, "Applying ${scaleLabel(scale)} render scale…")
        scope.launch {
            if (!AppState.isGodModeActive.get()) {
                publishAction(
                    "graphics_scale",
                    PrimeActionPhase.SUCCESS,
                    "${scaleLabel(scale)} saved; activate Prime before launching eFootball"
                )
                AppState.appendLog("[PRIME-GPU  ] Render scale $scale saved for next Prime activation")
                return@launch
            }

            val ready = ensurePrimeForInteractiveAction("graphics_scale")
            if (!ready) {
                publishAction(
                    "graphics_scale",
                    PrimeActionPhase.ERROR,
                    "${scaleLabel(scale)} saved, but the Prime engine could not reconnect"
                )
                return@launch
            }
            if (!_capabilities.value.gameDownscale) {
                publishAction("graphics_scale", PrimeActionPhase.ERROR, "No verified graphics backend is available")
                return@launch
            }

            val ok = autoTuner?.applyScale(scale) == true
            if (ok) {
                publishAction("graphics_scale", PrimeActionPhase.SUCCESS, "${scaleLabel(scale)} render scale verified")
            } else {
                publishAction("graphics_scale", PrimeActionPhase.ERROR, "Android did not verify that render-scale change")
            }
        }
    }

    private fun scaleLabel'''
manager, n = render_pattern.subn(render_replacement, manager, count=1)
if n != 1:
    raise SystemExit(f'F22: render setter replacement count={n}')

art_pattern = re.compile(
    r'    fun runArtOptimizationNow\(\) \{.*?\n    \}\n\n    private fun ensurePerformanceEngines',
    re.S,
)
art_replacement = '''    fun runArtOptimizationNow() {
        val mode = getArtMode()
        if (mode == PrimeArtMode.DEFAULT) return
        publishAction("art_optimize", PrimeActionPhase.WORKING, "Preparing Prime engine…")
        scope.launch {
            val ready = ensurePrimeForInteractiveAction("art_optimize")
            if (!ready) {
                AppState.appendLog("[PRIME-CPU  ] ART optimize deferred — Prime Server recovery failed")
                publishAction("art_optimize", PrimeActionPhase.ERROR, "Prime engine could not reconnect")
                return@launch
            }

            val filter = if (mode == PrimeArtMode.FULL) "speed" else "speed-profile"
            publishAction("art_optimize", PrimeActionPhase.WORKING, "Optimizing eFootball runtime…")
            setState(State.CONNECTING, "Optimizing eFootball runtime…")
            val r = executePrimeShellChecked("cmd package compile -f -m $filter $EFOOTBALL_PKG", timeoutMs = 120_000)
            if (r.ok) {
                AppState.appendLog("[PRIME-CPU  ] ART $filter optimization complete")
                publishAction("art_optimize", PrimeActionPhase.SUCCESS, "Runtime optimization completed")
            } else {
                AppState.appendLog("[PRIME-CPU  ] ART optimization failed: ${r.output.take(160)}")
                publishAction("art_optimize", PrimeActionPhase.ERROR, "Runtime optimization was rejected on this device")
            }
            if (AppState.isGodModeActive.get()) setState(State.PRIME_MODE_ACTIVE, "Prime Mode active") else syncIdleStateFromSetup()
        }
    }

    private suspend fun ensurePrimeForInteractiveAction(actionId: String): Boolean {
        if (PrimeClient.isAlive(timeoutMs = 800)) return true
        if (!AppState.isGodModeActive.get()) return false
        publishAction(actionId, PrimeActionPhase.WORKING, "Reconnecting Prime engine…")
        _primeLinkState.value = PrimeLinkState.RECOVERING
        val recovered = commandGate.withPermit {
            if (PrimeClient.isAlive(timeoutMs = 500)) true
            else ensurePrimeServerAlive(needBootstrap = !isBootstrapped())
        }
        if (recovered) {
            AppState.primeServerAlive = true
            _primeLinkState.value = PrimeLinkState.CONNECTED
            updateSetupSnapshot(primeServerAlive = true)
            startGuardianLoop()
            ensureGuardianService()
            AppState.appendLog("[PRIME-GUARD] Interactive action recovered PrimeServer")
        }
        return recovered
    }

    private fun ensurePerformanceEngines'''
manager, n = art_pattern.subn(art_replacement, manager, count=1)
if n != 1:
    raise SystemExit(f'F22: ART replacement count={n}')

needle = '''                performanceGameModeEnabled = { isCpuGameModeEnabled() },\n                applyScaleOverride = { scale ->\n'''
repl = '''                performanceGameModeEnabled = { isCpuGameModeEnabled() },\n                gameForeground = { _memorySnapshot.value.gameForeground },\n                applyScaleOverride = { scale ->\n'''
if needle not in manager:
    raise SystemExit('F22: auto tuner constructor anchor not found')
manager = manager.replace(needle, repl, 1)

guardian_anchor = '''    /**\n     * Foreground-service heartbeat for the detached privileged engine.\n'''
guardian_helpers = '''    private fun startGuardianLoop() {
        if (guardianJob?.isActive == true) return
        guardianJob = scope.launch {
            AppState.appendLog("[PRIME-GUARD] Runtime guardian started")
            while (isActive) {
                val needed = AppState.isGodModeActive.get() || prefs().getBoolean(KEY_RESTORE_PENDING, false)
                if (!needed) break
                guardianPulse()
                delay(GUARDIAN_PULSE_MS)
            }
            AppState.appendLog("[PRIME-GUARD] Runtime guardian stopped")
        }
    }

    private fun stopGuardianLoop() {
        guardianJob?.cancel()
        guardianJob = null
    }

    private fun ensureGuardianService() {
        runCatching { LanLinkForegroundService.start(appContext) }
            .onSuccess { AppState.appendLog("[PRIME-GUARD] Foreground guardian requested") }
            .onFailure { AppState.appendLog("[PRIME-GUARD] Foreground guardian start failed: ${it.message}") }
    }

'''
if guardian_anchor not in manager:
    raise SystemExit('F22: guardianPulse comment anchor not found')
manager = manager.replace(guardian_anchor, guardian_helpers + guardian_anchor, 1)

recover_anchor = '''                    _primeLinkState.value = PrimeLinkState.CONNECTED\n                    AppState.primeServerAlive = true\n                    updateSetupSnapshot(primeServerAlive = true)\n                    if (AppState.isGodModeActive.get()) {\n                        ensurePerformanceEngines()\n                        memoryDirector?.start()\n                        autoTuner?.start()\n                        setState(State.PRIME_MODE_ACTIVE, "Prime Mode active · engine recovered")\n                        AppState.appendLog("[PRIME-GUARD] PrimeServer recovered without user action")\n'''
recover_repl = '''                    _primeLinkState.value = PrimeLinkState.CONNECTED
                    AppState.primeServerAlive = true
                    updateSetupSnapshot(primeServerAlive = true)
                    if (AppState.isGodModeActive.get()) {
                        ensurePerformanceEngines()
                        memoryDirector?.start()
                        autoTuner?.start()
                        val savedScale = getRenderScale()
                        if (_capabilities.value.gameDownscale && savedScale != "1.00") {
                            val applied = autoTuner?.applyScale(savedScale) == true
                            AppState.appendLog("[PRIME-GUARD] Re-applied saved render scale $savedScale verified=$applied")
                        }
                        setState(State.PRIME_MODE_ACTIVE, "Prime Mode active · engine recovered")
                        AppState.appendLog("[PRIME-GUARD] PrimeServer recovered without user action")
'''
if recover_anchor not in manager:
    raise SystemExit('F22: guardian recovery anchor not found')
manager = manager.replace(recover_anchor, recover_repl, 1)

activation_anchor = '''        setState(State.PRIME_MODE_ACTIVE, activeStatus)\n        AppState.isGodModeActive.set(true)\n        _primeLinkState.value = PrimeLinkState.CONNECTED\n        memoryDirector?.start()\n        autoTuner?.start()\n        LanLinkForegroundService.start(appContext)\n        publishAction("activate", PrimeActionPhase.SUCCESS, "Prime Mode is active")\n'''
activation_repl = '''        setState(State.PRIME_MODE_ACTIVE, activeStatus)
        AppState.isGodModeActive.set(true)
        _primeLinkState.value = PrimeLinkState.CONNECTED
        startGuardianLoop()
        ensureGuardianService()
        memoryDirector?.start()
        autoTuner?.start()
        publishAction("activate", PrimeActionPhase.SUCCESS, "Prime Mode is active")
'''
if activation_anchor not in manager:
    raise SystemExit('F22: activation guardian anchor not found')
manager = manager.replace(activation_anchor, activation_repl, 1)

deact_anchor = '''                    _primeLinkState.value = PrimeLinkState.IDLE\n                    setState(State.PAIRED_IDLE, "Prime Mode deactivated — phone settings restored")\n                    AppState.appendLog("[PRIME-MODE ] All changed settings restored exactly")\n                    LanLinkForegroundService.stop(appContext)\n                    publishAction("deactivate", PrimeActionPhase.SUCCESS, "Prime Mode stopped and phone settings restored")\n'''
deact_repl = '''                    _primeLinkState.value = PrimeLinkState.IDLE
                    stopGuardianLoop()
                    setState(State.PAIRED_IDLE, "Prime Mode deactivated — phone settings restored")
                    AppState.appendLog("[PRIME-MODE ] All changed settings restored exactly")
                    LanLinkForegroundService.stop(appContext)
                    publishAction("deactivate", PrimeActionPhase.SUCCESS, "Prime Mode stopped and phone settings restored")
'''
if deact_anchor not in manager:
    raise SystemExit('F22: deactivation anchor not found')
manager = manager.replace(deact_anchor, deact_repl, 1)

manager_path.write_text(manager)

memory_path = Path('app/src/main/java/com/peerlink/app/godmode/PrimeMemoryDirector.kt')
memory = memory_path.read_text()

memory = memory.replace(
    '''        val running: Boolean = false,\n        val matchProtected: Boolean = false,\n        val gameVaulted: Boolean = false,\n''',
    '''        val running: Boolean = false,\n        val matchProtected: Boolean = false,\n        val gameForeground: Boolean = false,\n        val gameVaulted: Boolean = false,\n''',
    1,
)
if 'val gameForeground: Boolean = false' not in memory:
    raise SystemExit('F22: memory snapshot gameForeground insertion failed')

memory = memory.replace(
    '''        private const val MONITOR_MS = 500L\n        private const val MEMORY_SAMPLE_MS = 2_000L\n''',
    '''        private const val MONITOR_MS = 750L\n        private const val UID_SAMPLE_MS = 1_500L\n        private const val MEMORY_SAMPLE_MS = 4_000L\n''',
    1,
)
if 'UID_SAMPLE_MS = 1_500L' not in memory:
    raise SystemExit('F22: memory polling constants anchor not found')

field_anchor = '''    private var lastVaultAttemptMs = 0L\n    private var lastMemorySampleMs = 0L\n    private var lastActionMs = 0L\n'''
field_repl = '''    private var lastVaultAttemptMs = 0L\n    private var lastUidSampleMs = 0L\n    private var cachedGameTop = false\n    private var lastMemorySampleMs = 0L\n    private var lastActionMs = 0L\n'''
if field_anchor not in memory:
    raise SystemExit('F22: memory state-field anchor not found')
memory = memory.replace(field_anchor, field_repl, 1)

stop_anchor = '''        lastVaultAttemptMs = 0L\n        temporaryForegroundPkg = ""\n        _snapshot.value = _snapshot.value.copy(running = false, gameVaulted = false, pressure = "Idle")\n'''
stop_repl = '''        lastVaultAttemptMs = 0L\n        lastUidSampleMs = 0L\n        cachedGameTop = false\n        temporaryForegroundPkg = ""\n        _snapshot.value = _snapshot.value.copy(running = false, gameForeground = false, gameVaulted = false, pressure = "Idle")\n'''
if stop_anchor not in memory:
    raise SystemExit('F22: memory stop anchor not found')
memory = memory.replace(stop_anchor, stop_repl, 1)

state_anchor = '''        val matchProtected = PrimeGameplayTracker.isMatchProtected(now)\n        val state = if (capabilities().uidState) readUidState(gameUid) else null\n        val gameTop = state != null && state <= 2\n        if (gameTop) seenGameTop = true\n'''
state_repl = '''        val matchProtected = PrimeGameplayTracker.isMatchProtected(now)
        if (capabilities().uidState && now - lastUidSampleMs >= UID_SAMPLE_MS) {
            lastUidSampleMs = now
            val sampledState = readUidState(gameUid)
            if (sampledState != null) cachedGameTop = sampledState <= 2
        }
        val gameTop = cachedGameTop
        if (gameTop) seenGameTop = true
'''
if state_anchor not in memory:
    raise SystemExit('F22: memory uid-state anchor not found')
memory = memory.replace(state_anchor, state_repl, 1)

snapshot_anchor = '''            running = true, matchProtected = matchProtected, gameVaulted = gameVaulted,\n'''
snapshot_repl = '''            running = true, matchProtected = matchProtected, gameForeground = cachedGameTop, gameVaulted = gameVaulted,\n'''
if snapshot_anchor not in memory:
    raise SystemExit('F22: pressure snapshot anchor not found')
memory = memory.replace(snapshot_anchor, snapshot_repl, 1)

else_anchor = '''            _snapshot.value = _snapshot.value.copy(matchProtected = matchProtected, gameVaulted = gameVaulted, protectedForeground = temporaryForegroundPkg)\n'''
else_repl = '''            _snapshot.value = _snapshot.value.copy(matchProtected = matchProtected, gameForeground = gameTop, gameVaulted = gameVaulted, protectedForeground = temporaryForegroundPkg)\n'''
if else_anchor not in memory:
    raise SystemExit('F22: lightweight snapshot anchor not found')
memory = memory.replace(else_anchor, else_repl, 1)

memory_path.write_text(memory)

auto_path = Path('app/src/main/java/com/peerlink/app/godmode/PrimeAutoTuner.kt')
auto = auto_path.read_text()
ctor_anchor = '''    private val performanceGameModeEnabled: () -> Boolean,\n    private val applyScaleOverride: (String) -> Boolean,\n'''
ctor_repl = '''    private val performanceGameModeEnabled: () -> Boolean,\n    private val gameForeground: () -> Boolean,\n    private val applyScaleOverride: (String) -> Boolean,\n'''
if ctor_anchor not in auto:
    raise SystemExit('F22: AutoTuner constructor anchor not found')
auto = auto.replace(ctor_anchor, ctor_repl, 1)

auto = auto.replace(
    '                    val active = PrimeGameplayTracker.isMatchProtected()\n',
    '                    val active = gameForeground() || PrimeGameplayTracker.isMatchProtected()\n',
    1,
)
if 'val active = gameForeground() || PrimeGameplayTracker.isMatchProtected()' not in auto:
    raise SystemExit('F22: AutoTuner active condition replacement failed')

auto = auto.replace(
    '                delay(if (PrimeGameplayTracker.isMatchProtected()) SAMPLE_MS else 3_000L)\n',
    '                delay(if (gameForeground() || PrimeGameplayTracker.isMatchProtected()) SAMPLE_MS else 3_000L)\n',
    1,
)
if 'delay(if (gameForeground() || PrimeGameplayTracker.isMatchProtected())' not in auto:
    raise SystemExit('F22: AutoTuner delay condition replacement failed')

auto_path.write_text(auto)

service_path = Path('app/src/main/java/com/peerlink/app/service/LanLinkForegroundService.kt')
service = service_path.read_text()
create_anchor = '''        installPrimeCrashHandler()\n        GodModeManager.guardianPulse()\n        startStatusLoop()\n        Log.i(TAG, "Service created")\n'''
create_repl = '''        installPrimeCrashHandler()
        AppState.appendLog("[PRIME-GUARD] Foreground guardian service created")
        GodModeManager.guardianPulse()
        startStatusLoop()
        Log.i(TAG, "Service created")
'''
if create_anchor not in service:
    raise SystemExit('F22: service create anchor not found')
service = service.replace(create_anchor, create_repl, 1)

destroy_anchor = '''    override fun onDestroy() {\n        statusJob?.cancel()\n        super.onDestroy()\n        Log.i(TAG, "Service destroyed")\n    }\n'''
destroy_repl = '''    override fun onDestroy() {
        statusJob?.cancel()
        AppState.appendLog("[PRIME-GUARD] Foreground guardian service destroyed")
        super.onDestroy()
        Log.i(TAG, "Service destroyed")
    }
'''
if destroy_anchor not in service:
    raise SystemExit('F22: service destroy anchor not found')
service = service.replace(destroy_anchor, destroy_repl, 1)
service_path.write_text(service)

starter_path = Path('app/src/main/jni/starter.cpp')
starter = starter_path.read_text()
header_anchor = '#include <termios.h>\n'
header_repl = '#include <termios.h>\n#include <signal.h>\n#include <sys/prctl.h>\n'
if header_anchor not in starter:
    raise SystemExit('F22: starter include anchor not found')
starter = starter.replace(header_anchor, header_repl, 1)

child_anchor = '''        case 0: {\n            LOGD("child");\n            setsid();\n            chdir("/");\n            int fd = open("/dev/null", O_RDWR);\n            if (fd != -1) {\n                dup2(fd, STDIN_FILENO);\n                dup2(fd, STDOUT_FILENO);\n                dup2(fd, STDERR_FILENO);\n                if (fd > 2) close(fd);\n            }\n            run_server(path, main_class, process_name, auth_token);\n        }\n'''
child_repl = '''        case 0: {
            LOGD("child");
            prctl(PR_SET_PDEATHSIG, 0);
            signal(SIGHUP, SIG_IGN);
            signal(SIGPIPE, SIG_IGN);
            if (setsid() == -1) {
                perrorf("warn: setsid failed: %s\\n", strerror(errno));
            }
            chdir("/");
            umask(077);

            int nullfd = open("/dev/null", O_RDONLY);
            if (nullfd != -1) {
                dup2(nullfd, STDIN_FILENO);
                if (nullfd > 2) close(nullfd);
            }
            int logfd = open("/data/local/tmp/peerlink_prime.log",
                             O_WRONLY | O_CREAT | O_APPEND, 0600);
            if (logfd != -1) {
                dup2(logfd, STDOUT_FILENO);
                dup2(logfd, STDERR_FILENO);
                if (logfd > 2) close(logfd);
            } else {
                int fd = open("/dev/null", O_WRONLY);
                if (fd != -1) {
                    dup2(fd, STDOUT_FILENO);
                    dup2(fd, STDERR_FILENO);
                    if (fd > 2) close(fd);
                }
            }
            run_server(path, main_class, process_name, auth_token);
        }
'''
if child_anchor not in starter:
    raise SystemExit('F22: starter child anchor not found')
starter = starter.replace(child_anchor, child_repl, 1)
starter_path.write_text(starter)

print('F22 runtime/performance repair: PASS')
