package com.peerlink.app.service

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * F34 structure-first eFootball score-screen reader.
 *
 * DESIGN CONTRACT (what makes this device-independent — the F29..F33 readers
 * trusted screen fractions measured on one phone; this reader trusts nothing
 * about WHERE an element sits, only what it LOOKS LIKE):
 *
 *  1. NO FIXED SCREEN WINDOWS. The score boxes, the label strip, the table
 *     rows, the value tokens and the menu glyphs are FOUND by structural
 *     search over the full frame; every sub-window derives from what was
 *     found (anchor-relative geometry).
 *  2. ADAPTIVE COLOUR. The UI-yellow hue is estimated per frame from the
 *     frame's own strong-chroma warm hue histogram (chroma-weighted mode,
 *     5-degree bins): UI yellow is one spectrally tight cluster, so it wins
 *     a bin even when vivid floodlit grass carries more total chroma across
 *     many bins. Masks centre on that estimate with generous absolute rails.
 *  3. INK = LOCAL CONTRAST + BLUE LEAN. Digits inside a yellow box are
 *     "significantly darker than the box" (thresholded from the box's own
 *     value distribution) and blue-leaning/neutral (b + INK_LEAN >= r,g) so
 *     yellow-navy JPEG halo can never fatten a stroke. No absolute RGB.
 *  4. AUTHORED-SCALE BOUNDS ONLY. Size gates bound what the game UI can
 *     render relative to frame height (the UI scales with display height on
 *     every device); gates are 2-6x wider than any measured device.
 *  5. FAIL-SAFE. Ambiguity refuses the read; a refused read is never a wrong
 *     read. Callers fall back to the (slow) ML Kit chain.
 *
 * Screen presentations covered (all verified against real captures):
 *  STATS_BOARD - full/halftime statistics board, score in the top banner.
 *  WALKING     - end-of-half pitch walk-out, score in the bottom banner.
 *  MENU        - result menu after tapping Next, large score under the clock.
 */
internal object ScoreBoardDetector {

    enum class ScreenType { STATS_BOARD, WALKING, MENU, OTHER }

    /** 13 fixed eFootball statistic rows, in board order. */
    val STAT_NAMES = listOf(
        "Possession", "TotalShots", "ShotsOnTarget", "Fouls", "Offsides",
        "CornerKicks", "FreeKicks", "Passes", "SuccessfulPasses", "Crosses",
        "Interceptions", "Tackles", "Saves",
    )

    class StatRow(val name: String, val home: Int, val away: Int)

    class Stats internal constructor(internal val rows: List<StatRow>) {
        val size: Int get() = rows.size
        operator fun get(name: String): Pair<Int, Int>? =
            rows.firstOrNull { it.name == name }?.let { it.home to it.away }
        fun toJsonArray(): org.json.JSONArray = org.json.JSONArray().apply {
            rows.forEach { row ->
                put(org.json.JSONObject().apply {
                    put("name", row.name)
                    put("home", row.home)
                    put("away", row.away)
                })
            }
        }

        companion object {
            fun fromJson(array: org.json.JSONArray): Stats {
                val rows = ArrayList<StatRow>(array.length())
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    val name = o.optString("name")
                    val home = o.optInt("home", -1)
                    val away = o.optInt("away", -1)
                    if (name.isNotEmpty() && home in 0..100 && away in 0..100) {
                        rows.add(StatRow(name, home, away))
                    }
                }
                return Stats(rows)
            }
        }
    }

    enum class Finality { FULL_TIME, HALF_TIME, CLOCK, UNKNOWN }

    class Detection(
        val type: ScreenType,
        val home: Int?,
        val away: Int?,
        val finality: Finality,
        val stats: Stats?,
        val gateInfo: String,
    ) {
        val score: Pair<Int, Int>? get() = if (home == null || away == null) null else home to away
        val finalScreen: Boolean get() = finality == Finality.FULL_TIME
    }

    /**
     * Kept for call-site compatibility. The structure-first reader derives
     * everything from the frame itself, so the geometry only decides whether
     * a statistics table can exist at all (legacy band composites crop it).
     */
    sealed class Geometry {
        object Full : Geometry()
        class Composite(val topHeight: Int, val gap: Int, val refHeight: Int) : Geometry()
    }

    // Tunable primitives (grid-searched over native-exact + robustness-matrix
    // objective: wrong reads = 0 hard constraint, then max clean checks).
    internal const val INK_V_CEIL = 0.52f
    internal const val INK_LEAN = 16

    // ----------------------------------------------------------------------
    // Colour masks with per-frame adaptive yellow hue.
    // ----------------------------------------------------------------------
    internal class Masks(val w: Int, val h: Int) {
        val strict = BooleanArray(w * h)   // solid yellow (bands/boxes)
        val loose = BooleanArray(w * h)    // glyph ink on navy/dark
        val v = FloatArray(w * h)
        val chroma = FloatArray(w * h)
        val hue = FloatArray(w * h)
        val r = IntArray(w * h)
        val g = IntArray(w * h)
        val b = IntArray(w * h)
        var hueY = -1f
        var strictFrac = 0f
    }

    internal fun buildMasks(pixels: IntArray, w: Int, h: Int): Masks {
        val m = Masks(w, h)
        val hue = FloatArray(w * h)
        val sat = FloatArray(w * h)
        var strictCount = 0
        val total = w * h
        for (i in 0 until total) {
            val c = pixels[i]
            val rr = (c shr 16) and 0xFF
            val gg = (c shr 8) and 0xFF
            val bb = c and 0xFF
            m.r[i] = rr; m.g[i] = gg; m.b[i] = bb
            val mx = max(rr, max(gg, bb))
            val mn = min(rr, min(gg, bb))
            val d = mx - mn
            m.chroma[i] = d.toFloat()
            m.v[i] = mx / 255f
            var hu = 0f
            if (d > 0) {
                val rm = mx == rr; val gm = mx == gg && !rm
                hu = when {
                    rm -> 60f * (gg - bb) / d
                    gm -> 60f * (bb - rr) / d + 120f
                    else -> 60f * (rr - gg) / d + 240f
                }
                if (hu < 0f) hu += 360f
            }
            hue[i] = hu
            m.hue[i] = hu
            sat[i] = if (mx > 0) d.toFloat() / mx else 0f
        }
        // --- adaptive yellow hue: chroma-weighted mode over 5-degree bins in
        // [20,100]; then the median hue within +/-[10,15] of the peak bin.
        val nb = 17
        val bins = FloatArray(nb)
        var poolSize = 0
        val poolHue = FloatArray(total)
        val poolChroma = FloatArray(total)
        for (i in 0 until total) {
            if (m.chroma[i] >= 110f && m.v[i] >= 0.35f && hue[i] >= 20f && hue[i] <= 100f) {
                val bin = ((hue[i] - 20f) / 5f).toInt().coerceIn(0, nb - 1)
                bins[bin] += m.chroma[i]
                poolHue[poolSize] = hue[i]
                poolChroma[poolSize] = m.chroma[i]
                poolSize++
            }
        }
        if (poolSize >= 150) {
            var peak = 0
            for (k in 1 until nb) if (bins[k] > bins[peak]) peak = k
            val lo = 20f + peak * 5f - 10f
            val hi = 20f + peak * 5f + 15f
            val sel = FloatArray(poolSize)
            var sn = 0
            for (k in 0 until poolSize) {
                if (poolHue[k] >= lo && poolHue[k] <= hi) { sel[sn++] = poolHue[k] }
            }
            if (sn >= 50) {
                java.util.Arrays.sort(sel, 0, sn)
                val hy = sel[sn / 2]
                if (hy in 30f..90f) m.hueY = hy
            }
        }
        if (m.hueY > 0f) {
            for (i in 0 until total) {
                var dh = abs(((hue[i] - m.hueY + 180f) % 360f) - 180f)
                if (dh <= 24f && m.chroma[i] >= 95f && m.v[i] >= 0.42f) {
                    m.strict[i] = true; strictCount++
                }
                if (dh <= 32f && m.chroma[i] >= 60f && m.v[i] >= 0.30f) {
                    m.loose[i] = true
                }
            }
        }
        m.strictFrac = strictCount.toFloat() / total
        return m
    }

    // ----------------------------------------------------------------------
    // Entry point.
    // ----------------------------------------------------------------------
    fun analyze(frame: Bitmap, geometry: Geometry): Detection? {
        val w = frame.width
        val h = frame.height
        if (w < 320 || h < 180) return null
        val pixels = IntArray(w * h)
        frame.getPixels(pixels, 0, w, 0, 0, w, h)
        val m = buildMasks(pixels, w, h)
        val info = "hueY=${m.hueY} strict=${m.strictFrac}"
        val out = Detection(ScreenType.OTHER, null, null, Finality.UNKNOWN, null, info)

        // universal pre-gate: no plausible yellow anywhere -> not a score frame
        if (m.hueY <= 0f || m.strictFrac * w * h < max(300f, 0.0004f * w * h)) return out

        // banner presentations (stats board top / walking bottom): find boxes
        for ((A, B) in findScoreBoxes(m, w, h)) {
            val hv = readBoxValue(m, A, minConf = 0.50f, minMargin = 0.04f)
            val av = readBoxValue(m, B, minConf = 0.50f, minMargin = 0.04f)
            if (hv == null || av == null) continue
            val home: Int
            val away: Int
            if (A.x0 < B.x0) { home = hv; away = av } else { home = av; away = hv }
            val strip = findStripBelow(m, A, B, h)
            var rows: List<IndexedRow>? = null
            if (strip != null) {
                rows = tableRows(m, strip.second, A, B, w, h)
            } else {
                rows = tableRows(m, max(A.y1, B.y1), A, B, w, h)
            }
            return if (rows != null && rows.size >= 4) {
                val statRows = ArrayList<StatRow>(rows.size)
                for (r in rows) {
                    if (r.index < STAT_NAMES.size) {
                        statRows.add(StatRow(STAT_NAMES[r.index], r.home, r.away))
                    }
                }
                val fin = if (strip != null) readStripLabel(m, strip, A, B) else Finality.UNKNOWN
                Detection(ScreenType.STATS_BOARD, home, away, fin, Stats(statRows), info)
            } else {
                Detection(ScreenType.WALKING, home, away, Finality.UNKNOWN, null, info)
            }
        }

        // menu presentation: big yellow digits on dark, no boxes
        val menu = findMenuScore(m, w, h)
        if (menu != null) {
            val fin = readMenuFinality(m, menu.first, menu.second)
            return Detection(ScreenType.MENU, menu.third, menu.fourth, fin, null, info)
        }
        return out
    }

    // ----------------------------------------------------------------------
    // Box type (inclusive corners).
    // ----------------------------------------------------------------------
    internal class Box(var x0: Int, var y0: Int, var x1: Int, var y1: Int, var area: Int) {
        val w: Int get() = x1 - x0 + 1
        val h: Int get() = y1 - y0 + 1
        val cy: Float get() = (y0 + y1) / 2f
    }

    // ----------------------------------------------------------------------
    // Connected components (4-neighbour flood fill, iterative).
    // ----------------------------------------------------------------------
    internal fun components(mask: BooleanArray, w: Int, h: Int, minArea: Int): ArrayList<Box> {
        val seen = BooleanArray(mask.size)
        val out = ArrayList<Box>()
        val queue = IntArray(mask.size)
        for (start in mask.indices) {
            if (!mask[start] || seen[start]) continue
            var head = 0; var tail = 0
            queue[tail++] = start
            seen[start] = true
            var bx0 = start % w; var bx1 = bx0
            var by0 = start / w; var by1 = by0
            var area = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % w; val y = p / w
                area++
                if (x < bx0) bx0 = x
                if (x > bx1) bx1 = x
                if (y < by0) by0 = y
                if (y > by1) by1 = y
                if (x > 0 && mask[p - 1] && !seen[p - 1]) { seen[p - 1] = true; queue[tail++] = p - 1 }
                if (x + 1 < w && mask[p + 1] && !seen[p + 1]) { seen[p + 1] = true; queue[tail++] = p + 1 }
                if (y > 0 && mask[p - w] && !seen[p - w]) { seen[p - w] = true; queue[tail++] = p - w }
                if (y + 1 < h && mask[p + w] && !seen[p + w]) { seen[p + w] = true; queue[tail++] = p + w }
            }
            if (area >= minArea) out.add(Box(bx0, by0, bx1, by1, area))
        }
        return out
    }

    internal fun mergeFragments(comps: List<Box>, ygap: Int, maxW: Int, maxH: Int): ArrayList<Box> {
        val sorted = comps.sortedWith(compareBy({ it.y0 }, { it.x0 }))
        val out = ArrayList<Box>()
        for (c in sorted) {
            var target: Box? = null
            for (p in out) {
                val ov = min(c.x1, p.x1) - max(c.x0, p.x0) + 1
                val minw = min(c.w, p.w)
                val gap = max(c.y0 - p.y1, p.y0 - c.y1)
                if (ov <= 0 || ov <= 0.5f * minw || gap > ygap) continue
                if (max(c.x1, p.x1) - min(c.x0, p.x0) + 1 > maxW) continue
                if (max(c.y1, p.y1) - min(c.y0, p.y0) + 1 > maxH) continue
                target = p; break
            }
            if (target != null) {
                target.x0 = min(target.x0, c.x0); target.x1 = max(target.x1, c.x1)
                target.y0 = min(target.y0, c.y0); target.y1 = max(target.y1, c.y1)
                target.area += c.area
            } else {
                out.add(Box(c.x0, c.y0, c.x1, c.y1, c.area))
            }
        }
        return out
    }

    /** Column-valley split of a glyph cluster into digit pieces. Empty
     *  columns split first (always safe: a digit has no full-height empty
     *  column); fused pieces wider than maxW go to recognition-guided
     *  valley cuts (both halves must read as digits, else min-ink fallback
     *  that downstream gates will reject). */
    internal fun splitWide(mask: BooleanArray, mw: Int, mh: Int, maxW: Int): List<Triple<BooleanArray, Int, Int>> {
        val col = IntArray(mw)
        for (y in 0 until mh) for (x in 0 until mw) if (mask[y * mw + x]) col[x]++
        val segs = ArrayList<IntArray>()
        var start = -1; var gap = 0
        for (x in 0 until mw) {
            if (col[x] > 0) { if (start < 0) start = x; gap = 0 } else if (start >= 0) {
                gap++
                if (gap >= 1) {
                    if (x - gap - start + 1 >= 2) segs.add(intArrayOf(start, x - gap))
                    start = -1
                }
            }
        }
        if (start >= 0 && mw - start >= 2) segs.add(intArrayOf(start, mw - 1))
        if (segs.size > 1) {
            return segs.map { ab ->
                val a = ab[0]; val b = ab[1]
                val sw = b - a + 1
                val sub = BooleanArray(sw * mh)
                for (y in 0 until mh) for (x in 0 until sw) sub[y * sw + x] = mask[y * mw + a + x]
                Triple(sub, sw, mh)
            }
        }
        if (mw <= maxW) return listOf(Triple(mask, mw, mh))
        // fused digits: recognition-guided valley cuts
        val out = ArrayList<Triple<BooleanArray, Int, Int>>()
        var s = 0
        while (mw - s > maxW) {
            val lo = s + max(1, (0.20f * maxW).toInt())
            val hi = min(mw - 1, s + (0.80f * (mw - s)).toInt())
            val cand = (lo..hi).toList().sortedBy { col[it] }.take(5)
            var bestCut = -1; var bestScore = -1f
            for (cut in cand) {
                if (cut - s < 2 || mw - cut < 2) continue
                var score = 0f; var ok = true
                for (piece in listOf(cut to s, mw to cut)) {
                    val a = piece.second; val b = piece.first
                    val sw = b - a
                    val sub = BooleanArray(sw * mh)
                    for (y in 0 until mh) for (x in 0 until sw) sub[y * sw + x] = mask[y * mw + a + x]
                    val rd = classifyGlyph(sub, sw, mh)
                    if (rd.digit == null || rd.confidence < 0.5f) { ok = false; break }
                    score += rd.confidence
                }
                if (ok && score > bestScore) { bestScore = score; bestCut = cut }
            }
            if (bestCut < 0) bestCut = cand.minByOrNull { col[it] } ?: lo
            if (bestCut - s <= 0) break
            val sw = bestCut - s
            val sub = BooleanArray(sw * mh)
            for (y in 0 until mh) for (x in 0 until sw) sub[y * sw + x] = mask[y * mw + s + x]
            out.add(Triple(sub, sw, mh))
            s = bestCut
        }
        if (s < mw) {
            val sw = mw - s
            val sub = BooleanArray(sw * mh)
            for (y in 0 until mh) for (x in 0 until sw) sub[y * sw + x] = mask[y * mw + s + x]
            out.add(Triple(sub, sw, mh))
        }
        return out
    }

    // ----------------------------------------------------------------------
    // Ink (local contrast + blue lean) and box threshold.
    // ----------------------------------------------------------------------
    internal fun inkMask(m: Masks, y0: Int, y1: Int, x0: Int, x1: Int, th: Float, hueInk: Float): BooleanArray {
        // Digit ink = dark, blue-leaning AND in this box's own ink-hue family
        // (or effectively neutral outline). The yellow-navy JPEG halo lives at
        // hue 55-110 and is excluded by hue family even where its blue-lean
        // gets close. All tests are relative to the frame's own colours.
        val ww = x1 - x0 + 1
        val hh = y1 - y0 + 1
        val out = BooleanArray(ww * hh)
        for (y in 0 until hh) {
            val fy = y0 + y
            for (x in 0 until ww) {
                val i = fy * m.w + x0 + x
                var dh = abs(((m.hue[i] - hueInk + 180f) % 360f) - 180f)
                if (dh > 180f) dh -= 360f
                val dhAbs = abs(dh)
                val lean = m.b[i] + INK_LEAN >= m.r[i] && m.b[i] + INK_LEAN >= m.g[i]
                out[y * ww + x] = m.v[i] <= th && lean && (dhAbs <= 40f || m.chroma[i] <= 25f)
            }
        }
        return out
    }

    /** 3-tap vertical closing: fills 1-2px horizontal cracks that JPEG noise
     *  cuts into thin strokes (a cracked-open '0' counts two holes and reads
     *  '8'). Only used in the score-box path where glyphs are ~29px; the
     *  ~16px table glyphs deform under closing and stay raw. */
    internal fun closeV(mask: BooleanArray, w: Int, h: Int): BooleanArray {
        val d = BooleanArray(mask.size)
        for (i in mask.indices) {
            val y = i / w
            d[i] = mask[i] || (y > 0 && mask[i - w]) || (y + 1 < h && mask[i + w])
        }
        val out = BooleanArray(mask.size)
        for (i in mask.indices) {
            val y = i / w
            out[i] = (d[i] && (y == 0 || d[i - w]) && (y + 1 == h || d[i + w])) || mask[i]
        }
        return out
    }

    /** (ink threshold, ink hue reference) for one box. The threshold comes
     *  from the box's own strict-yellow brightness; the hue reference is the
     *  median hue of the pixels already dark enough to be ink (the digit
     *  cores themselves), so the family follows the actual ink whatever the
     *  panel did to it. */
    internal fun boxInkRef(m: Masks, box: Box): Pair<Float, Float> {
        var sum = 0f; var n = 0
        val ths = ArrayList<Float>()
        for (y in box.y0..box.y1) for (x in box.x0..box.x1) {
            val i = y * m.w + x
            if (m.strict[i]) { sum += m.v[i]; n++; ths.add(m.v[i]) }
        }
        if (n == 0) return 0.48f to 240f
        val medV = sum / n
        val th = min(INK_V_CEIL, medV - 0.30f)
        val hues = ArrayList<Float>()
        for (y in box.y0..box.y1) for (x in box.x0..box.x1) {
            val i = y * m.w + x
            if (m.v[i] <= th) hues.add(m.hue[i])
        }
        if (hues.size < 6) return th to 240f
        hues.sort()
        return th to hues[hues.size / 2]
    }

    internal fun boxInkThreshold(m: Masks, box: Box): Float {
        var sum = 0f; var n = 0
        for (y in box.y0..box.y1) for (x in box.x0..box.x1) {
            val i = y * m.w + x
            if (m.strict[i]) { sum += m.v[i]; n++ }
        }
        if (n == 0) return 0.48f
        return min(INK_V_CEIL, sum / n - 0.30f)
    }

    // ----------------------------------------------------------------------
    // Stage A: score-box pair, found anywhere (structural).
    // ----------------------------------------------------------------------
    internal class Evidence(val ok: Boolean, val frac: Float, val glyphs: Int)

    internal fun boxDigitEvidence(m: Masks, box: Box): Evidence {
        val (th, hueInk) = boxInkRef(m, box)
        val ix0 = box.x0 + (0.14f * box.w).toInt()
        val ix1 = box.x1 - (0.14f * box.w).toInt()
        val iy0 = box.y0 + (0.14f * box.h).toInt()
        val iy1 = box.y1 - (0.14f * box.h).toInt()
        if (ix1 - ix0 < 4 || iy1 - iy0 < 4) return Evidence(false, 0f, 0)
        val closed = closeV(inkMask(m, iy0, iy1, ix0, ix1, th, hueInk), ix1 - ix0 + 1, iy1 - iy0 + 1)
        val ink = closed
        val ww = ix1 - ix0 + 1; val hh = iy1 - iy0 + 1
        var inkN = 0
        for (v in ink) if (v) inkN++
        val frac = inkN.toFloat() / (ww * hh)
        if (frac < 0.05f || frac > 0.62f) return Evidence(false, frac, 0)
        val comps = components(ink, ww, hh, 6)
        val glyphs = comps.filter { 0.25f * box.h <= it.h && it.h <= 0.95f * box.h }
        if (glyphs.isEmpty()) return Evidence(false, frac, 0)
        val boxArea = (box.w - 2 * (0.14f * box.w).toInt()) * (box.h - 2 * (0.14f * box.h).toInt())
        for (g in glyphs) if (g.area > 0.30f * max(1, boxArea)) return Evidence(false, frac, 0)
        // 8-point solidity: a real box is a FILLED rounded rectangle — yellow
        // at its four corners AND four edge midpoints. Digit glyphs fail at
        // least one sample ('0'/'8' corners, '4' left edge, ':' everywhere).
        val cs = max(3, (0.22f * min(box.w, box.h)).toInt())
        val strict = m.strict
        val bx0 = box.x0 + 1; val by0 = box.y0 + 1
        val bx1 = box.x1 - 1; val by1 = box.y1 - 1
        val my = (box.y0 + box.y1) / 2; val mx = (box.x0 + box.x1) / 2
        val probes = listOf(
            bx0 to by0, bx1 - cs to by0, bx0 to by1 - cs, bx1 - cs to by1 - cs,
            bx0 to my - cs / 2, bx1 - cs to my - cs / 2,
            mx - cs / 2 to by0, mx - cs / 2 to by1 - cs,
        )
        for ((px, py) in probes) {
            val cx0 = px.coerceIn(0, m.w - cs)
            val cy0 = py.coerceIn(0, m.h - cs)
            var n = 0; var tot = 0
            for (y in cy0 until cy0 + cs) for (x in cx0 until cx0 + cs) {
                tot++; if (strict[y * m.w + x]) n++
            }
            if (n.toFloat() / tot < 0.45f) return Evidence(false, frac, 0)
        }
        return Evidence(true, frac, glyphs.size)
    }

    internal fun findScoreBoxes(m: Masks, W: Int, H: Int): List<Pair<Box, Box>> {
        val minArea = max(30, (0.00005f * W * H).toInt())
        val comps = components(m.strict, W, H, minArea)
        data class Cand(val b: Box, val th: Float, val quality: Float)
        val cands = ArrayList<Cand>()
        for (b in comps) {
            if (b.h < max(12, 0.012f * H) || b.h > 0.15f * H) continue
            if (b.w > 0.90f * W) continue
            val asp = b.w.toFloat() / b.h
            if (asp < 0.55f || asp > 2.8f) continue
            if (b.area.toFloat() / (b.w * b.h) < 0.52f) continue
            val ev = boxDigitEvidence(m, b)
            if (ev.ok) {
                cands.add(Cand(b, 0.5f,
                    ev.frac * sqrt(b.area.toFloat()) * (1 + 0.1f * ev.glyphs)))
            }
        }
        data class PairCand(val minArea: Int, val quality: Float, val A: Box, val B: Box)
        val pairs = ArrayList<PairCand>()
        for (i in cands.indices) for (j in i + 1 until cands.size) {
            val A = cands[i]; val B = cands[j]
            val hmax = max(A.b.h, B.b.h)
            if (abs(A.b.h - B.b.h) > 0.35f * hmax) continue
            if (abs(A.b.cy - B.b.cy) > 0.35f * hmax) continue
            val gap = max(A.b.x0 - B.b.x1, B.b.x0 - A.b.x1)
            if (gap < 0.30f * min(A.b.w, B.b.w) || gap > 2.5f * min(A.b.w, B.b.w)) continue
            pairs.add(PairCand(min(A.b.area, B.b.area), A.quality + B.quality, A.b, B.b))
        }
        pairs.sortWith(compareByDescending<PairCand> { it.minArea }.thenByDescending { it.quality })
        return pairs.map { it.A to it.B }
    }

    // ----------------------------------------------------------------------
    // Stage B: read a number out of one yellow box.
    // ----------------------------------------------------------------------
    internal fun readBoxValue(m: Masks, box: Box, minConf: Float, minMargin: Float): Int? {
        val (th, hueInk) = boxInkRef(m, box)
        val ix0 = box.x0 + (0.14f * box.w).toInt()
        val ix1 = box.x1 - (0.14f * box.w).toInt()
        val iy0 = box.y0 + (0.14f * box.h).toInt()
        val iy1 = box.y1 - (0.14f * box.h).toInt()
        if (ix1 - ix0 < 4 || iy1 - iy0 < 4) return null
        val ink = closeV(inkMask(m, iy0, iy1, ix0, ix1, th, hueInk), ix1 - ix0 + 1, iy1 - iy0 + 1)
        val ww = ix1 - ix0 + 1; val hh = iy1 - iy0 + 1
        var inkN = 0
        for (v in ink) if (v) inkN++
        if (inkN < 10) return null
        var comps = components(ink, ww, hh, 5)
        comps = mergeFragments(comps, max(2, (0.12f * box.h).toInt()), box.w, box.h)
        comps = comps.filter { it.h >= 0.25f * box.h }
        if (comps.isEmpty()) return null
        val hmax = comps.maxOf { it.h }
        comps = comps.filter { it.h >= 0.62f * hmax }.sortedBy { it.x0 }
        if (comps.size > 3) return null
        val digits = StringBuilder()
        for (c in comps) {
            // reading-resolution floor: below ~8px a glyph carries no identity
            if (c.h < 8) return null
            val sw = c.x1 - c.x0 + 1
            val sub = BooleanArray(sw * c.h)
            for (y in 0 until c.h) for (x in 0 until sw) {
                sub[y * sw + x] = ink[(c.y0 - iy0 + y) * ww + (c.x0 - ix0 + x)]
            }
            for ((piece, pw, ph) in splitWide(sub, sw, c.h, (1.30f * c.h).toInt())) {
                val rd = classifyGlyph(piece, pw, ph)
                if (rd.digit == null || rd.confidence < minConf || rd.margin < minMargin) return null
                digits.append('0' + rd.digit)
            }
        }
        val s = digits.toString()
        if (s.isEmpty() || s.length > 2) return null
        return s.toIntOrNull()
    }

    // ----------------------------------------------------------------------
    // Stage C: label strip + finality.
    // ----------------------------------------------------------------------
    internal fun findStripBelow(m: Masks, A: Box, B: Box, H: Int): Pair<Int, Int>? {
        val px0 = min(A.x0, B.x0); val px1 = max(A.x1, B.x1)
        val span = px1 - px0
        val x0 = max(0, px0 - span); val x1 = min(m.w - 1, px1 + span)
        var y = max(A.y1, B.y1) + 1
        val limit = min(H, y + (3.5f * max(A.h, B.h)).toInt())
        val minRun = max(3, (0.30f * max(A.h, B.h)).toInt())
        var best: Pair<Int, Int>? = null
        var runStart = -1; var runEnd = -1; var runLen = 0
        while (y < limit) {
            var n = 0; var tot = 0
            var x = x0
            while (x <= x1) { tot++; if (m.strict[y * m.w + x]) n++; x += 2 }
            if (n.toFloat() / max(1, tot) >= 0.55f) {
                if (runStart < 0) runStart = y
                runEnd = y; runLen++
            } else {
                if (runStart >= 0 && runLen >= minRun) {
                    if (best == null || runLen > best.second - best.first + 1) best = runStart to runEnd
                }
                runStart = -1; runLen = 0
            }
            y++
        }
        if (runStart >= 0 && runLen >= minRun) {
            if (best == null || runLen > best.second - best.first + 1) best = runStart to runEnd
        }
        return best
    }

    internal fun readStripLabel(m: Masks, strip: Pair<Int, Int>, A: Box, B: Box): Finality {
        val (top, bot) = strip
        val x0 = min(A.x0, B.x0); val x1 = max(A.x1, B.x1)
        val stripH = bot - top + 1
        var sum = 0f; var n = 0
        for (y in top..bot) for (x in x0..x1) {
            val i = y * m.w + x
            if (m.strict[i]) { sum += m.v[i]; n++ }
        }
        if (n == 0) return Finality.UNKNOWN
        val th = min(0.45f, sum / n - 0.30f)
        val hues = ArrayList<Float>()
        for (y in top..bot) for (x in x0..x1) {
            val i = y * m.w + x
            if (m.v[i] <= th) hues.add(m.hue[i])
        }
        hues.sort()
        val hueInk = if (hues.size >= 6) hues[hues.size / 2] else 240f
        val closed = closeV(inkMask(m, top, bot, x0, x1, th, hueInk), x1 - x0 + 1, bot - top + 1)
        val ink = closed
        val comps = components(ink, x1 - x0 + 1, stripH, 8)
        val cands = comps.filter { 0.25f * stripH <= it.h && it.h <= 0.90f * stripH }
        if (cands.isEmpty()) return Finality.UNKNOWN
        val c = cands.minByOrNull { it.x0 } ?: return Finality.UNKNOWN
        val cw = c.x1 - c.x0 + 1; val ch = c.y1 - c.y0 + 1
        val sub = BooleanArray(cw * ch)
        for (y in 0 until ch) for (x in 0 until cw) {
            sub[y * cw + x] = ink[(c.y0 - top + y) * (x1 - x0 + 1) + (c.x0 - x0 + x)]
        }
        return classifyFH(sub, cw, ch)
    }

    // ----------------------------------------------------------------------
    // Stage D: statistics table (index-positioned rows).
    // ----------------------------------------------------------------------
    internal class IndexedRow(val index: Int, val home: Int, val away: Int)

    internal fun clusterTokens(row: List<Box>, tokGap: Int): ArrayList<Pair<Box, ArrayList<Box>>> {
        val sorted = row.sortedBy { it.x0 }
        val tokens = ArrayList<Pair<Box, ArrayList<Box>>>()
        for (c in sorted) {
            val last = tokens.lastOrNull()
            if (last != null && c.x0 - last.first.x1 <= tokGap) {
                val (tb, parts) = last
                val nb = Box(tb.x0, min(tb.y0, c.y0), max(tb.x1, c.x1), max(tb.y1, c.y1), tb.area + c.area)
                parts.add(c)
                tokens[tokens.size - 1] = nb to parts
            } else {
                tokens.add(Box(c.x0, c.y0, c.x1, c.y1, c.area) to arrayListOf(c))
            }
        }
        return tokens
    }

    internal fun occupancyLabelBand(tokenRows: List<List<Pair<Box, ArrayList<Box>>>>): Pair<Int, Int>? {
        if (tokenRows.isEmpty()) return null
        var xLo = Int.MAX_VALUE; var xHi = Int.MIN_VALUE
        for (tr in tokenRows) for ((tb, _) in tr) {
            if (tb.x0 < xLo) xLo = tb.x0
            if (tb.x1 > xHi) xHi = tb.x1
        }
        val nb = max(1, (xHi - xLo) / 4)
        val cover = IntArray(nb + 1)
        for (tr in tokenRows) for ((tb, _) in tr) {
            val a = max(0, (tb.x0 - xLo) / 4).coerceAtMost(nb)
            val b = max(0, (tb.x1 - xLo) / 4).coerceAtMost(nb)
            for (k in a..b) cover[k]++
        }
        var peak = 0
        for (cv in cover) if (cv > peak) peak = cv
        val need = max(3, (0.8f * peak).toInt())
        var bestS = 0; var bestE = 0; var curS = -1
        for (i in 0..nb) {
            if (cover[i] >= need) { if (curS < 0) curS = i }
            else {
                if (curS >= 0 && i - curS > bestE - bestS) { bestS = curS; bestE = i }
                curS = -1
            }
        }
        if (curS >= 0 && nb + 1 - curS > bestE - bestS) { bestS = curS; bestE = nb + 1 }
        if (bestE - bestS < 2) return null
        return (xLo + bestS * 4) to (xLo + bestE * 4)
    }

    internal fun tableRows(m: Masks, stripBottom: Int, A: Box, B: Box, W: Int, H: Int): List<IndexedRow>? {
        val boxH = max(A.h, B.h); val boxW = min(A.w, B.w)
        val yTop = stripBottom + max(2, (0.12f * boxH).toInt())
        if (yTop >= H - 4) return null
        val minArea = max(6, (0.000008f * W * H).toInt())
        var comps = componentsOffset(m.loose, m.w, yTop, H, minArea)
        val hlo = 0.18f * boxH; val hhi = 0.90f * boxH
        comps = comps.filter { it.h in hlo..hhi && it.w <= 1.2f * boxW }
        if (comps.size < 8) return null
        val medH = comps.map { it.h.toFloat() }.sorted()[comps.size / 2]
        val rowGap = max(3, (0.70f * medH).toInt())
        comps = comps.sortedBy { it.cy }
        val rowsList = ArrayList<ArrayList<Box>>()
        for (c in comps) {
            val last = rowsList.lastOrNull()
            if (last != null && abs(c.cy - last.last().cy) < rowGap) last.add(c)
            else rowsList.add(arrayListOf(c))
        }
        val tokenRows = rowsList.map { clusterTokens(it, max(2, (0.60f * medH).toInt())) }
        val band = occupancyLabelBand(tokenRows) ?: return null
        val (bandX0, bandX1) = band
        data class ParsedRow(val cy: Float, val home: Pair<Box, ArrayList<Box>>, val away: Pair<Box, ArrayList<Box>>)
        val parsed = ArrayList<ParsedRow>()
        for ((row, tr) in rowsList.zip(tokenRows)) {
            val cy = row.map { it.cy }.average().toFloat()
            val home = tr.filter { it.first.x1 < bandX0 }.maxByOrNull { it.first.x1 }
            val away = tr.filter { it.first.x0 > bandX1 }.minByOrNull { it.first.x0 }
            if (home != null && away != null) parsed.add(ParsedRow(cy, home, away))
        }
        if (parsed.size < 4) return null
        // trim trailing rows off the regular lattice (UI below the table)
        while (parsed.size > 4) {
            val pitches = (0 until parsed.size - 1).map { parsed[it + 1].cy - parsed[it].cy }.filter { it > 0f }
            if (pitches.isEmpty()) break
            val medPitch = pitches.sorted()[pitches.size / 2]
            if (parsed[parsed.size - 1].cy - parsed[parsed.size - 2].cy <= 1.6f * medPitch) break
            parsed.removeAt(parsed.size - 1)
        }
        // row y-lattice -> table index: one unreadable value never shifts rows
        val cys = parsed.map { it.cy }
        val pitches2 = (0 until cys.size - 1).map { cys[it + 1] - cys[it] }.filter { it > 2f }
        if (pitches2.isEmpty()) return null
        val pitch = pitches2.sorted()[pitches2.size / 2]
        val cy0 = cys[0]
        val out = ArrayList<IndexedRow>()
        for (p in parsed) {
            val idx = Math.round((p.cy - cy0) / pitch)
            if (idx > 12) continue
            val hv = tokenValue(m, p.home)
            val av = tokenValue(m, p.away)
            if (hv == null || av == null) continue
            out.add(IndexedRow(idx, hv, av))
        }
        if (out.size < 4) return null
        return out
    }

    /** components() on a sub-window of a frame-sized mask, offsetting boxes. */
    internal fun componentsOffset(mask: BooleanArray, w: Int, yFrom: Int, yTo: Int, minArea: Int): ArrayList<Box> {
        val seen = BooleanArray(mask.size)
        val out = ArrayList<Box>()
        val queue = IntArray(mask.size)
        for (start in yFrom * w until yTo * w) {
            if (!mask[start] || seen[start]) continue
            var head = 0; var tail = 0
            queue[tail++] = start; seen[start] = true
            var bx0 = start % w; var bx1 = bx0
            var by0 = start / w; var by1 = by0
            var area = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % w; val y = p / w
                area++
                if (x < bx0) bx0 = x
                if (x > bx1) bx1 = x
                if (y < by0) by0 = y
                if (y > by1) by1 = y
                if (x > 0 && mask[p - 1] && !seen[p - 1]) { seen[p - 1] = true; queue[tail++] = p - 1 }
                if (x + 1 < w && mask[p + 1] && !seen[p + 1]) { seen[p + 1] = true; queue[tail++] = p + 1 }
                if (y > yFrom && mask[p - w] && !seen[p - w]) { seen[p - w] = true; queue[tail++] = p - w }
                if (y + 1 < yTo && mask[p + w] && !seen[p + w]) { seen[p + w] = true; queue[tail++] = p + w }
            }
            if (area >= minArea) out.add(Box(bx0, by0, bx1, by1, area))
        }
        return out
    }

    // ----------------------------------------------------------------------
    // Token pieces, '%' veto, value reading.
    // ----------------------------------------------------------------------
    internal fun pctVeto(piece: BooleanArray, pw: Int, ph: Int): Boolean {
        val asp = pw.toFloat() / max(1, ph)
        if (asp > 0.85f) return true
        return asp > 0.80f && countHoles(piece, pw, ph, minHoleArea = 1) >= 2
    }

    internal fun tokenPieces(m: Masks, tb: Box, parts: List<Box>): List<Triple<BooleanArray, Int, Int>> {
        val mw = tb.x1 - tb.x0 + 1; val mh = tb.y1 - tb.y0 + 1
        val mask = BooleanArray(mw * mh)
        for (c in parts) {
            // sparse fragments (a degraded '%' sliver fills ~0.21 of its bbox;
            // real glyph parts fill >= ~0.40) never enter the union
            if (c.area.toFloat() / max(1, c.w * c.h) < 0.15f) continue
            for (y in c.y0..c.y1) for (x in c.x0..c.x1) {
                if (m.loose[y * m.w + x]) mask[(y - tb.y0) * mw + (x - tb.x0)] = true
            }
        }
        return splitWide(mask, mw, mh, (1.30f * mh).toInt())
    }

    internal fun tokenValue(m: Masks, tok: Pair<Box, ArrayList<Box>>): Int? {
        val digits = StringBuilder()
        for ((piece, pw, ph) in tokenPieces(m, tok.first, tok.second)) {
            if (pctVeto(piece, pw, ph)) continue
            val rd = classifyGlyph(piece, pw, ph)
            // 0.60 confidence: real stat digits read 0.61..1.0, compression
            // sliver junk reads ~0.51 (measured on the calibration set)
            if (rd.digit == null || rd.confidence < 0.60f || rd.margin < 0.03f) continue
            digits.append('0' + rd.digit)
        }
        val s = digits.toString()
        if (s.isEmpty() || s.length > 2) return null   // a stat value is <= 2 digits
        return s.toIntOrNull()
    }

    // ----------------------------------------------------------------------
    // Stage E: menu score.
    // ----------------------------------------------------------------------
    internal fun darkBackground(m: Masks, box: Box): Boolean {
        val r = box.h
        val x0 = max(0, box.x0 - r); val x1 = min(m.w - 1, box.x1 + r)
        val y0 = max(0, box.y0 - r); val y1 = min(m.h - 1, box.y1 + r)
        var sum = 0f; var n = 0
        for (y in y0..y1) for (x in x0..x1) {
            val inside = x in box.x0..box.x1 && y in box.y0..box.y1
            if (!inside) { sum += m.v[y * m.w + x]; n++ }
        }
        return n > 0 && sum / n <= 0.34f
    }

    internal class MenuResult(val first: Box, val second: Box, val third: Int, val fourth: Int)

    internal fun readNumberTokens(m: Masks, clusters: List<Pair<Box, ArrayList<Box>>>, medH: Float): List<Pair<Box, Int>> {
        val out = ArrayList<Pair<Box, Int>>()
        for ((tb, parts) in clusters) {
            val mw = tb.x1 - tb.x0 + 1; val mh = tb.y1 - tb.y0 + 1
            val mask = BooleanArray(mw * mh)
            for (c in parts) {
                for (y in c.y0..c.y1) for (x in c.x0..c.x1) {
                    if (m.loose[y * m.w + x]) mask[(y - tb.y0) * mw + (x - tb.x0)] = true
                }
            }
            var digits = ""
            var pure = true
            for ((piece, pw, ph) in splitWide(mask, mw, mh, (1.30f * mh).toInt())) {
                val rd = classifyGlyph(piece, pw, ph)
                if (rd.digit == null || rd.confidence < 0.45f || rd.margin < 0.02f) { pure = false; break }
                digits += ('0' + rd.digit)
            }
            if (pure && digits.length in 1..2) out.add(tb to (digits.toIntOrNull() ?: continue))
        }
        return out
    }

    internal fun findMenuScore(m: Masks, W: Int, H: Int): MenuResult? {
        val minArea = max(20, (0.00006f * W * H).toInt())
        val comps = components(m.loose, W, H, minArea)
        // component floor is an anti-speck guard in ABSOLUTE pixels; the
        // authored-scale floor lives on whole CLUSTERS further down
        val cand = comps.filter { it.h >= 6 && it.h <= 0.15f * H && it.w <= 0.5f * W && darkBackground(m, it) }
        if (cand.size < 2) return null
        val medH = cand.map { it.h.toFloat() }.sorted()[cand.size / 2]
        // merge fragments by X-OVERLAP: a bold digit splits into bowl + base
        // bar that fully overlap the digit horizontally; the score DASH
        // overlaps neither neighbour and survives as its own cluster
        val clusters = cand.map { it to arrayListOf(it) }.toMutableList()
        var changed = true
        while (changed) {
            changed = false
            val out = ArrayList<Pair<Box, ArrayList<Box>>>()
            for (cur in clusters) {
                val c = cur.first
                var target: Pair<Box, ArrayList<Box>>? = null
                for (o in out) {
                    val ov = min(c.x1, o.first.x1) - max(c.x0, o.first.x0) + 1
                    val minw = min(c.w, o.first.w)
                    val ygap = max(c.y0 - o.first.y1, o.first.y0 - c.y1)
                    if (ov < 0.5f * minw || ygap > 0.5f * medH) continue
                    if (max(c.y1, o.first.y1) - min(c.y0, o.first.y0) + 1 > 0.16f * H) continue
                    target = o; break
                }
                if (target != null) {
                    val t = target.first
                    val nb = Box(min(t.x0, c.x0), min(t.y0, c.y0), max(t.x1, c.x1), max(t.y1, c.y1), t.area + c.area)
                    out[out.indexOf(target)] = nb to (target.second + cur.second)
                    changed = true
                } else {
                    out.add(cur)
                }
            }
            clusters.clear(); clusters.addAll(out)
        }
        var dash: Box? = null
        val numberClus = ArrayList<Pair<Box, ArrayList<Box>>>()
        for (cl in clusters) {
            val tb = cl.first
            if (tb.h < 0.035f * H) continue
            if (cl.second.size == 1 && tb.w.toFloat() / max(1, tb.h) >= 1.4f && dash == null) {
                dash = tb; continue
            }
            numberClus.add(cl)
        }
        val numbers = readNumberTokens(m, numberClus, medH).toMutableList()
        if (numbers.size < 2) return null
        val maxH = numbers.maxOf { it.first.h }
        val strong = numbers.filter { it.first.h >= 0.60f * maxH }
        if (strong.size < 2) return null
        val sorted = strong.sortedBy { it.first.x0 }
        if (dash != null) {
            val left = sorted.lastOrNull { it.first.x1 < dash.x0 }
            val right = sorted.firstOrNull { it.first.x0 > dash.x1 }
            if (left != null && right != null) return MenuResult(left.first, right.first, left.second, right.second)
        }
        var best: Triple<Int, Pair<Box, Int>, Pair<Box, Int>>? = null
        for (i in sorted.indices) for (j in i + 1 until sorted.size) {
            val A = sorted[i].first; val B = sorted[j].first
            if (abs(A.h - B.h) > 0.35f * max(A.h, B.h)) continue
            val gap = B.x0 - A.x1
            if (gap < 0 || gap > 2.5f * max(A.w, B.w)) continue
            if (best == null || gap < best.first) best = Triple(gap, sorted[i], sorted[j])
        }
        best ?: return null
        return MenuResult(best.second.first, best.third.first, best.second.second, best.third.second)
    }

    internal fun readMenuFinality(m: Masks, homeBox: Box, awayBox: Box): Finality {
        val x0 = min(homeBox.x0, awayBox.x0)
        val x1 = max(homeBox.x1, awayBox.x1)
        val gh = max(homeBox.h, awayBox.h)
        val y1 = min(homeBox.y0, awayBox.y0) - 1
        val y0 = max(0, y1 - (2.0f * gh).toInt())
        if (y1 - y0 < 4) return Finality.UNKNOWN
        val ww = x1 - x0 + 1; val wh = y1 - y0 + 1
        val win = BooleanArray(ww * wh)
        for (y in 0 until wh) for (x in 0 until ww) win[y * ww + x] = m.loose[(y0 + y) * m.w + x0 + x]
        val comps = components(win, ww, wh, 8)
        val cands = comps.filter { 0.10f * gh <= it.h && it.h <= 0.90f * gh }
        if (cands.isEmpty()) return Finality.UNKNOWN
        val c = cands.minByOrNull { it.x0 } ?: return Finality.UNKNOWN
        val cw = c.x1 - c.x0 + 1; val ch = c.y1 - c.y0 + 1
        val sub = BooleanArray(cw * ch)
        for (y in 0 until ch) for (x in 0 until cw) sub[y * cw + x] = win[(c.y0 + y) * ww + c.x0 + x]
        return classifyFH(sub, cw, ch)
    }

    // ----------------------------------------------------------------------
    // F / H / clock on glyph-internal fractions only (scale-free).
    // ----------------------------------------------------------------------
    internal fun classifyFH(mask: BooleanArray, w: Int, h: Int): Finality {
        if (h < 8 || w < 3) return Finality.UNKNOWN
        val holeFloor = max(4, (h / 8) * (h / 8))
        val holes = countHoles(mask, w, h, holeFloor)
        if (holes >= 1) return Finality.CLOCK
        val q = max(1, w / 4)
        var leftInk = 0; var leftArea = 0
        for (y in 0 until h) for (x in 0 until q) { leftArea++; if (mask[y * w + x]) leftInk++ }
        val colL = leftInk.toFloat() / leftArea
        val r0 = 2 * q
        var lowerInk = 0; var lowerArea = 0
        val yStart = (0.55f * h).toInt()
        for (y in yStart until h) for (x in r0 until w) { lowerArea++; if (mask[y * w + x]) lowerInk++ }
        val colRL = if (lowerArea > 0) lowerInk.toFloat() / lowerArea else 0f
        var topInk = 0; var topArea = 0
        val tEnd = max(1, h / 5)
        for (y in 0 until tEnd) for (x in 0 until w) { topArea++; if (mask[y * w + x]) topInk++ }
        val rowT = topInk.toFloat() / topArea
        // F lower-right is empty (0.0-0.1), H's right stem fills 0.35-0.5 even
        // on narrow small glyphs (a 0.45 gate measured 0.43 on a real 11px H)
        if (colL > 0.30f && colRL < 0.25f && rowT > 0.40f) return Finality.FULL_TIME
        if (colL > 0.30f && colRL > 0.25f && rowT < 0.60f) return Finality.HALF_TIME
        return Finality.UNKNOWN
    }

    // ----------------------------------------------------------------------
    // Glyph classifier (frozen bank, per-digit hole/aspect evidence).
    // ----------------------------------------------------------------------
    internal const val GRID_W = 16
    internal const val GRID_H = 24

    internal class GlyphRead(val digit: Int?, val confidence: Float, val margin: Float)

    private val templates: List<Tpl> by lazy {
        ScoreBoardTemplates.ALL.map { t ->
            val bytes = ByteArray(48)
            for (i in 0 until 48) {
                bytes[i] = ((Character.digit(t.bits[i * 2], 16) shl 4) or
                    Character.digit(t.bits[i * 2 + 1], 16)).toByte()
            }
            val grid = LongArray(6)
            for (i in 0 until 384) {
                if ((bytes[i / 8].toInt() shr (7 - (i % 8))) and 1 == 1) {
                    grid[i / 64] = grid[i / 64] or (1L shl (i % 64))
                }
            }
            Tpl(t.digit, grid, t.aspect, t.holes, t.weight)
        }
    }

    internal class Tpl(val digit: Int, val grid: LongArray, val aspect: Float, val holes: Int, val weight: Float)

    internal fun countHoles(mask: BooleanArray, w: Int, h: Int, minHoleArea: Int = 1): Int {
        if (h < 3 || w < 3) return 0
        val inv = BooleanArray(mask.size) { !mask[it] }
        val seen = BooleanArray(mask.size)
        val queue = IntArray(mask.size)
        fun flood(start: Int): Int {
            var head = 0; var tail = 0; var size = 0
            queue[tail++] = start; seen[start] = true
            while (head < tail) {
                val p = queue[head++]; size++
                val x = p % w; val y = p / w
                if (x > 0 && inv[p - 1] && !seen[p - 1]) { seen[p - 1] = true; queue[tail++] = p - 1 }
                if (x + 1 < w && inv[p + 1] && !seen[p + 1]) { seen[p + 1] = true; queue[tail++] = p + 1 }
                if (y > 0 && inv[p - w] && !seen[p - w]) { seen[p - w] = true; queue[tail++] = p - w }
                if (y + 1 < h && inv[p + w] && !seen[p + w]) { seen[p + w] = true; queue[tail++] = p + w }
            }
            return size
        }
        for (x in 0 until w) {
            if (inv[x] && !seen[x]) flood(x)
            if (inv[(h - 1) * w + x] && !seen[(h - 1) * w + x]) flood((h - 1) * w + x)
        }
        for (y in 0 until h) {
            if (inv[y * w] && !seen[y * w]) flood(y * w)
            if (inv[y * w + w - 1] && !seen[y * w + w - 1]) flood(y * w + w - 1)
        }
        var holes = 0
        for (i in inv.indices) {
            if (inv[i] && !seen[i]) {
                if (flood(i) >= minHoleArea) holes++
            }
        }
        return holes
    }

    internal class Norm(val grid: LongArray, val aspect: Float)

    internal fun normalizeGrid(mask: BooleanArray, w: Int, h: Int): Norm? {
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) for (x in 0 until w) {
            if (mask[y * w + x]) {
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        if (maxX < minX || maxY < minY) return null
        val sw = maxX - minX + 1
        val sh = maxY - minY + 1
        val aspect = sw.toFloat() / sh
        val grid = LongArray(6)
        for (gy in 0 until GRID_H) {
            val sy = minY + min(sh - 1, (gy * sh + sh / 2) / GRID_H)
            for (gx in 0 until GRID_W) {
                val sx = minX + min(sw - 1, (gx * sw + sw / 2) / GRID_W)
                if (mask[sy * w + sx]) {
                    val i = gy * GRID_W + gx
                    grid[i / 64] = grid[i / 64] or (1L shl (i % 64))
                }
            }
        }
        return Norm(grid, aspect)
    }

    internal fun classifyGlyph(mask: BooleanArray, w: Int, h: Int): GlyphRead {
        val norm = normalizeGrid(mask, w, h) ?: return GlyphRead(null, 0f, 0f)
        // ignore sub-digit pinholes: a JPEG-noise split of a '4' counter fakes
        // a second hole and reads '8'; real digit holes are >= h/4 pixels
        val holes = countHoles(mask, w, h, max(3, h / 4))
        // per-digit class features: a 16px '5' may close its bowl under
        // compression (holes 0->1) — that must not penalise the digit '5' if
        // any harvested '5' variant shows the same topology, but it MUST
        // penalise digits that never render that way.
        val digitHoles = HashMap<Int, MutableSet<Int>>()
        val digitAspect = HashMap<Int, Pair<Float, Float>>()
        for (t in templates) {
            digitHoles.getOrPut(t.digit) { mutableSetOf() }.add(t.holes)
            val cur = digitAspect[t.digit] ?: (Float.MAX_VALUE to -Float.MAX_VALUE)
            digitAspect[t.digit] = min(cur.first, t.aspect) to max(cur.second, t.aspect)
        }
        val perDigit = HashMap<Int, Float>()
        for (t in templates) {
            var inter = 0L; var union = 0L
            for (k in 0 until 6) {
                inter += java.lang.Long.bitCount(norm.grid[k] and t.grid[k])
                union += java.lang.Long.bitCount(norm.grid[k] or t.grid[k])
            }
            var sc = (if (union > 0) inter.toFloat() / union else 0f) * t.weight
            if (holes !in (digitHoles[t.digit] ?: emptySet())) sc *= 0.35f
            val (lo, hi) = digitAspect[t.digit] ?: (0f to 1f)
            if (aspect < lo - 0.15f || aspect > hi + 0.15f) sc *= 0.6f
            if (sc > (perDigit[t.digit] ?: -1f)) perDigit[t.digit] = sc
        }
        val ranked = perDigit.entries.sortedByDescending { it.value }
        val bd = ranked[0].key; val best = ranked[0].value
        val second = if (ranked.size > 1) ranked[1].value else 0f
        val margin = best - second
        if (best < 0.45f || margin < 0.02f) return GlyphRead(null, best, margin)
        return GlyphRead(bd, best, margin)
    }

    private fun Float.pow(p: Float): Float = kotlin.math.pow(this, p)
}
