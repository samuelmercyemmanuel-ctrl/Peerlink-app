# F33 — Score & Statistics Reader Rebuild (Full-Time + Halftime + Menu screens)

## What was broken (root cause, proven)

The F29–F32 score reader **never read a single score in the field**. Two independent
fatal defects, both proven against the seven calibration screenshots and the match
logs in this repository:

1. **Wrong colour window (fatal).** `ScoreVisualPreprocessor` filtered the score-box
   yellow at **hue 15–45° (orange)**. eFootball draws its UI yellow at **hue ≈ 60°**
   (pure yellow, e.g. RGB 230,230,0). Every frame therefore produced zero yellow
   pixels → the preprocessor returned null → `detectFrame()` returned null.
   Evidence: `grep MATCH-OCR peerlink_match_*.txt` across all recorded matches
   returns **zero** score-read lines while bursts analyzed 9–25 frames each.
2. **~1.5 s latency per frame.** ML Kit ran on every candidate frame with a
   1.8 s latch. At the 4 fps capture cadence this dropped most frames, and capture
   bursts are often cancelled after ~2 s ("gameplay recovered"), so the stats board
   frequently flashed by unanalyzed.
3. **No statistics reading at all**, and the legacy band composite physically
   crops away most of the statistics table (display rows 32–70%).

## What F33 delivers

### Two-stage pixel engine (`ScoreBoardDetector.kt`, no OCR in the hot path)

* **Stage 1 — Gate (~3–6 ms):** classifies each frame as
  `STATS_BOARD` (halftime/fulltime statistics board), `WALKING` (end-of-half banner),
  `MENU` (result menu after Next), or `OTHER`. Non-score frames are thrown away in
  milliseconds — they are never "read".
* **Stage 2 — Read (~5–25 ms):** fixed game-UI geometry (measured from real
  captures) locates the score digits and the 13 statistics rows; glyphs are
  classified against **ScoreBoardTemplates**, a bank harvested from the real
  screenshots (plus font prototypes for digits that never appeared). Includes:
  * score on all three screen presentations (bottom banner, top banner, big menu digits),
  * full statistics table read (Possession → Saves, home + away, `%` handled),
  * Full Time / Halftime / clock detection from the header glyph structure
    ('F' / 'H' / closed digit) — no OCR needed for finality.

Measured on the reference implementation: **all 7 calibration screenshots pass**
(score + gate + finality + all 13 statistic rows exact), at 1600 px raw, 1280 px
and 960 px with JPEG q88 (the exact production transfer format). Non-score
crops (pitch, sky, grass, menu cards, noise) are all rejected as `OTHER`.

### Latency

| | F32 (old) | F33 (new) |
|---|---|---|
| Non-score frame | ~1.5 s ML Kit | **~3–6 ms gate reject** |
| Score frame | ~1.5 s (often wrong/null) | **~5–25 ms** deterministic |
| 2-frame confirmation | 2 × 1.5 s (often never) | **~0.5 s** |

### Capture path (Prime v6)

* New privileged command `__fullcap_jpeg__` (PrimeServer): full display JPEG capped
  at 1280 px — the statistics table is only present on the full frame.
* `PrimeClient.captureFullFrame()` + protocol 2..6. Legacy v4/v5 band composites
  still work for **score-only** reads (coordinate mapper remaps the bands);
  statistics need the v6 daemon (redeploy Prime after updating the APK).

### Statistics persisted with the match

* `MatchStats` / `MatchStatRow` models in `MatchData.kt`; optional `stats` field on
  `MatchRecord` (JSON round-trip, excluded from settlement/integrity).
* `MatchTracker.confirmScreenScore()` accepts and stores the table;
  `MatchAutomationEngine` passes it through. Old ledger files keep loading.

### Fallbacks kept

ML Kit chain (preprocessor + ScoreLaneReader + FinalScoreEvidence) is retained as a
last-resort for a frame the gate classified as a score screen but the pixel engine
could not resolve (unknown UI skin / badly degraded capture).

## Files changed / added

| File | Change |
|---|---|
| `app/.../service/ScoreBoardDetector.kt` | **new** — gate + pixel readers + glyph classifier + stats + finality |
| `app/.../service/ScoreBoardTemplates.kt` | **new** — 52-template bank from real captures (generated) |
| `app/.../service/PrimeScreenScoreDetector.kt` | rewritten — v6 full-frame path, gate-first flow, ML Kit fallback only |
| `app/.../godmode/PrimeServer.kt` | `__fullcap_jpeg__` + `prime_ok_v6` + full-frame JPEG pipeline |
| `app/.../godmode/PrimeClient.kt` | `captureFullFrame()`, protocol 2..6 |
| `app/.../core/MatchData.kt` | `MatchStats` model + optional ledger field + JSON |
| `app/.../core/MatchTracker.kt` | `confirmScreenScore(..., stats)` |
| `app/.../service/MatchAutomationEngine.kt` | passes stats into the ledger commit |
| `tests/f33_score_detector_regression.py` | **new** — 45 structural + calibration-vector checks |
| `tests/f33_reference/` | **new** — executable Python reference (prototype + robustness harness + template exporter) |
| `tests/run_checks.py` | registers the F33 suite |

## How to verify

```bash
# host checks (no Android SDK needed):
python3 tests/run_checks.py          # includes f33_score_detector_regression

# full pixel-level validation against the real screenshots (numpy + Pillow):
python3 tests/f33_reference/prototype.py    # ALL 7 PASS
python3 tests/f33_reference/robustness.py   # scale/JPEG matrix + negatives + speed
```

Expected: `ALL PASS` on all seven screenshots with exact scores
(0-1 walking, 0-1 FT board, 0-0 HT board, 2-2 FT menu, 1-2 HT board, 4-2 HT board,
4-2 HT menu/clock) and exact 13-row statistics on all four boards.

## Known limits

* Legacy v4/v5 band composite (pre-v6 Prime daemon) reads the score only; the two
  LaLiga-banner boards classify correctly but their digits degrade below the
  reliable-reading threshold at 960 px q88. Redeploying Prime (Activate flow)
  switches bursts to the v6 full-frame path, which passes everything.
* The template bank covers every digit 0–9 (real captures + font prototypes).
  If a future eFootball UI reskin changes the font, re-run the exporter in
  `tests/f33_reference/` with new captures.
