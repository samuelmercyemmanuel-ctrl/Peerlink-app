package com.peerlink.app.service

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * F33 two-stage eFootball score-screen reader.
 *
 * Stage 1 GATE (~3-6 ms on one core): classify the frame from pure colour
 * structure. eFootball draws every score presentation with the same palette —
 * saturated yellow at hue ~60 (the previous reader filtered hue 15..45 and
 * therefore never matched a single real frame), navy text, dark menu
 * backgrounds. Frames that are not one of the three score presentations are
 * rejected in milliseconds without any OCR.
 *
 * Stage 2 READ (~5-25 ms): the score digits (and, on the statistics board,
 * all 13 statistic rows) are extracted by colour geometry that is fixed by
 * the game UI and measured from real captures, then classified against a
 * template bank harvested from real eFootball renders
 * (see [ScoreBoardTemplates]). No ML model and no network is involved, so a
 * read costs a few milliseconds instead of the ~1.5 s an ML Kit pass needed,
 * and misreads are deterministic rather than random.
 *
 * Screen presentations covered (all verified against real captures):
 *  STATS_BOARD - full/halftime statistics board, score in the top banner.
 *  WALKING     - end-of-half pitch walk-out, score in the bottom banner.
 *  MENU        - result menu after tapping Next, large score under the clock.
 */
internal object ScoreBoardDetector {

    enum class ScreenType { STATS_BOARD, WALKING, MENU, OTHER }

    /** 13 fixed eFootball statistic rows, in board order. */
    val STAT_NAMES = listOf(
        "Possession", "TotalShots", "ShotsOnTarget", "Fouls", "Offsides",
        "CornerKicks", "FreeKicks", "Passes", "SuccessfulPasses", "Crosses",
        "Interceptions", "Tackles", "Saves",
    )

    class StatRow(val name: String, val home: Int, val away: Int)

    class Stats internal constructor(internal val rows: List<StatRow>) {
        val size: Int get() = rows.size
        operator fun get(name: String): Pair<Int, Int>? =
            rows.firstOrNull { it.name == name }?.let { it.home to it.away }
        fun toJsonArray(): org.json.JSONArray = org.json.JSONArray().apply {
            rows.forEach { row ->
                put(org.json.JSONObject().apply {
                    put("name", row.name)
                    put("home", row.home)
                    put("away", row.away)
                })
            }
        }

        companion object {
            fun fromJson(array: org.json.JSONArray): Stats {
                val rows = ArrayList<StatRow>(array.length())
                for (i in 0 until array.length()) {
                    val o = array.optJSONObject(i) ?: continue
                    val name = o.optString("name")
                    val home = o.optInt("home", -1)
                    val away = o.optInt("away", -1)
                    if (name.isNotEmpty() && home in 0..100 && away in 0..100) {
                        rows.add(StatRow(name, home, away))
                    }
                }
                return Stats(rows)
            }
        }
    }

    enum class Finality { FULL_TIME, HALF_TIME, CLOCK, UNKNOWN }

    class Detection(
        val type: ScreenType,
        val home: Int?,
        val away: Int?,
        val finality: Finality,
        val stats: Stats?,
        val gateInfo: String,
    ) {
        val score: Pair<Int, Int>? get() = if (home == null || away == null) null else home to away
        val finalScreen: Boolean get() = finality == Finality.FULL_TIME
    }

    /**
     * Window geometry of the incoming image.
     * FULL: a complete display frame (v6 __fullcap_jpeg__). Statistics rows
     *       are only present here — the legacy band composite crops them away.
     * COMPOSITE: v4/v5 band stack (display top 0..32% + bottom 70..100%,
     *       central 22..78% width). Score reading still works through the
     *       coordinate mapper; statistics do not.
     */
    sealed class Geometry {
        object Full : Geometry()
        class Composite(val topHeight: Int, val gap: Int, val refHeight: Int) : Geometry()
    }

    /**
     * Maps full-screen fractions to pixels of the actual image. All reader
     * windows are expressed as screen fractions measured from real captures;
     * for the composite those fractions map onto the stacked bands.
     */
    internal class FrameMap(val w: Int, val h: Int, private val geometry: Geometry) {
        val composite: Boolean = geometry is Geometry.Composite
        // Composite drops the display's 32..70% band, diluting global colour
        // fractions; the gate normalises by this factor.
        val dilution: Float = when (val g = geometry) {
            is Geometry.Full -> 1f
            is Geometry.Composite ->
                (w.toFloat() * h) / ((w / 0.56f) * max(1, g.refHeight))
        }

        fun x(f: Float): Int = if (!composite) (f * w).toInt().coerceIn(0, w - 1)
        else (((f - 0.22f) / 0.56f) * w).toInt().coerceIn(0, w - 1)

        fun y(f: Float): Int {
            if (!composite) return (f * h).toInt().coerceIn(0, h - 1)
            val g = geometry as Geometry.Composite
            val top = g.topHeight.coerceIn(1, h)
            val gap = g.gap.coerceIn(0, max(0, h - top - 1))
            val bottom = h - top - gap
            val v = if (f < 0.32f) {
                f / 0.32f * top
            } else {
                top + gap + (f - 0.70f) / 0.30f * bottom
            }
            return v.toInt().coerceIn(0, h - 1)
        }
    }

    // ------------------------------------------------------------------
    // Colour masks. The game palette is extremely stable, which is what makes
    // a pixel engine viable: pure yellow ~hue 60, navy ~hue 240, and the two
    // are never mixed by the UI.
    // ------------------------------------------------------------------
    internal class Masks(val w: Int, val h: Int) {
        val yellow = BooleanArray(w * h)     // strict: bands/separators (never grass)
        val yellowInk = BooleanArray(w * h)  // loose: glyph ink on navy/dark
        val navy = BooleanArray(w * h)
        val green = BooleanArray(w * h)
        val dark = BooleanArray(w * h)
        val white = BooleanArray(w * h)
        var yellowFrac = 0f; var navyFrac = 0f; var greenFrac = 0f
        var darkFrac = 0f; var whiteFrac = 0f

        inline fun at(arr: BooleanArray, x: Int, y: Int) = arr[y * w + x]
    }

    internal fun buildMasks(pixels: IntArray, w: Int, h: Int): Masks {
        val m = Masks(w, h)
        var yC = 0; var nC = 0; var gC = 0; var dC = 0; var wC = 0
        val total = w * h
        for (i in 0 until total) {
            val c = pixels[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val diff = mx - mn
            var hue = 0f
            if (diff > 0) {
                val rm = mx == r; val gm = mx == g && !rm
                hue = when {
                    rm -> 60f * (g - b) / diff
                    gm -> 60f * (b - r) / diff + 120f
                    else -> 60f * (r - g) / diff + 240f
                }
                if (hue < 0f) hue += 360f
            }
            val sat = if (mx > 0) diff.toFloat() / mx else 0f
            val v = mx / 255f
            m.yellow[i] = hue in 48f..72f && sat >= 0.58f && v >= 0.60f
            m.yellowInk[i] = hue in 45f..75f && sat >= 0.45f && v >= 0.40f
            m.navy[i] = hue in 200f..260f && sat >= 0.45f && v <= 0.55f
            m.green[i] = hue in 70f..160f && sat >= 0.25f && v >= 0.25f
            m.dark[i] = v <= 0.22f
            m.white[i] = sat <= 0.12f && v >= 0.85f
            if (m.yellow[i]) yC++
            if (m.navy[i]) nC++
            if (m.green[i]) gC++
            if (m.dark[i]) dC++
            if (m.white[i]) wC++
        }
        m.yellowFrac = yC.toFloat() / total
        m.navyFrac = nC.toFloat() / total
        m.greenFrac = gC.toFloat() / total
        m.darkFrac = dC.toFloat() / total
        m.whiteFrac = wC.toFloat() / total
        return m
    }

    /** Loose navy tier for JPEG-degraded digits. */
    internal fun looseNavy(pixels: IntArray, w: Int, h: Int): BooleanArray {
        val out = BooleanArray(w * h)
        for (i in 0 until w * h) {
            val c = pixels[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val mx = max(r, max(g, b))
            val mn = min(r, min(g, b))
            val diff = mx - mn
            var hue = 0f
            if (diff > 0) {
                val rm = mx == r; val gm = mx == g && !rm
                hue = when {
                    rm -> 60f * (g - b) / diff
                    gm -> 60f * (b - r) / diff + 120f
                    else -> 60f * (r - g) / diff + 240f
                }
                if (hue < 0f) hue += 360f
            }
            val sat = if (mx > 0) diff.toFloat() / mx else 0f
            val v = mx / 255f
            out[i] = hue in 195f..265f && sat >= 0.28f && v <= 0.68f
        }
        return out
    }

    // ------------------------------------------------------------------
    // Entry point.
    // ------------------------------------------------------------------
    fun analyze(frame: Bitmap, geometry: Geometry): Detection? {
        val w = frame.width
        val h = frame.height
        if (w < 320 || h < 180) return null
        val pixels = IntArray(w * h)
        frame.getPixels(pixels, 0, w, 0, 0, w, h)
        val map = FrameMap(w, h, geometry)
        val masks = buildMasks(pixels, w, h)
        val type = gate(masks, map)
        if (type == ScreenType.OTHER) {
            return Detection(ScreenType.OTHER, null, null, Finality.UNKNOWN, null, gateDebug(masks))
        }
        var home: Int? = null
        var away: Int? = null
        var finality = Finality.UNKNOWN
        var stats: Stats? = null
        when (type) {
            ScreenType.STATS_BOARD -> {
                val loose = looseNavy(pixels, w, h)
                val clusters = readBannerScore(masks, loose, map, bannerZoneBoard(map))
                if (clusters != null) {
                    home = readScoreValue(clusters.second.first, masks, clusters.first.first, map, maxDigits = 2)
                    away = readScoreValue(clusters.second.second, masks, clusters.first.second, map, maxDigits = 2)
                }
                finality = readFinalityBoard(masks, map)
                if (geometry is Geometry.Full) {
                    stats = readStatsTable(masks, map)
                }
            }
            ScreenType.WALKING -> {
                val loose = looseNavy(pixels, w, h)
                val clusters = readBannerScore(masks, loose, map, bannerZoneWalking(map))
                if (clusters != null) {
                    home = readScoreValue(clusters.second.first, masks, clusters.first.first, map, maxDigits = 2)
                    away = readScoreValue(clusters.second.second, masks, clusters.first.second, map, maxDigits = 2)
                }
            }
            ScreenType.MENU -> {
                val clusters = readMenuScore(masks, map)
                if (clusters != null) {
                    home = readScoreValue(clusters.first, masks, null, map, useInk = true, maxDigits = 2)
                    away = readScoreValue(clusters.second, masks, null, map, useInk = true, maxDigits = 2)
                }
                finality = readFinalityMenu(masks, map)
            }
            ScreenType.OTHER -> Unit
        }
        return Detection(type, home, away, finality, stats, gateDebug(masks))
    }

    private fun gateDebug(m: Masks): String =
        "y=${m.yellowFrac} n=${m.navyFrac} g=${m.greenFrac} d=${m.darkFrac} w=${m.whiteFrac}"

    // ------------------------------------------------------------------
    // Stage 1 gate.
    // ------------------------------------------------------------------
    internal fun gate(m: Masks, map: FrameMap): ScreenType {
        val h = m.h
        val w = m.w
        val dil = if (map.composite) max(0.3f, map.dilution) else 1f
        // bottom yellow band (walking banner strip): strict-yellow rows in the
        // lower part, averaged over the central 40% width
        var bottomBandRows = 0
        var bottomBandSum = 0f
        val x0 = map.x(0.30f)
        val x1 = map.x(0.70f)
        val scanFrom = if (map.composite) (0.55f * h).toInt() else (0.66f * h).toInt()
        var y = scanFrom
        while (y < h) {
            var cnt = 0
            for (x in x0 until x1 step 2) if (m.at(m.yellow, x, y)) cnt++
            val frac = cnt.toFloat() * 2f / max(1, x1 - x0)
            if (frac > 0.30f) { bottomBandRows++; bottomBandSum += y.toFloat() / h }
            y++
        }
        val bandCenter = if (bottomBandRows > 0) bottomBandSum / bottomBandRows else 0f
        val bottomBand = bottomBandRows >= 2 && bandCenter > (if (map.composite) 0.58f else 0.72f)
        // menu: yellow ink in the top-centre window
        val cy0 = map.y(0.04f); val cy1 = map.y(0.26f)
        val cx0 = map.x(0.40f); val cx1 = map.x(0.60f)
        var menuInk = 0
        var menuArea = 0
        for (yy in cy0 until cy1) for (xx in cx0 until cx1) {
            menuArea++
            if (m.at(m.yellow, xx, yy)) menuInk++
        }
        val menuInkFrac = if (menuArea > 0) menuInk.toFloat() / menuArea else 0f
        return when {
            m.yellowFrac / dil >= 0.14f && m.navyFrac / dil >= 0.06f &&
                m.greenFrac / dil <= 0.34f && m.whiteFrac / dil <= 0.12f ->
                ScreenType.STATS_BOARD
            m.darkFrac / dil >= 0.38f && m.whiteFrac / dil >= 0.10f &&
                m.yellowFrac / dil <= 0.06f && menuInkFrac >= 0.004f ->
                ScreenType.MENU
            m.greenFrac / dil >= 0.38f && m.yellowFrac / dil >= 0.02f && bottomBand ->
                ScreenType.WALKING
            else -> ScreenType.OTHER
        }
    }

    // ------------------------------------------------------------------
    // Zone helpers (fractions measured from real 1600x720 captures; the UI
    // scales linearly with frame height).
    // ------------------------------------------------------------------
    private fun bannerZoneBoard(map: FrameMap): Pair<Int, Int> = map.y(0.148f) to map.y(0.235f)
    private fun bannerZoneWalking(map: FrameMap): Pair<Int, Int> = map.y(0.79f) to map.y(0.89f)

    // ------------------------------------------------------------------
    // Connected components + glyph helpers.
    // ------------------------------------------------------------------
    internal class Box(var x0: Int, var y0: Int, var x1: Int, var y1: Int, var area: Int) {
        val width: Int get() = x1 - x0 + 1
        val height: Int get() = y1 - y0 + 1
    }

    internal fun components(mask: BooleanArray, w: Int, h: Int, minArea: Int): ArrayList<Box> {
        val seen = BooleanArray(mask.size)
        val out = ArrayList<Box>()
        val queue = IntArray(mask.size)
        for (start in mask.indices) {
            if (!mask[start] || seen[start]) continue
            var head = 0; var tail = 0
            queue[tail++] = start
            seen[start] = true
            var bx0 = start % w; var bx1 = bx0
            var by0 = start / w; var by1 = by0
            var area = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % w; val yy = p / w
                area++
                if (x < bx0) bx0 = x
                if (x > bx1) bx1 = x
                if (yy < by0) by0 = yy
                if (yy > by1) by1 = yy
                if (x > 0 && mask[p - 1] && !seen[p - 1]) { seen[p - 1] = true; queue[tail++] = p - 1 }
                if (x + 1 < w && mask[p + 1] && !seen[p + 1]) { seen[p + 1] = true; queue[tail++] = p + 1 }
                if (yy > 0 && mask[p - w] && !seen[p - w]) { seen[p - w] = true; queue[tail++] = p - w }
                if (yy + 1 < h && mask[p + w] && !seen[p + w]) { seen[p + w] = true; queue[tail++] = p + w }
            }
            if (area >= minArea) out.add(Box(bx0, by0, bx1, by1, area))
        }
        return out
    }

    /** Merge stroke fragments split by compression. Union size is capped so a
     *  digit never merges with the digit-box border bars or banner trims. */
    internal fun mergeFragments(comps: List<Box>, ygap: Int, maxW: Int, maxH: Int): ArrayList<Box> {
        val sorted = comps.sortedWith(compareBy({ it.y0 }, { it.x0 }))
        val out = ArrayList<Box>()
        for (c in sorted) {
            var target: Box? = null
            for (p in out) {
                val ov = min(c.x1, p.x1) - max(c.x0, p.x0) + 1
                val minw = min(c.width, p.width)
                val gap = max(c.y0 - p.y1, p.y0 - c.y1)
                if (ov <= 0 || ov <= 0.5f * minw || gap > ygap) continue
                val unionW = max(c.x1, p.x1) - min(c.x0, p.x0) + 1
                val unionH = max(c.y1, p.y1) - min(c.y0, p.y0) + 1
                if (unionW > maxW || unionH > maxH) continue
                target = p; break
            }
            if (target != null) {
                target.x0 = min(target.x0, c.x0); target.x1 = max(target.x1, c.x1)
                target.y0 = min(target.y0, c.y0); target.y1 = max(target.y1, c.y1)
                target.area += c.area
            } else {
                out.add(Box(c.x0, c.y0, c.x1, c.y1, c.area))
            }
        }
        return out
    }

    /** Extract a boolean sub-window from a full mask (pixels coordinate space). */
    private fun window(masks: BooleanArray, w: Int, x0: Int, x1: Int, y0: Int, y1: Int): Pair<BooleanArray, Int> {
        val ww = x1 - x0 + 1
        val win = BooleanArray(ww * (y1 - y0 + 1))
        var k = 0
        for (y in y0..y1) for (x in x0..x1) win[k++] = masks[y * w + x]
        return win to ww
    }

    // ------------------------------------------------------------------
    // Score digits in the banner (stats board top / walking bottom).
    // ------------------------------------------------------------------
    internal fun readBannerScore(
        m: Masks,
        loose: BooleanArray,
        map: FrameMap,
        zone: Pair<Int, Int>,
    ): Pair<Pair<BooleanArray, BooleanArray>, Pair<Box, Box>>? {
        val h = m.h; val w = m.w
        val (zy0, zy1) = zone
        val result = HashMap<String, Box>(2)
        val usedMask = HashMap<String, BooleanArray>(2)
        val fragGap = max(3, (0.012f * h).toInt())
        for (side in listOf("home", "away")) {
            val xf0 = if (side == "home") 0.415f else 0.5025f
            val xf1 = if (side == "home") 0.4975f else 0.585f
            val X0 = map.x(xf0)
            val X1 = map.x(xf1)
            var cand: List<Box>? = null
            var chosen: BooleanArray = m.navy
            for (nm in listOf(m.navy, loose)) {
                val (win, ww) = window(nm, w, X0, X1, zy0, zy1)
                val wh = zy1 - zy0 + 1
                for (ygap in intArrayOf(0, fragGap)) {
                    var comps = components(win, ww, wh, max(6, (0.00002f * w * h).toInt()))
                    if (ygap > 0) {
                        comps = mergeFragments(comps, ygap, (0.052f * w).toInt(), (0.068f * h).toInt())
                    }
                    val filtered = comps.filter {
                        0.030f * h <= it.height && it.height <= 0.068f * h &&
                            it.width <= 0.070f * w && it.area >= max(10, (0.00006f * w * h).toInt())
                    }
                    if (filtered.isNotEmpty()) { cand = filtered; chosen = nm; break }
                }
                if (cand != null) break
            }
            if (cand == null) return null
            for (c in cand) { c.x0 += X0; c.x1 += X0; c.y0 += zy0; c.y1 += zy0 }
            val targetX = map.x(if (side == "home") 0.4655f else 0.5355f).toFloat()
            cand = cand.sortedByDescending { c ->
                val cx = (c.x0 + c.x1) / 2f
                val prox = exp(-(((cx - targetX) / (0.016f * w)).pow(2)))
                prox * sqrt(c.area.toFloat())
            }
            val best = cand.first()
            val cluster = Box(best.x0, best.y0, best.x1, best.y1, best.area)
            var changed = true
            while (changed) {
                changed = false
                for (c in cand) {
                    if (c.x0 <= cluster.x1 && c.x1 >= cluster.x0 && (c.x0 < cluster.x0 || c.x1 > cluster.x1)) {
                        cluster.x0 = min(cluster.x0, c.x0); cluster.x1 = max(cluster.x1, c.x1)
                        cluster.y0 = min(cluster.y0, c.y0); cluster.y1 = max(cluster.y1, c.y1)
                        cluster.area += c.area
                        changed = true
                    }
                }
            }
            if (cluster.width > 0.075f * w) return null
            result[side] = cluster
            usedMask[side] = chosen
        }
        val homeBox = result["home"] ?: return null
        val awayBox = result["away"] ?: return null
        return (usedMask["home"]!! to usedMask["away"]!!) to (homeBox to awayBox)
    }

    // ------------------------------------------------------------------
    // Big yellow digits on the result menu.
    // ------------------------------------------------------------------
    internal fun readMenuScore(m: Masks, map: FrameMap): Pair<Box, Box>? {
        val w = m.w; val h = m.h
        val Y0 = map.y(0.045f); val Y1 = map.y(0.27f)
        val out = HashMap<String, Box>(2)
        for (side in listOf("home", "away")) {
            val X0 = map.x(if (side == "home") 0.40f else 0.5025f)
            val X1 = map.x(if (side == "home") 0.4975f else 0.60f)
            val (win, ww) = window(m.yellowInk, w, X0, X1 - 1, Y0, Y1 - 1)
            val wh = Y1 - Y0
            val groups = segmentsOfWindow(win, ww, wh, max(10, (0.00008f * w * h).toInt()),
                (0.055f * w).toInt(), max(3, (0.012f * h).toInt()))
            val cand = groups.filter {
                0.055f * h <= it.height && it.height <= 0.13f * h && it.width <= 0.060f * w
            }
            if (cand.isEmpty()) return null
            val targetX = map.x(if (side == "home") 0.4655f else 0.5335f).toFloat()
            val bestGroup = cand.sortedByDescending { g ->
                val cx = (g.x0 + g.x1) / 2f
                val prox = exp(-(((cx - targetX) / (0.02f * w)).pow(2)))
                prox * sqrt(g.area.toFloat())
            }.first()
            out[side] = Box(bestGroup.x0 + X0, bestGroup.y0 + Y0, bestGroup.x1 + X0, bestGroup.y1 + Y0, bestGroup.area)
        }
        return (out["home"] ?: return null) to (out["away"] ?: return null)
    }

    // ------------------------------------------------------------------
    // Glyph segmentation inside a window (merge x-overlapping strokes).
    // ------------------------------------------------------------------
    internal fun segmentsOfWindow(
        mask: BooleanArray, w: Int, h: Int,
        minArea: Int, wideMax: Int, ygap: Int,
    ): ArrayList<Box> {
        val comps = components(mask, w, h, minArea)
            .filter { it.width <= wideMax }
            .sortedWith(compareBy({ it.y0 }, { it.x0 }))
        val groups = ArrayList<Box>()
        for (c in comps) {
            var target: Box? = null
            for (g in groups) {
                val ov = min(c.x1, g.x1) - max(c.x0, g.x0) + 1
                val minw = min(c.width, g.width)
                val gap = max(c.y0 - g.y1, g.y0 - c.y1)
                if (ov > 0.45f * minw && gap <= ygap) { target = g; break }
            }
            if (target != null) {
                target.x0 = min(target.x0, c.x0); target.x1 = max(target.x1, c.x1)
                target.y0 = min(target.y0, c.y0); target.y1 = max(target.y1, c.y1)
                target.area += c.area
            } else {
                groups.add(Box(c.x0, c.y0, c.x1, c.y1, c.area))
            }
        }
        return groups
    }

    // ------------------------------------------------------------------
    // Digit classification.
    // ------------------------------------------------------------------
    internal const val GRID_W = 16
    internal const val GRID_H = 24

    internal class GlyphFeatures(val digit: Int, val grid: LongArray, val aspect: Float, val holes: Int)

    private val templates: List<GlyphFeatures> by lazy {
        ScoreBoardTemplates.ALL.map { t ->
            val bytes = ByteArray(48)
            for (i in 0 until 48) {
                bytes[i] = ((Character.digit(t.bits[i * 2], 16) shl 4) or
                    Character.digit(t.bits[i * 2 + 1], 16)).toByte()
            }
            val grid = LongArray(6)
            for (i in 0 until 384) {
                if ((bytes[i / 8].toInt() shr (i % 8)) and 1 == 1) {
                    grid[i / 64] = grid[i / 64] or (1L shl (i % 64))
                }
            }
            GlyphFeatures(t.digit, grid, t.aspect, t.holes)
        }
    }

    internal class GlyphRead(val digit: Int?, val confidence: Float, val holes: Int, val aspect: Float)

    internal fun normalizeGrid(mask: BooleanArray, w: Int, h: Int): Pair<LongArray, Float>? {
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) for (x in 0 until w) {
            if (mask[y * w + x]) {
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
            }
        }
        if (maxX < minX || maxY < minY) return null
        val sw = maxX - minX + 1
        val sh = maxY - minY + 1
        val aspect = sw.toFloat() / sh
        val grid = LongArray(6)
        for (gy in 0 until GRID_H) {
            // centre sampling of each grid cell (matches the calibrated Python
            // reference, which box-downsamples with a 50% threshold)
            val sy = minY + min(sh - 1, (gy * sh + sh / 2) / GRID_H)
            for (gx in 0 until GRID_W) {
                val sx = minX + min(sw - 1, (gx * sw + sw / 2) / GRID_W)
                if (mask[sy * w + sx]) {
                    val i = gy * GRID_W + gx
                    grid[i / 64] = grid[i / 64] or (1L shl (i % 64))
                }
            }
        }
        return grid to aspect
    }

    internal fun countHoles(mask: BooleanArray, w: Int, h: Int): Int {
        if (w < 3 || h < 3) return 0
        val inv = BooleanArray(mask.size) { !mask[it] }
        val seen = BooleanArray(mask.size)
        val queue = IntArray(mask.size)
        fun flood(start: Int) {
            var head = 0; var tail = 0
            queue[tail++] = start; seen[start] = true
            while (head < tail) {
                val p = queue[head++]
                val x = p % w; val y = p / w
                if (x > 0 && inv[p - 1] && !seen[p - 1]) { seen[p - 1] = true; queue[tail++] = p - 1 }
                if (x + 1 < w && inv[p + 1] && !seen[p + 1]) { seen[p + 1] = true; queue[tail++] = p + 1 }
                if (y > 0 && inv[p - w] && !seen[p - w]) { seen[p - w] = true; queue[tail++] = p - w }
                if (y + 1 < h && inv[p + w] && !seen[p + w]) { seen[p + w] = true; queue[tail++] = p + w }
            }
        }
        for (x in 0 until w) {
            if (inv[x] && !seen[x]) flood(x)
            if (inv[(h - 1) * w + x] && !seen[(h - 1) * w + x]) flood((h - 1) * w + x)
        }
        for (y in 0 until h) {
            if (inv[y * w] && !seen[y * w]) flood(y * w)
            if (inv[y * w + w - 1] && !seen[y * w + w - 1]) flood(y * w + w - 1)
        }
        var holes = 0
        for (i in inv.indices) {
            if (inv[i] && !seen[i]) { holes++; flood(i) }
        }
        return holes
    }

    internal fun classifyGlyph(mask: BooleanArray, w: Int, h: Int): GlyphRead {
        val norm = normalizeGrid(mask, w, h) ?: return GlyphRead(null, 0f, 0, 0f)
        val (grid, aspect) = norm
        val holes = countHoles(mask, w, h)
        var best = -1f; var second = -1f; var bestDigit: Int? = null
        for (t in templates) {
            var inter = 0L; var union = 0L
            for (k in 0 until 6) {
                inter += java.lang.Long.bitCount(grid[k] and t.grid[k])
                union += java.lang.Long.bitCount(grid[k] or t.grid[k])
            }
            var score = if (union > 0) inter.toFloat() / union else 0f
            if (t.holes != holes) score *= 0.35f
            if (abs(t.aspect - aspect) > 0.40f) score *= 0.6f
            if (score > best) { second = best; best = score; bestDigit = t.digit }
            else if (score > second) second = score
        }
        return GlyphRead(bestDigit, best, holes, aspect)
    }

    /** Column-gap/valley split of an over-wide fused glyph ("45"). */
    internal fun splitWide(mask: BooleanArray, w: Int, h: Int, maxW: Int): List<Triple<BooleanArray, Int, Int>> {
        if (w <= maxW) return listOf(Triple(mask, w, h))
        val colInk = IntArray(w)
        for (y in 0 until h) for (x in 0 until w) if (mask[y * w + x]) colInk[x]++
        val segs = ArrayList<IntArray>()
        var start = -1; var gap = 0
        for (x in 0 until w) {
            if (colInk[x] > 0) { if (start < 0) start = x; gap = 0 }
            else if (start >= 0) {
                gap++
                if (gap >= 1) {
                    if (x - gap - start + 1 >= 2) segs.add(intArrayOf(start, x - gap))
                    start = -1; gap = 0
                }
            }
        }
        if (start >= 0 && w - start >= 2) segs.add(intArrayOf(start, w - 1))
        if (segs.size > 1) {
            return segs.map { ab ->
                val a = ab[0]; val b = ab[1]
                val sw = b - a + 1
                val sub = BooleanArray(sw * h)
                for (y in 0 until h) for (x in 0 until sw) sub[y * sw + x] = mask[y * w + a + x]
                Triple(sub, sw, h)
            }
        }
        val outList = ArrayList<Triple<BooleanArray, Int, Int>>()
        var s = 0
        while (w - s > maxW) {
            val lo = s + max(1, (0.25f * maxW).toInt())
            val hi = min(w - 1, s + (0.75f * (w - s)).toInt())
            var cut = lo; var bestInk = Int.MAX_VALUE
            for (x in lo..hi) if (colInk[x] < bestInk) { bestInk = colInk[x]; cut = x }
            val sw = cut - s
            if (sw <= 0) break
            val sub = BooleanArray(sw * h)
            for (y in 0 until h) for (x in 0 until sw) sub[y * sw + x] = mask[y * w + s + x]
            outList.add(Triple(sub, sw, h))
            s = cut
        }
        if (s < w) {
            val sw = w - s
            val sub = BooleanArray(sw * h)
            for (y in 0 until h) for (x in 0 until sw) sub[y * sw + x] = mask[y * w + s + x]
            outList.add(Triple(sub, sw, h))
        }
        return outList
    }

    /** Read a number (1-2 score digits) from a cluster box in frame coords. */
    internal fun readScoreValue(
        cluster: Box, m: Masks, inkOverride: BooleanArray?, map: FrameMap,
        useInk: Boolean = false, maxDigits: Int = 2, minConf: Float = 0.45f,
    ): Int? {
        val w = m.w; val h = m.h
        val ink = inkOverride ?: if (useInk) m.yellowInk else m.navy
        val cw = cluster.width; val ch = cluster.height
        val win = BooleanArray(cw * ch)
        var k = 0
        for (y in cluster.y0..cluster.y1) for (x in cluster.x0..cluster.x1) {
            win[k++] = ink[y * w + x]
        }
        val groups = segmentsOfWindow(win, cw, ch, 6, cw, max(2, (0.010f * h).toInt()))
            .sortedBy { it.x0 }
        val digits = ArrayList<Int>(2)
        for (g in groups) {
            if (g.width < 3) continue
            val seg = BooleanArray(g.width * g.height)
            var kk = 0
            for (y in g.y0..g.y1) for (x in g.x0..g.x1) seg[kk++] = win[y * cw + x]
            for ((piece, pw, ph) in splitWide(seg, g.width, g.height, (1.30f * ch).toInt())) {
                val read = classifyGlyph(piece, pw, ph)
                val d = read.digit
                if (d != null && read.aspect > 0.85f && read.holes >= 2) continue // '%' veto
                if (d != null && read.confidence >= minConf) digits.add(d)
            }
        }
        return if (digits.size in 1..maxDigits) digits.joinToString("").toIntOrNull() else null
    }

    // ------------------------------------------------------------------
    // Statistics table (STATS_BOARD, full frames only).
    // ------------------------------------------------------------------
    internal fun findStripBottom(m: Masks, map: FrameMap): Int? {
        val w = m.w; val h = m.h
        val x0 = map.x(0.35f); val x1 = map.x(0.65f)
        val yStart = map.y(0.20f); val yEnd = map.y(0.40f)
        var stripEnd: Int? = null
        var run = 0
        var y = yStart
        while (y < yEnd) {
            var cnt = 0
            for (x in x0 until x1 step 2) if (m.at(m.yellow, x, y)) cnt++
            val frac = cnt.toFloat() * 2f / max(1, x1 - x0)
            if (frac > 0.82f) { run++; stripEnd = y } else {
                if (run >= (0.020f * h).toInt()) return stripEnd
                run = 0
            }
            y++
        }
        return if (run >= (0.015f * h).toInt()) stripEnd else null
    }

    internal fun readStatsTable(m: Masks, map: FrameMap): Stats? {
        val w = m.w; val h = m.h
        val stripBottom = findStripBottom(m, map) ?: return null
        val winTop = stripBottom + 2
        val rowClusters = HashMap<String, List<Box>>(2)
        for (side in listOf("home", "away")) {
            val X0 = map.x(if (side == "home") 0.350f else 0.590f)
            val X1 = map.x(if (side == "home") 0.408f else 0.648f)
            val yEnd = map.y(0.97f)
            val ww = X1 - X0 + 1; val wh = yEnd - winTop
            if (ww <= 0 || wh <= 0) return null
            val win = BooleanArray(ww * wh)
            var k = 0
            for (y in winTop until yEnd) for (x in X0..X1) win[k++] = m.yellowInk[y * w + x]
            val groups = segmentsOfWindow(win, ww, wh, 8, (0.052f * w).toInt(), 2)
            val cand = groups.filter {
                0.020f * h <= it.height && it.height <= 0.050f * h &&
                    it.width <= 0.045f * w && it.area >= 25
            }.map { Box(it.x0 + X0, it.y0 + winTop, it.x1 + X0, it.y1 + winTop, it.area) }
            rowClusters[side] = cand
        }
        fun groupRows(clusters: List<Box>): ArrayList<Box> {
            val sorted = clusters.sortedBy { (it.y0 + it.y1) / 2 }
            val out = ArrayList<Box>()
            for (c in sorted) {
                val cy = (c.y0 + c.y1) / 2f
                val last = out.lastOrNull()
                if (last != null && cy - (last.y0 + last.y1) / 2f < 0.017f * h) {
                    last.x0 = min(last.x0, c.x0); last.x1 = max(last.x1, c.x1)
                    last.y0 = min(last.y0, c.y0); last.y1 = max(last.y1, c.y1)
                    last.area += c.area
                } else {
                    out.add(Box(c.x0, c.y0, c.x1, c.y1, c.area))
                }
            }
            return out
        }
        val homeRows = groupRows(rowClusters["home"] ?: emptyList())
        val awayRows = groupRows(rowClusters["away"] ?: emptyList())
        class PairRow(val home: Box, val away: Box, val cy: Float)
        val used = BooleanArray(awayRows.size)
        val pairs = ArrayList<PairRow>()
        for (hr in homeRows.sortedBy { (it.y0 + it.y1) / 2 }) {
            var bestK = -1; var bestD = Float.MAX_VALUE
            for ((k, ar) in awayRows.withIndex()) {
                if (used[k]) continue
                val d = abs((hr.y0 + hr.y1) / 2f - (ar.y0 + ar.y1) / 2f)
                if (d < bestD) { bestD = d; bestK = k }
            }
            if (bestK >= 0 && bestD <= 0.012f * h) {
                used[bestK] = true
                val ar = awayRows[bestK]
                pairs.add(PairRow(hr, ar, ((hr.y0 + hr.y1) / 2f + (ar.y0 + ar.y1) / 2f) / 2f))
            }
        }
        pairs.sortBy { it.cy }
        val rows = ArrayList<StatRow>(13)
        for ((k, p) in pairs.withIndex()) {
            if (k >= 13) break
            val hv = readStatCell(p.home, m)
            val av = readStatCell(p.away, m)
            if (hv != null && av != null) rows.add(StatRow(STAT_NAMES[k], hv, av))
        }
        return if (rows.isEmpty()) null else Stats(rows)
    }

    private fun readStatCell(cluster: Box, m: Masks): Int? {
        val w = m.w
        val cw = cluster.width; val ch = cluster.height
        val win = BooleanArray(cw * ch)
        var k = 0
        for (y in cluster.y0..cluster.y1) for (x in cluster.x0..cluster.x1) {
            win[k++] = m.yellowInk[y * w + x]
        }
        val groups = segmentsOfWindow(win, cw, ch, 6, cw, 2).sortedBy { it.x0 }
        val digits = ArrayList<Int>(3)
        for (g in groups) {
            val seg = BooleanArray(g.width * g.height)
            var kk = 0
            for (y in g.y0..g.y1) for (x in g.x0..g.x1) seg[kk++] = win[y * cw + x]
            for ((piece, pw, ph) in splitWide(seg, g.width, g.height, (1.30f * ch).toInt())) {
                val read = classifyGlyph(piece, pw, ph)
                val d = read.digit
                if (d != null && read.aspect > 0.85f && read.holes >= 2) continue // '%'
                if (d != null && read.confidence >= 0.45f) digits.add(d)
            }
        }
        if (digits.isEmpty() || digits.size > 3) return null
        val v = digits.joinToString("").toIntOrNull() ?: return null
        return if (v <= 100) v else null
    }

    // ------------------------------------------------------------------
    // Finality header: F (Full Time) / H (Halftime) / closed digit (clock).
    // ------------------------------------------------------------------
    internal fun classifyFH(mask: BooleanArray, w: Int, h: Int): Finality {
        if (w < 3 || h < 8) return Finality.UNKNOWN
        val holes = countHoles(mask, w, h)
        val q = max(1, w / 4)
        var leftInk = 0; var leftArea = 0
        for (y in 0 until h) for (x in 0 until q) { leftArea++; if (mask[y * w + x]) leftInk++ }
        val colL = leftInk.toFloat() / leftArea
        val r0 = 2 * q
        var lowerInk = 0; var lowerArea = 0
        val yStart = (0.55f * h).toInt()
        for (y in yStart until h) for (x in r0 until w) { lowerArea++; if (mask[y * w + x]) lowerInk++ }
        val colRLower = if (lowerArea > 0) lowerInk.toFloat() / lowerArea else 0f
        var topInk = 0; var topArea = 0
        val tEnd = max(1, h / 5)
        for (y in 0 until tEnd) for (x in 0 until w) { topArea++; if (mask[y * w + x]) topInk++ }
        val rowT = topInk.toFloat() / topArea
        return when {
            holes == 0 && colL > 0.30f && colRLower < 0.22f && rowT > 0.40f -> Finality.FULL_TIME
            holes == 0 && colL > 0.30f && colRLower > 0.45f && rowT < 0.60f -> Finality.HALF_TIME
            holes >= 1 -> Finality.CLOCK
            else -> Finality.UNKNOWN
        }
    }

    internal fun readFinalityBoard(m: Masks, map: FrameMap): Finality {
        val w = m.w
        val Y0 = map.y(0.225f); val Y1 = map.y(0.285f)
        val X0 = map.x(0.38f); val X1 = map.x(0.62f)
        if (Y1 <= Y0 || X1 <= X0) return Finality.UNKNOWN
        val ww = X1 - X0; val wh = Y1 - Y0
        val win = BooleanArray(ww * wh)
        var k = 0
        for (y in Y0 until Y1) for (x in X0 until X1) win[k++] = m.navy[y * w + x]
        val groups = segmentsOfWindow(win, ww, wh, 8, (0.10f * w).toInt(), 2)
        val cand = groups.filter { 0.018f * m.h <= it.height && it.height <= 0.045f * m.h }
        if (cand.isEmpty()) return Finality.UNKNOWN
        val g = cand.minBy { it.x0 }
        val seg = BooleanArray(g.width * g.height)
        var kk = 0
        for (y in g.y0..g.y1) for (x in g.x0..g.x1) seg[kk++] = win[y * ww + x]
        return classifyFH(seg, g.width, g.height)
    }

    internal fun readFinalityMenu(m: Masks, map: FrameMap): Finality {
        val w = m.w
        val Y0 = map.y(0.035f); val Y1 = map.y(0.095f)
        val X0 = map.x(0.38f); val X1 = map.x(0.62f)
        if (Y1 <= Y0 || X1 <= X0) return Finality.UNKNOWN
        val ww = X1 - X0; val wh = Y1 - Y0
        val win = BooleanArray(ww * wh)
        var k = 0
        for (y in Y0 until Y1) for (x in X0 until X1) win[k++] = m.yellowInk[y * w + x]
        val groups = segmentsOfWindow(win, ww, wh, 6, (0.10f * w).toInt(), 2)
        val cand = groups.filter { 0.016f * m.h <= it.height && it.height <= 0.045f * m.h }
        if (cand.isEmpty()) return Finality.UNKNOWN
        val g = cand.minBy { it.x0 }
        val seg = BooleanArray(g.width * g.height)
        var kk = 0
        for (y in g.y0..g.y1) for (x in g.x0..g.x1) seg[kk++] = win[y * ww + x]
        return classifyFH(seg, g.width, g.height)
    }

    private fun Float.pow(p: Float): Float = kotlin.math.pow(this, p)
}
